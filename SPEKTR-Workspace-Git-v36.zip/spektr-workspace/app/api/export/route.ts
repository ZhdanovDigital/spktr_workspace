import {authorize,body,json} from '@/server/security';
import {exportGoogle} from '@/server/google-export';
export const dynamic='force-dynamic';
const pending=new Set<string>();
export async function POST(req:Request){let key='';try{authorize(req);const input=await body(req);if(!input.confirmed)throw new Error('Подтвердите создание файла в Google');if(!input.requestId)throw new Error('Отсутствует ID операции');key=req.headers.get('oai-authenticated-user-id')+':'+input.requestId;if(pending.has(key))return json({error:'duplicate',message:'Эта операция уже выполняется или была отправлена. Проверьте Google Drive.'},409);pending.add(key);if(pending.size>1000)pending.delete(pending.values().next().value!);return json(await exportGoogle(input));}catch(e){return json({error:'export_error',message:(e as Error).message},400)}}
