import {authorize,json} from '@/server/security';
import {uploadTaskFile,downloadTaskFile} from '@/server/task-files';
export const dynamic='force-dynamic';
export async function POST(req:Request){try{authorize(req);return json(await uploadTaskFile(req));}catch(e){return json({error:'attachment_error',message:(e as Error).message},(e as Error&{status?:number}).status||400);}}
export async function GET(req:Request){try{authorize(req);return await downloadTaskFile(req);}catch(e){return json({error:'attachment_error',message:(e as Error).message},(e as Error&{status?:number}).status||400);}}
