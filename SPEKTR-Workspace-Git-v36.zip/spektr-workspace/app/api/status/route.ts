import {authorize,json} from '@/server/security';
export const dynamic='force-dynamic';
export async function GET(req:Request){try{authorize(req);return json({database:!!process.env.DB_API_URL,ai:{openai:!!process.env.OPENAI_API_KEY,anthropic:!!process.env.ANTHROPIC_API_KEY,gemini:!!process.env.GEMINI_API_KEY},googleExport:!!(process.env.GOOGLE_EXPORT_ACCESS_TOKEN||process.env.GOOGLE_REFRESH_TOKEN&&process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET)})}catch(e){return json({error:'unauthorized',message:(e as Error).message},401)}}
