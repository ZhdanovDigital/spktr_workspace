import {authorize,body,json} from '@/server/security';
import {readOneC,writeOneC} from '@/server/onec';
export const dynamic='force-dynamic';
export async function GET(req:Request){try{authorize(req);return json(await readOneC(req,new URL(req.url).searchParams.get('client')))}catch(e){return json({message:(e as Error).message},(e as any).status||400)}}
export async function POST(req:Request){try{authorize(req);return json(await writeOneC(req,await body(req)))}catch(e){return json({message:(e as Error).message},(e as any).status||400)}}
