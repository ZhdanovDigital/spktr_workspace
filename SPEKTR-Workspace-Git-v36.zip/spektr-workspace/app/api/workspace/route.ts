import {authorize,body,json} from '@/server/security';
import {loadWorkspace} from '@/server/workspace';
export const dynamic='force-dynamic';
export async function POST(req:Request){try{authorize(req);return json(await loadWorkspace(await body(req)))}catch(e){return json({error:'source_error',message:(e as Error).message},400)}}
