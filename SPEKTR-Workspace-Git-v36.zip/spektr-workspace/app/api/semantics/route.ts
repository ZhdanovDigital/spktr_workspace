import {authorize,body,json} from '@/server/security';
import {read,write} from '@/server/semantic/service';
export const dynamic='force-dynamic';
const error=(e:any)=>json({message:e.message||'Ошибка модуля семантики'},e.status||400);
export async function GET(req:Request){try{authorize(req);return json(await read(req))}catch(e){return error(e)}}
export async function POST(req:Request){try{authorize(req);return json(await write(req,await body(req)))}catch(e){return error(e)}}
