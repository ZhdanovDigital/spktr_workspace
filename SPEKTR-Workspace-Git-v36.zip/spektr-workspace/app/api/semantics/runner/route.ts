import {json} from '@/server/security';
import {runUnattended} from '@/server/semantic/runner';
export const dynamic='force-dynamic';
export async function POST(req:Request){try{return json(await runUnattended(req))}catch(e:any){return json({message:e.message||'Ошибка обработчика'},e.status||400)}}
