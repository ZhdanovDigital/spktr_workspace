import {authorize,body,json} from '@/server/security';
import {generateReport} from '@/server/ai';
export const dynamic='force-dynamic';
export async function POST(req:Request){try{authorize(req);const input=await body(req);if(!input.test&&!input.confirmed)throw new Error('Подтвердите передачу данных выбранному ИИ');return json(await generateReport(input))}catch(e){return json({error:'ai_error',message:(e as Error).message},400)}}
