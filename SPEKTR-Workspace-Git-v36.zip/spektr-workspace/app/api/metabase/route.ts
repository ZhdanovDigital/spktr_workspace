import {authorize,body,json} from '@/server/security';
import {metabaseToken} from '@/server/metabase';
export const dynamic='force-dynamic';
export async function POST(req:Request){try{authorize(req);const input=await body(req);if(input.entityType && input.entityType!=='dashboard')throw new Error('Поддерживаются дашборды');const client=typeof input.customContext==='object'?input.customContext?.client:input.customContext||input.client;return json(await metabaseToken(client,input.entityId));}catch(e){return json({error:'metabase_error',message:(e as Error).message},400)}}
