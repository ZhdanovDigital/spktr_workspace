import { authorize, body, json } from '@/server/security';
import { readTeam, saveTeam } from '@/server/team';
export const dynamic = 'force-dynamic';
export async function GET(req:Request) {
  try { authorize(req); return json(await readTeam(req)); }
  catch(e) { return json({error:'team_error',message:(e as Error).message},(e as Error & {status?:number}).status||400); }
}
export async function POST(req:Request) {
  try { authorize(req); const result = await saveTeam(req,await body(req)); return json(result,result.conflict ? 409 : 200); }
  catch(e) { return json({error:'team_error',message:(e as Error).message},(e as Error & {status?:number}).status||400); }
}
