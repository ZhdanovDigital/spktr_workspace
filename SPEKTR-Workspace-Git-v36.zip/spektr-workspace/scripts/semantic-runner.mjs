// Run in a trusted scheduler environment, with secrets injected by its secret manager.
// The destination is intentionally pinned to this Site.
const endpoint='https://spektr-workspace.zhdanovroman.chatgpt.site/api/semantics/runner';
const service=process.env.SPEKTR_SITE_SERVICE_TOKEN,key=process.env.SEMANTIC_RUNNER_KEY;
if(!service||!key)throw new Error('Set SPEKTR_SITE_SERVICE_TOKEN and SEMANTIC_RUNNER_KEY in the trusted runner environment.');
for(let step=0;step<30;step++){
 const response=await fetch(endpoint,{method:'POST',redirect:'error',signal:AbortSignal.timeout(80000),headers:{'OAI-Sites-Authorization':'Bearer '+service,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:'{}'});
 if(!response.ok)throw new Error('Queue runner failed: HTTP '+response.status);
 const result=await response.json();
 if(result.idle){console.log('No ready jobs.');break;}
 console.log(JSON.stringify({jobId:result.jobId,ok:result.ok,complete:result.complete,retry:result.retry}));
 if(result.retry)break;
}
