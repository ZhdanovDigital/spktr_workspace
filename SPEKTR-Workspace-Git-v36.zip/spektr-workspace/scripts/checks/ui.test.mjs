import test from 'node:test';
import assert from 'node:assert/strict';
const values=new Map();
globalThis.localStorage={get length(){return values.size},key(i){return [...values.keys()][i]??null},getItem(k){return values.get(k)??null},setItem(k,v){values.set(k,String(v))},removeItem(k){values.delete(k)}};
globalThis.window={dispatchEvent(){}};globalThis.CustomEvent=class {};
const {repository:R}=await import('../../public/client/data/repository.js');
const {S}=await import('../../public/client/ui/state.js');
// These records describe October; keep UI/report checks independent of the wall clock.
const {periods,createPeriods}=await import('../../public/client/domain/dates.js');Object.assign(periods,createPeriods('2026-10-31'));
const ui=await import('../../public/client/ui/team.js');
const {clientPage}=await import('../../public/client/ui/client.js');
const {projectsPage}=await import('../../public/client/ui/projects.js');
const {reportsPage,integrationsPage}=await import('../../public/client/ui/tools.js');
const {initializeReport,captureReportInputs}=await import('../../public/client/team-features.js');
R.sharedReady=true;S.client='mrt';
R.sharedRecords.set('task.example',{key:'task.example',revision:1,value:{id:'example',client:'mrt',title:'<script>unsafe</script>',assignee:'Менеджер',due:'2026-10-12',time:'18:00',status:'todo',kind:'review',repeat:'weekly',origin:'demonstration',checks:Array(6).fill(false)}});
R.sharedRecords.set('log.example',{key:'log.example',revision:1,meta:{author:'Менеджер'},value:{id:'example',client:'mrt',date:'2026-10-07',manager:'Менеджер',platform:'google',text:'Уточнены минус-слова',goal:'Проверка трафика',result:'Эффект не оценён',status:'Наблюдаем',origin:'demonstration'}});
R.sharedRecords.set('prompt.example',{key:'prompt.example',revision:1,value:{id:'example',name:'Модуль Google',scope:'platform',platform:'google',content:'Не придумывай причины',autoSelect:true,active:true}});

test('all core screens render with escaped data and working action identifiers',()=>{
  const tasks=ui.tasksPage();assert.ok(tasks.includes('data-action="task-edit"'));assert.ok(tasks.includes('&lt;script&gt;unsafe&lt;/script&gt;'));assert.ok(!tasks.includes('<script>unsafe'));
  assert.ok(ui.journalPage().includes('Уточнены минус-слова'));assert.ok(ui.promptsPage().includes('Модуль Google'));
  assert.ok(projectsPage().includes('Контроль команды'));assert.ok(reportsPage().includes('Новый отчёт'));assert.ok(integrationsPage().includes('Metabase'));
  for(const tab of ['overview','accounts','sales','tasks','work']){S.tab=tab;assert.ok(clientPage().includes('MRT Comfort'))}
});
test('task, journal, prompts, and synchronization dialogs render',()=>{
  S.taskDraft=R.tasks()[0];S.logDraft=R.logs('mrt')[0];S.promptDraft=R.prompts()[0];
  for(const name of ['notifications','team-sync','task-edit','seed-reviews','prompt-edit','prompt-import','journal-edit','metabase-settings','metabase-view']){
    const html=ui.teamModal(name);assert.ok(html.includes('role="dialog"'),name);assert.ok(html.includes('data-action="close"'),name);
  }
  assert.equal(ui.teamModal('unrecognized'),null);
});
test('report automatically includes only the selected-period journal and freezes selected instructions',()=>{
  S.reportPeriod='this_month';initializeReport();assert.ok(S.brief[1].includes('Уточнены минус-слова'));assert.ok(S.reportPromptIds.includes('example'));
  const {data,cfg}=captureReportInputs();assert.equal(data.confirmedWorkLog.length,1);assert.equal(data.confirmedWorkLog[0].recordedBy,'Менеджер');assert.ok(cfg.skill.includes('Не придумывай причины'));
  const frozen=structuredClone(S.reportPromptSnapshot);R.sharedRecords.get('prompt.example').value.content='Новая инструкция';assert.deepEqual(S.reportPromptSnapshot,frozen);
});

test('client dashboard scopes work to that client and exposes assignment controls only to admin',async()=>{
 const {managerControl,clientSettingsModal}=await import('../../public/client/ui/client-admin.js');
 const oldUser=R.sharedUser;S.client='mrt';S.tab='overview';
 R.sharedRecords.set('log.other',{key:'log.other',revision:1,value:{id:'other',client:'mebel',date:'2026-10-07',text:'PRIVATE OTHER CLIENT JOURNAL',origin:'demonstration'}});
 const html=clientPage();assert.ok(html.includes('Уточнены минус-слова'));assert.ok(!html.includes('PRIVATE OTHER CLIENT JOURNAL'));
 assert.ok(html.includes('data-action="task-new-account"'));assert.ok(html.includes('Журнал изменений'));assert.ok(html.includes('Цена результата'));
 const c=R.clients().find(c=>c.id==='mrt');assert.equal(c.manager,'Мадина');
 R.sharedUser={permissions:{manageClients:false}};assert.ok(!managerControl(c).includes('data-action="client-settings"'));
 R.sharedUser={permissions:{manageClients:true}};assert.ok(managerControl(c).includes('data-action="client-settings"'));
 S.modal='client-settings';assert.ok(clientSettingsModal().includes('form="client-settings-form"'));
 R.sharedUser=oldUser;S.modal=null;R.sharedRecords.delete('log.other');
});

test('both web systems render together and setup allows both IDs without a source selector',async()=>{
 const {webAnalyticsSection}=await import('../../public/client/ui/web-analytics.js');
 const {advancedModal}=await import('../../public/client/ui/advanced-modals.js');
 const c=R.clients().find(c=>c.id==='mrt'),ga4=structuredClone(c.analytics[0]),ym={...structuredClone(ga4),id:'ym-second',provider:'metrika',name:'Отдельная Метрика'};
 const html=webAnalyticsSection({...c,analytics:[ga4,ym]});
 assert.match(html,/web-provider-ga4/);assert.match(html,/web-provider-metrika/);assert.match(html,/Google Analytics 4/);assert.match(html,/Яндекс Метрика/);
 assert.ok(!html.includes('data-field="analyticsSource"'));assert.match(html,/не складываются/);
 const modal=advancedModal('analytics-setup');assert.match(modal,/name="ga4Id"/);assert.match(modal,/name="metrikaId"/);
});

test('budget controls render on both project list and client dashboard; saved periods use server records and escape notes',async()=>{
 const {budgetPanel,budgetModal,clientBudgets}=await import('../../public/client/ui/budget-plan.js');const {budgetKey}=await import('../../public/client/domain/budget-plan.js');
 const {periods}=await import('../../public/client/domain/dates.js');const c=R.clients().find(c=>c.id==='mrt'),p=periods.this_month;
 const value={client:'mrt',origin:'demonstration',from:p.from,to:p.to,source:'paid',note:'<script>unsafe budget</script>',amounts:[{currency:'KZT',amount:500000}]},key=budgetKey(value);
 R.sharedRecords.set(key,{key,value,revision:1,meta:{author:'Мадина',updatedAt:new Date().toISOString()}});S.client='mrt';S.period='this_month';S.tab='overview';
 assert.match(projectsPage(),/План расходов/);assert.match(projectsPage(),/data-action="budget-edit"/);const html=clientPage();assert.match(html,/План и факт расходов/);assert.match(html,/channel-reading-status/);assert.match(html,/Оплачено клиентом/);assert.match(html,/Мадина/);assert.ok(!html.includes(value.note));assert.match(html,/&lt;script&gt;unsafe budget/);
 const before=clientBudgets(c).length;R.sharedRecords.set('budgetPlan.database.mrt.other',{key:'budgetPlan.database.mrt.other',value:{...value,origin:'database'}});assert.equal(clientBudgets(c).length,before);
 S.modal='budget-plan';S.budgetDraft={...value,amounts:{KZT:'500000'}};S.budgetEditingKey=key;assert.match(budgetModal(),/id="budget-form"/);assert.match(budgetModal(),/readonly/);assert.match(budgetModal(),/budget-amount-KZT/);S.modal=null;S.budgetEditingKey=null;R.sharedRecords.delete(key);R.sharedRecords.delete('budgetPlan.database.mrt.other');
});

test('budget editor preserves draft during rerenders, captures revision and awaits server acknowledgement',async()=>{
 const {installBudgets}=await import('../../public/client/ui/budget-plan.js');const {budgetKey}=await import('../../public/client/domain/budget-plan.js');const {periods}=await import('../../public/client/domain/dates.js');
 const oldDocument=globalThis.document,oldFormData=globalThis.FormData,oldPersist=R.persist;const events=new Map(),actions={};let toasts=[],closed=0,captured,resolveSave;
 globalThis.document={addEventListener(name,fn){events.set(name,fn)}};globalThis.FormData=class{constructor(form){return form.fields[Symbol.iterator]()}};
 const value={client:'mrt',origin:'demonstration',from:periods.this_month.from,to:periods.this_month.to,source:'manual',note:'Old',amounts:[{currency:'KZT',amount:500000}]},key=budgetKey(value);R.sharedRecords.set(key,{key,value,revision:4});
 try{
  installBudgets(actions,{render(){},toast(t){toasts.push(t)},openModal(name){S.modal=name},closeModal(){closed++;S.modal=null}});
  actions['budget-edit']({dataset:{client:'mrt',key}});assert.equal(S.budgetRevision,4);
  const form={fields:[['from',value.from],['to',value.to],['source','paid'],['note','New budget'],['amount-KZT','600000']],hasAttribute(name){return name==='data-budget-form'}};
  events.get('input')({target:{closest(){return form}}});assert.equal(S.budgetDraft.amounts.KZT,'600000');assert.equal(S.budgetDraft.source,'paid');
  // Background refresh must not update the revision captured when the form opened.
  R.sharedRecords.get(key).revision=5;R.persist=(...args)=>{captured=args;return new Promise(resolve=>resolveSave=resolve)};
  const saving=events.get('submit')({target:form,preventDefault(){}});assert.equal(captured[2],4);assert.equal(captured[1].amounts[0].amount,600000);assert.equal(closed,0);assert.equal(toasts.length,0);assert.equal(S.teamBusy,true);
  resolveSave({});await saving;assert.equal(closed,1);assert.equal(toasts.length,1);assert.equal(S.teamBusy,false);
  actions['budget-edit']({dataset:{client:'mrt',key}});R.persist=async()=>{throw new Error('network failed')};await events.get('submit')({target:form,preventDefault(){}});assert.equal(closed,1);assert.equal(S.modal,'budget-plan');assert.equal(S.budgetDraft.note,'New budget');assert.equal(S.budgetError,'network failed');
 }finally{R.persist=oldPersist;globalThis.document=oldDocument;globalThis.FormData=oldFormData;R.sharedRecords.delete(key);S.modal=null;S.teamBusy=false;S.budgetEditingKey=null}
});

test('website dashboard shows bounce rate and individual chosen goals, and every client mark supports its favicon',async()=>{
 const {webAnalyticsSection}=await import('../../public/client/ui/web-analytics.js');const {goalPreferenceKey}=await import('../../public/client/domain/web-goals.js');
 S.period='this_month';S.client='mrt';S.tab='overview';let c=R.clients().find(c=>c.id==='mrt'),source=c.analytics[0];const html=webAnalyticsSection(c);
 assert.match(html,/Отказы/);assert.ok(!html.includes('Вовлечённость'));assert.match(html,/Избранные конверсии/);assert.match(html,/WhatsApp/);assert.match(html,/Звонки/);assert.ok(!html.includes('web-events-total'));assert.match(html,/data-action="web-goals-edit"/);assert.match(projectsPage(),/data-client-favicon/);assert.match(clientPage(),/favicon.ico/);
 const key=goalPreferenceKey(c),value={clientId:c.id,origin:'demonstration',sources:[{provider:source.provider,sourceId:source.id,goals:[{id:'whatsapp',kind:'whatsapp',name:'Only WhatsApp'}]}]};R.sharedRecords.set(key,{key,value,revision:1});
 c=R.clients().find(c=>c.id==='mrt');assert.equal(c.analytics[0].favoriteGoals.length,1);const chosen=webAnalyticsSection(c);assert.match(chosen,/goal-whatsapp/);assert.ok(!chosen.includes('goal-lead'));assert.ok(!chosen.includes('goal-call'));
 const nextSource={...source,id:'another-counter'};assert.equal(R.clients().find(c=>c.id==='mrt').analytics[0].id,source.id);assert.notEqual(nextSource.id,c.analytics[0].id);
 R.sharedRecords.delete(key);
});

test('goal selector saves explicit choices only after acknowledgement and preserves drafts on failure',async()=>{
 const {installWebGoals,webGoalsModal}=await import('../../public/client/ui/web-goals.js');const {goalPreferenceKey}=await import('../../public/client/domain/web-goals.js');
 const previousDocument=globalThis.document,previousFormData=globalThis.FormData,previousPersist=R.persist;const events={},actions={};let closed=0,captured,resolveSave;globalThis.document={addEventListener(name,fn){events[name]=fn}};globalThis.FormData=class {constructor(form){this.data=new Map(form.fields)}has(k){return this.data.has(k)}get(k){return this.data.get(k)}};
 const c=R.clients().find(c=>c.id==='mrt'),source=c.analytics[0],key=goalPreferenceKey(c);
 try{
  installWebGoals(actions,{render(){},toast(){},openModal(name){S.modal=name},closeModal(){closed++;S.modal=null}});
  actions['web-goals-edit']({dataset:{client:c.id,source:source.id,provider:source.provider}});assert.equal(S.modal,'web-goals');assert.match(webGoalsModal(),/name="selected-0"/);
  const form={fields:[['selected-1','on'],['kind-0','lead'],['kind-1','whatsapp'],['kind-2','call']],hasAttribute(name){return name==='data-goal-preferences-form'}};
  R.persist=(...args)=>{captured=args;return new Promise(resolve=>resolveSave=resolve)};const saving=events.submit({target:form,preventDefault(){}});assert.equal(closed,0);assert.equal(S.teamBusy,true);assert.equal(captured[0],key);assert.equal(captured[2],0);assert.deepEqual(captured[1].sources[0].goals.map(g=>g.id),['whatsapp']);resolveSave({});await saving;assert.equal(closed,1);
  actions['web-goals-edit']({dataset:{client:c.id,source:source.id,provider:source.provider}});R.persist=async()=>{throw Error('network failed')};await events.submit({target:form,preventDefault(){}});assert.equal(closed,1);assert.equal(S.goalDraft.rows[1].selected,true);assert.equal(S.goalError,'network failed');
 }finally{globalThis.document=previousDocument;globalThis.FormData=previousFormData;R.persist=previousPersist;S.teamBusy=false;S.modal=null}
});

test('every client tab exposes two distinct Drive folders and a shared edit dialog',async()=>{
 const {clientFolderKey}=await import('../../public/client/domain/client-folders.js'),{clientFolderLinks,clientFoldersModal}=await import('../../public/client/ui/client-folders.js');const c=R.clients()[0],key=clientFolderKey(c),before={client:S.client,tab:S.tab,modal:S.modal};S.client=c.id;const links={general:'https://drive.google.com/drive/folders/GENERAL_test',digital:'https://drive.google.com/drive/folders/DIGITAL_test?resourcekey=0-test'};R.sharedRecords.set(key,{key,revision:1,value:{clientId:c.id,origin:'demonstration',links}});
 for(const tab of ['overview','accounts','sales','tasks','journal','work']){S.tab=tab;const html=clientPage();assert.ok(html.includes('Общая папка клиента'));assert.ok(html.includes('Папка Digital'));assert.ok(html.includes('href="'+links.general+'"'));assert.ok(html.includes('href="'+links.digital+'"'));assert.ok(html.includes('data-action="client-folders"'))}
 R.sharedRecords.set(key,{key,revision:2,value:{clientId:c.id,origin:'demonstration',links:{}}});assert.equal((clientFolderLinks(c).match(/folder-unlinked/g)||[]).length,2);S.modal='client-folders';S.clientFoldersContext={id:c.id,name:c.name,key,origin:'demonstration',revision:2};S.clientFoldersDraft=links;const modal=clientFoldersModal();assert.ok(modal.includes('client-folder-general'));assert.ok(modal.includes('client-folder-digital'));assert.ok(modal.includes('Сохранить папки'));assert.ok(modal.includes('DIGITAL_test?resourcekey=0-test'));R.sharedRecords.delete(key);Object.assign(S,before);
});
