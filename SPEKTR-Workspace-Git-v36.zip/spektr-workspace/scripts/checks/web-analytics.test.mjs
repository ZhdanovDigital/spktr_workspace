import test from 'node:test';
import assert from 'node:assert/strict';
import {webMetrics,webSourceSnapshot} from '../../public/client/domain/analytics.js';
import {analyticsReportText,buildReportContext,webReportSheets} from '../../public/client/domain/report.js';
import {makePeriod} from '../../public/client/domain/dates.js';
const p=makePeriod('test','2026-10-05','2026-10-06');
const day=(date,sessions,goals)=>({date,sessions,users:80,pageviews:sessions*2,engagedSessions:sessions*.6,goalSessions:goals,conversions:goals+1,durationSeconds:sessions*50,bounces:sessions*.25});
const ga4={id:'ga4-123',provider:'ga4',name:'GA4 example.kz',state:'fresh',updated:'2026-10-09T04:00:00Z',days:[day('2026-10-03',100,10),day('2026-10-04',100,10),day('2026-10-05',100,10),day('2026-10-06',300,60)],periodTotals:[{from:p.from,to:p.to,users:250}],channels:[{date:p.from,channel:'Paid Search',sessions:100,goalSessions:10,conversions:11}]};
const metrika={...structuredClone(ga4),id:'ym-456',provider:'metrika',name:'Метрика example.kz',days:ga4.days.map(r=>({...r,sessions:r.sessions*2})),periodTotals:[{from:p.from,to:p.to,users:400}]};
const client={id:'one',name:'Example',site:'example.kz',accounts:[],sales:[],previous:[],targets:{},analytics:[ga4,metrika]};
test('website rates are weighted by sessions and unique users are read from period totals',()=>{
 const m=webMetrics(ga4,p);assert.equal(m.sessions,400);assert.equal(m.goalSessions,70);assert.equal(m.cr,17.5);assert.equal(m.engagementRate,60);assert.equal(m.bounceRate,25);assert.equal(m.avgDuration,50);assert.equal(m.users,250);
 assert.equal(webMetrics({...ga4,periodTotals:[]},p).users,null);
 const partial=webMetrics({...ga4,days:ga4.days.map(r=>r.date===p.from?{...r,sessions:null}:r)},p);assert.equal(partial.sessions,null);assert.equal(partial.cr,null);
});
test('web comparison requires complete independent coverage and fresh source data',()=>{
 const reference=Date.parse('2026-10-09T04:40:00Z');
 assert.equal(webSourceSnapshot(ga4,p,{},reference).coverage.comparable,true);
 assert.equal(webSourceSnapshot({...ga4,days:ga4.days.slice(1)},p,{},reference).coverage.comparable,false);
 assert.equal(webSourceSnapshot(ga4,p,{},reference+86400000*2).coverage.comparable,false);
 assert.equal(webSourceSnapshot({...ga4,state:'error'},p,{},reference).coverage.comparable,false);
});
test('AI context, local report and spreadsheets include both systems without merging metrics',()=>{
 const data=buildReportContext(client,p,[],[],{},null);
 assert.deepEqual(data.analytics.map(a=>[a.id,a.provider,a.current.sessions]),[['ga4-123','ga4',400],['ym-456','metrika',800]]);
 assert.equal(data.analytics[0].coverage.expectedDays,2);assert.ok(data.rules.some(r=>r.includes('GA4 и Яндекс')));
 const text=analyticsReportText(client,p);assert.match(text,/Google Analytics 4/);assert.match(text,/Яндекс Метрика/);assert.ok(!text.includes('Вовлечённость:'));assert.match(text,/Избранные конверсии/);assert.match(text,/Отказы/);assert.match(text,/не суммируются/);
 const sheets=webReportSheets(data),rows=sheets['Веб-аналитика'];assert.equal(rows.length,5);
 const sessionColumn=rows[0].indexOf('Сеансы / визиты');assert.equal(rows[1][sessionColumn],400);assert.equal(rows[3][sessionColumn],800);
 assert.deepEqual(sheets['Веб-источники'].slice(1).map(r=>r[2]),['ga4-123','ym-456']);
 const legacy=webReportSheets({period:p,analytics:[{provider:'ga4',name:'Saved report',current:null,previous:null}]});assert.equal(legacy['Веб-аналитика'].length,3);
});
