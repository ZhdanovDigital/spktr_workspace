import test from 'node:test';
import assert from 'node:assert/strict';
import {accountMetrics} from '../../public/client/domain/analytics.js';
import {metrics,budgetForecast,validateSales} from '../../public/client/domain/metrics.js';
import {accountIssues,logInPeriod,composePrompt,nextDue,taskDueAt,overdue} from '../../public/client/domain/operations.js';
import {makePeriod,isoDate,createPeriods,setCustomPeriod} from '../../public/client/domain/dates.js';

const p=makePeriod('test','2026-10-05','2026-10-11');
const rows=(from,n,spend=100,results=5)=>Array.from({length:n},(_,i)=>({date:new Date(Date.parse(from)+i*86400000).toISOString().slice(0,10),spend,impressions:1000,clicks:100,conversions:results}));
const account={id:'google-one',platform:'google',currency:'KZT',state:'fresh',updated:'2026-10-12T05:00:00Z',asOf:'2026-10-12T10:00:00+05:00',history:rows('2026-09-28',7,100),days:rows('2026-10-05',7,200),balance:1400,payment:'prepay'};
const client={id:'client-one',accounts:[account],sales:[],previous:[],targets:{}};

test('prices are calculated from aggregate spend and results; missing fields stay missing',()=>{
  const m=accountMetrics(account,p),old=accountMetrics(account,p,true);
  assert.equal(m.spend,1400);assert.equal(m.conversions,35);assert.equal(m.cpa,40);assert.equal(old.cpa,20);assert.equal(m.ctr,10);
  const partial=structuredClone(account);partial.days[0].conversions=null;
  assert.equal(accountMetrics(partial,p).conversions,null);assert.equal(accountMetrics(partial,p).cpa,null);
  assert.equal(accountMetrics({days:[]},p).spend,null);
});
test('alerts need both full seven-day periods and enough results',()=>{
  assert.equal(accountIssues(client,{cpaPercent:30,minResults:5}).length,1);
  assert.equal(accountIssues({...client,accounts:[{...account,history:account.history.slice(1)}]},{cpaPercent:30,minResults:5}).length,0);
  assert.equal(accountIssues(client,{cpaPercent:30,minResults:36}).length,0);
  assert.equal(accountIssues({...client,accounts:[{...account,state:'stale'}]},{cpaPercent:30,minResults:5}).length,0);
});
test('different currencies and unattributed sales do not produce combined financial claims',()=>{
  const c={...client,accounts:[account,{...account,id:'meta',currency:'USD'}],sales:[{date:p.from,source:'all',leads:10,qualified:6,poor:2,unrated:2,sales:1,revenue:10000,attributed:false}]};
  const m=metrics(c,p);assert.equal(m.spend,null);assert.equal(m.cpl,null);assert.equal(m.roas,null);assert.equal(m.drr,null);
  assert.ok(validateSales([{date:p.from,source:'all',leads:10,qualified:6,poor:2,unrated:2,sales:1},{date:p.from,source:'meta',leads:2,qualified:2,poor:0,unrated:0,sales:0}]).some(e=>e.includes('нельзя смешивать')));
});
test('partial CRM data and a different revenue currency cannot inflate financial efficiency',()=>{
  const incomplete={...client,sales:[{date:p.from,source:'all',leads:10,qualified:6,poor:2,unrated:2,sales:1,revenue:10000,attributed:true}]};
  assert.equal(metrics(incomplete,p).cpl,null);assert.equal(metrics(incomplete,p).roas,null);
  const one=makePeriod('day',p.from,p.from),complete={...incomplete,accounts:[{...account,currency:'USD'}]};
  assert.equal(metrics(complete,one).cpl,20);assert.equal(metrics(complete,one).roas,null);assert.equal(metrics(complete,one).revenueCurrency,'KZT');
});
test('budget forecast uses seven complete days and the correct payment balance',()=>{
  assert.equal(budgetForecast(account).daily,200);assert.equal(budgetForecast(account).days,7);
  assert.equal(budgetForecast({...account,payment:'postpay',balance:null,limit:2800}).days,14);
  assert.equal(budgetForecast({...account,days:account.days.slice(1)}).days,null);
  assert.equal(budgetForecast({...account,days:rows(p.from,7,0)}).days,null);
});
test('journal dates and prompt scope are restricted to the selected report',()=>{
  assert.deepEqual(logInPeriod([{id:'before',date:'2026-10-04'},{id:'during',date:'2026-10-07'},{id:'after',date:'2026-10-12'}],p).map(x=>x.id),['during']);
  const modules=[{id:'format',name:'Format',scope:'format',content:'format',revision:2},{id:'google',name:'Google',scope:'platform',platform:'google',content:'google'},{id:'foreign',name:'Other client',scope:'client',client:'different',content:'not allowed'},{id:'meta',name:'Meta',scope:'platform',platform:'meta',content:'not allowed'},{id:'agency',name:'Agency',scope:'agency',content:'agency'}];
  const result=composePrompt({prompt:'base',skill:'legacy'},modules,client,modules.map(x=>x.id));
  assert.deepEqual(result.layers.map(x=>x.id),['agency','google','format']);assert.equal(result.layers[2].revision,2);assert.equal(result.prompt,'base');assert.ok(!result.skill.includes('not allowed'));
  assert.throws(()=>composePrompt({},[...modules,{id:'f2',name:'f2',scope:'format',content:'second'}],client,['format','f2']),/один модуль/);
});
test('recurrence retains month-end dates and reminders use Almaty time',()=>{
  assert.equal(nextDue('2026-01-31','monthly',31),'2026-02-28');assert.equal(nextDue('2026-02-28','monthly',31),'2026-03-31');
  assert.equal(nextDue('2026-10-12','weekly'),'2026-10-19');
  const task={due:'2026-10-12',time:'18:00',status:'todo'};
  assert.equal(taskDueAt(task),Date.parse('2026-10-12T13:00:00Z'));
  assert.equal(overdue(task,Date.parse('2026-10-12T12:59:59Z')),false);assert.equal(overdue(task,Date.parse('2026-10-12T13:00:01Z')),true);
  assert.equal(overdue({...task,status:'done'},Date.parse('2026-10-13T13:00:01Z')),false);
  assert.equal(isoDate(new Date('2026-10-12T20:00:00Z')),'2026-10-13');
});


test('month comparisons cover the entire previous calendar month across year and leap boundaries',()=>{
 for(const [today,key,from,to] of [
  ['2026-10-16','last_month','2026-08-01','2026-08-31'],
  ['2026-10-16','this_month','2026-09-01','2026-09-30'],
  ['2026-01-05','this_month','2025-12-01','2025-12-31'],
  ['2024-03-15','this_month','2024-02-01','2024-02-29'],
  ['2025-03-15','this_month','2025-02-01','2025-02-28']
 ]){const period=createPeriods(today)[key];assert.equal(period.previousFrom,from);assert.equal(period.previousTo,to)}
 const custom=setCustomPeriod('2026-09-01','2026-09-30');assert.equal(custom.previousFrom,'2026-08-01');assert.equal(custom.previousTo,'2026-08-31');
 const arbitrary=makePeriod('custom','2026-10-04','2026-10-10');assert.equal(arbitrary.previousFrom,'2026-09-27');assert.equal(arbitrary.previousTo,'2026-10-03');
});
test('weekly presets compare with the preceding Monday to Sunday, including a week crossing New Year',()=>{
 const periods=createPeriods('2026-01-01');
 assert.equal(periods.this_week.from,'2025-12-29');assert.equal(periods.this_week.to,'2026-01-01');
 assert.equal(periods.this_week.previousFrom,'2025-12-22');assert.equal(periods.this_week.previousTo,'2025-12-28');
 assert.equal(periods.last_week.previousFrom,'2025-12-15');assert.equal(periods.last_week.previousTo,'2025-12-21');
});
test('monthly coverage uses each month length and calculates comparable CR and CPL from complete aggregates',()=>{
 const period=createPeriods('2026-10-16').last_month;
 const sales=(from,n,leads)=>rows(from,n).map(r=>({...r,source:'all',leads,qualified:leads,poor:0,unrated:0,sales:0,attributed:true}));
 const c={...client,accounts:[{...account,history:rows('2026-08-01',31,100),days:rows('2026-09-01',30,150)}],previous:sales('2026-08-01',31,10),sales:sales('2026-09-01',30,20)};
 const current=metrics(c,period),old=metrics(c,period,true);
 assert.equal(current.adComplete,true);assert.equal(old.adComplete,true);assert.equal(old.crmComplete,true);
 assert.equal(current.cr,20);assert.equal(old.cr,10);assert.equal(current.cpl,7.5);assert.equal(old.cpl,10);
 c.accounts[0].history.shift();assert.equal(metrics(c,period,true).cpl,null);
});
