import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeExchangeRates,projectSpend,budgetDayTone} from '../../public/client/domain/project-money.js';
import {weekdayPerformance,qualityTrend} from '../../public/client/domain/web-insights.js';
const fx=normalizeExchangeRates({base:'KZT',rates:{USD:500,EUR:550},asOf:'2026-10-31',source:'Test accounting rate'});
test('portfolio totals convert selected-period native spend once, preserve zeros and refuse invented rates or missing values',()=>{
 const accounts=[{currency:'KZT',spend:1000},{currency:'USD',spend:10},{currency:'EUR',spend:2}];
 const metric=a=>({spend:a.spend,complete:true});let total=projectSpend(accounts,metric,fx);assert.equal(total.kzt,7100);assert.equal(total.usd,14.2);
 total=projectSpend(accounts,metric,null);assert.equal(total.kzt,null);assert.equal(total.usd,null);
 assert.equal(projectSpend([{currency:'USD',spend:10}],metric,null).usd,10);
 assert.equal(projectSpend([{currency:'KZT',spend:0}],metric,null).kzt,0);
 assert.equal(projectSpend([{currency:'KZT',spend:null}],metric,fx).kzt,null);
 assert.equal(projectSpend([],metric,fx).kzt,null);
 for(const patch of [{base:'USD'},{rates:{USD:0}},{rates:{USD:Infinity}},{rates:{KZT:2}},{asOf:'2026-02-30'}])assert.equal(normalizeExchangeRates({...fx,...patch}),null);
 assert.deepEqual([6.99,7,7.01,null].map(budgetDayTone),['low','boundary','safe','unknown']);
});
test('weekday CR is weighted by visits and quality lines preserve missing dates',()=>{
 const p={from:'2026-10-05',to:'2026-10-12'},source={provider:'metrika',days:[{date:'2026-10-05',sessions:100,goalSessions:20,bounces:30},{date:'2026-10-12',sessions:300,goalSessions:30,bounces:60}]};
 const weekdays=weekdayPerformance(source,p);assert.equal(weekdays[0].sessions,400);assert.equal(weekdays[0].cr,12.5);assert.equal(weekdays[0].expected,2);assert.equal(weekdays[1].sessions,null);
 const series=qualityTrend(source,p);assert.equal(series[0].cr,20);assert.equal(series[1].cr,null);assert.equal(series[0].bounceRate,30);
});
const values=new Map();globalThis.localStorage={get length(){return values.size},key:i=>[...values.keys()][i],getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};
globalThis.window={dispatchEvent(){},addEventListener(){}};globalThis.CustomEvent=class{};
globalThis.document={addEventListener(){},querySelectorAll(){return []}};
const {repository:R}=await import('../../public/client/data/repository.js');
const {S}=await import('../../public/client/ui/state.js');
const {installTeam}=await import('../../public/client/team-features.js');
const {tasksPage}=await import('../../public/client/ui/task-board.js');
test('manual and newly loaded DB clients become selectable task projects, including clients with no tasks',()=>{
 R.runtime.database=true;R.remoteClients=[{id:'db',name:'DB client',manager:'Мадина',accounts:[],sales:[],previous:[]}];
 values.set('spektr.workspace.v1.customClients',JSON.stringify([{id:'manual',name:'New manual client',manager:'Темирлан',accounts:[],sales:[],previous:[]}]));
 const page=tasksPage();assert.ok(page.includes('New manual client'));assert.ok(page.includes('DB client'));assert.ok(page.includes('data-task-drop="review"'));assert.equal((page.match(/data-task-drop=/g)||[]).length,4);
 R.remoteClients.push({id:'new-db',name:'Next DB import',accounts:[],sales:[],previous:[]});assert.ok(tasksPage().includes('Next DB import'));
});
test('moving tasks retains subtasks/comments and revision, checks completion rules and creates exactly one recurring successor',async()=>{
 const actions={},messages=[],originalPersist=R.persist,originalTimer=globalThis.setInterval;globalThis.setInterval=()=>0;
 installTeam(actions,{render(){},toast:m=>messages.push(m),openModal(){},closeModal(){},navigate(){},persistReport(){}});globalThis.setInterval=originalTimer;
 let revisionSeen;R.persist=async(key,value,revision)=>{revisionSeen=revision;const item={key,value:structuredClone(value),revision:(R.sharedRecords.get(key)?.revision||0)+1};R.sharedRecords.set(key,item);return item};
 try{
  const task={id:'move',client:'db',origin:'database',title:'Review Ads',assignee:'Мадина',due:'2027-01-01',status:'todo',kind:'review',repeat:'weekly',checks:Array(6).fill(false),subtasks:[{id:'sub',title:'Inspect queries',done:true}],comments:[{id:'c',text:'Context',author:'Madina',at:'2026-10-31T00:00:00Z'}]};
  R.sharedRecords.set('task.move',{key:'task.move',value:task,revision:4});await actions['task-move']({dataset:{id:'move',status:'review'}});let saved=R.sharedRecords.get('task.move');assert.equal(saved.value.status,'review');assert.equal(revisionSeen,4);assert.equal(saved.value.subtasks[0].done,true);assert.equal(saved.value.comments[0].text,'Context');
  await actions['task-move']({dataset:{id:'move',status:'done'}});assert.equal(R.sharedRecords.get('task.move').value.status,'review');assert.ok(messages.at(-1).includes('пункты'));
  saved.value.checks=Array(6).fill(true);await actions['task-move']({dataset:{id:'move',status:'done'}});assert.equal(R.sharedRecords.get('task.move').value.status,'done');assert.equal(R.tasks().filter(t=>t.series==='move').length,1);
  await actions['task-move']({dataset:{id:'move',status:'done'}});assert.equal(R.tasks().filter(t=>t.series==='move').length,1);
 }finally{R.persist=originalPersist}
});
