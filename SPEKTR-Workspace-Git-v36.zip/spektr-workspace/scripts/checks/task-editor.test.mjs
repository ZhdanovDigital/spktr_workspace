import test from 'node:test';
import assert from 'node:assert/strict';
const values=new Map(),listeners=new Map();
globalThis.localStorage={get length(){return values.size},key:i=>[...values.keys()][i],getItem:k=>values.get(k)||null,setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};globalThis.window={dispatchEvent(){}};globalThis.CustomEvent=class{};
const {S}=await import('../../public/client/ui/state.js');const {repository:R}=await import('../../public/client/data/repository.js');
const {taskEditorModal,installTaskEditor,uploadTaskAttachments,finishTaskAttachments}=await import('../../public/client/ui/task-editor.js');
test('issue editor separates content/properties and renders checkboxes, attachment controls and escaped text',()=>{
 R.sharedReady=true;const html=taskEditorModal({id:'task-fixture',client:'mrt',title:'<script>title</script>',subtasks:[{id:'one',title:'Inspect query',done:true}],attachments:[{id:'a1234567-1234-4123-8123-123456789abc',name:'<b>file</b>.txt',size:12}],comments:[]});
 assert.ok(html.includes('task-editor-main'));assert.ok(html.includes('task-editor-properties'));assert.ok(html.includes('name="subtask-0"'));assert.ok(html.includes('data-task-check'));assert.ok(html.includes('checked'));assert.ok(html.includes('data-task-files'));assert.ok(html.includes('/api/task-files?id='));assert.ok(html.includes('&lt;b&gt;file&lt;/b&gt;.txt'));assert.ok(!html.includes('<script>title</script>'));
});
test('adding/removing checklist items preserves the form draft; failed file batches retry only failed files with stable IDs',async()=>{
 const realFormData=globalThis.FormData,realFetch=globalThis.fetch;
 const fields={title:'Saved draft title',description:'Keep this text',client:'mrt',assignee:'Мадина',due:'2026-11-02',time:'18:00',status:'todo',kind:'other',repeat:'none',commentText:'Keep comment'},checkInput={value:'Check goals',focus(){}};let rows=[];
 const form={elements:{assignee:{value:'Мадина'}},querySelectorAll(){return rows.map(row=>({dataset:{subtaskRow:row.id},querySelector(selector){return selector==='[data-subtask-title]'?{value:row.title}:{checked:row.done}}}))},querySelector(){return checkInput}};
 globalThis.document={querySelector:selector=>selector==='#team-task-form'?form:checkInput,addEventListener(type,fn){const list=listeners.get(type)||[];list.push(fn);listeners.set(type,list)}};
 globalThis.FormData=class {constructor(input){return input?new Map([...Object.entries(fields),...rows.filter(row=>row.done).map(row=>['subtask-'+rows.indexOf(row),'on'])]):new Map()}};
 S.taskDraft={draftId:'b1234567-1234-4123-8123-123456789abc',client:'mrt',subtasks:[],attachments:[]};S.teamBusy=false;
 const actions={},messages=[];installTaskEditor(actions,{render(){rows=structuredClone(S.taskDraft.subtasks);checkInput.value=S.taskDraft.checkDraft||''},toast:text=>messages.push(text)});
 try{
  actions['task-check-add']();assert.equal(S.taskDraft.title,fields.title);assert.equal(S.taskDraft.description,fields.description);assert.equal(S.taskDraft.subtasks[0].title,'Check goals');assert.equal(S.taskDraft.commentText,'Keep comment');
  rows[0].done=true;checkInput.value='Check budget';actions['task-check-add']();assert.equal(S.taskDraft.subtasks[0].done,true);assert.equal(S.taskDraft.subtasks.length,2);
  actions['task-check-remove']({dataset:{id:S.taskDraft.subtasks[1].id}});assert.equal(S.taskDraft.subtasks.length,1);assert.equal(S.taskDraft.subtasks[0].done,true);
  const target={files:[new File(['a'],'a.txt'),new File(['b'],'b.txt')],closest(){return form},hasAttribute:name=>name==='data-task-files'};
  for(const listener of listeners.get('change'))listener({target});assert.ok(taskEditorModal(S.taskDraft).includes('a.txt'));assert.ok(taskEditorModal(S.taskDraft).includes('b.txt'));
  let fail=true;const calls=[];globalThis.fetch=async(url,{body})=>{assert.equal(url,'/api/task-files');assert.equal(body.get('taskId'),S.taskDraft.draftId);const file=body.get('file'),id=body.get('id');calls.push({name:file.name,id});if(file.name==='b.txt'&&fail){fail=false;return Response.json({message:'Try again'},{status:500});}return Response.json({file:{id,name:file.name,size:file.size,mime:file.type,uploadedAt:'2026-11-01T00:00:00Z',uploadedBy:'User'}})};
  await assert.rejects(()=>uploadTaskAttachments(S.taskDraft),/Try again/);const result=await uploadTaskAttachments(S.taskDraft);assert.equal(result.length,2);assert.deepEqual(calls.map(c=>c.name),['a.txt','b.txt','b.txt']);assert.equal(calls[1].id,calls[2].id);
  finishTaskAttachments(S.taskDraft);assert.ok(!taskEditorModal(S.taskDraft).includes('a.txt'));
 }finally{globalThis.FormData=realFormData;globalThis.fetch=realFetch;S.teamBusy=false;finishTaskAttachments(S.taskDraft)}
});
