import test from 'node:test';import assert from 'node:assert/strict';
import {normalizeWebGoals,favoriteGoals,goalMetrics,favoriteGoalSnapshot,goalPreferenceKey} from '../../public/client/domain/web-goals.js';
import {bounceCount} from '../../public/client/domain/web-behavior.js';
import {webMetrics} from '../../public/client/domain/analytics.js';
import {webDailySeries} from '../../public/client/domain/web-dashboard.js';
import {makePeriod} from '../../public/client/domain/dates.js';
import {normalizeWorkspace} from '../../public/client/data/remote.js';
import {buildReportContext,webReportSheets} from '../../public/client/domain/report.js';
import {faviconURLs,clientFavicon,installClientFavicons} from '../../public/client/ui/client-favicon.js';
const p=makePeriod('test','2026-10-05','2026-10-06');
const source={id:'ga4-one',provider:'ga4',state:'fresh',updated:'2026-10-09T00:00:00Z',days:[{date:p.from,sessions:100,engagedSessions:80},{date:p.to,sessions:300,engagedSessions:150}],goals:normalizeWebGoals([{id:'lead',name:'Form',kind:'lead',favorite:true,days:[{date:p.from,conversions:3,goalSessions:2},{date:p.to,conversions:8,goalSessions:6}]},{id:'wa',name:'WA click',kind:'whatsapp',favorite:true,days:[{date:p.from,conversions:0,goalSessions:0},{date:p.to,conversions:0,goalSessions:0}]},{id:'call',name:'Phone click',kind:'call',favorite:false,days:[]},{id:'page',name:'Page view',kind:'other',favorite:true,days:[]}])};
test('GA4 bounce counts derive from non-engaged sessions and remain weighted; Metrika never uses this fallback',()=>{
 assert.equal(bounceCount({sessions:100,engagedSessions:80},'ga4'),20);assert.equal(bounceCount({sessions:100,engagedSessions:80},'metrika'),null);assert.equal(bounceCount({sessions:100,engagedSessions:200},'ga4'),null);assert.equal(bounceCount({sessions:100,bounces:120},'ga4'),null);
 const m=webMetrics(source,p);assert.equal(m.bounces,170);assert.equal(m.bounceRate,42.5);assert.deepEqual(webDailySeries(source,p).map(r=>r.bounceRate),[20,50]);assert.equal(webMetrics({...source,days:[{date:p.from,sessions:100}]},p).bounceRate,null);
});
test('favorites use explicit choices, preserve measured zero and never infer a missing goal from a total',()=>{
 assert.deepEqual(favoriteGoals(source).map(g=>g.id),['lead','wa']);assert.deepEqual(favoriteGoals({...source,favoriteGoals:[]}),[]);
 const selected=favoriteGoalSnapshot(source,p);assert.equal(selected[0].current.conversions,11);assert.equal(selected[0].current.cr,2);assert.equal(selected[1].current.conversions,0);assert.equal(selected[1].current.complete,true);
 const missing=favoriteGoalSnapshot({...source,favoriteGoals:[{id:'missing',name:'Missing goal',kind:'call'}]},p)[0];assert.equal(missing.available,false);assert.equal(missing.current.conversions,null);assert.equal(missing.current.cr,null);
 const gap=goalMetrics(source,{days:source.goals[0].days.slice(0,1)},p);assert.equal(gap.complete,false);assert.equal(gap.conversions,3);assert.equal(gap.cr,null);
 const bad=goalMetrics(source,{days:[{date:p.from,goalSessions:101,conversions:2},{date:p.to,goalSessions:2,conversions:2}]},p);assert.equal(bad.cr,null);
});
test('goals normalize identities and reject duplicates, invalid dates and negative counts',()=>{
 assert.deepEqual(normalizeWebGoals(null),[]);assert.equal(normalizeWebGoals([{id:1,name:'Goal',days:[]}])[0].id,'1');
 for(const value of [[{id:'a',name:'A',days:[{date:'2026-02-30',conversions:1}]}],[{id:'a',name:'A',days:[{date:p.from,conversions:-1}]}],[{id:'a',name:'A'},{id:'a',name:'B'}],[{id:'a',name:'A',days:[{date:p.from,conversions:0},{date:p.from,conversions:1}]}]])assert.throws(()=>normalizeWebGoals(value));
 const normalized=normalizeWorkspace({clients:[{id:'test',name:'Test',analytics:[source]}]})[0];assert.equal(normalized.analytics[0].goals[0].id,'lead');
 const report=buildReportContext({...normalized,sales:[],previous:[]},p,[],[],{},null);assert.equal(report.analytics[0].favoriteConversions.length,2);const sheet=webReportSheets(report)['Избранные конверсии'];assert.equal(sheet[1][7],11);assert.equal(sheet[3][7],0);
 assert.notEqual(goalPreferenceKey({id:'x',dataOrigin:'database'}),goalPreferenceKey({id:'x'}));
});
test('favicons use the client site safely, with an independent image fallback',()=>{
 assert.equal(faviconURLs('mebel.kz').direct,'https://mebel.kz/favicon.ico');for(const site of ['javascript:alert(1)','https://user:pass@example.com','http://127.0.0.1','https://localhost',''])assert.equal(faviconURLs(site),null);
 const html=clientFavicon({site:'example.kz',name:'<script>unsafe</script>',initials:'X'});assert.match(html,/favicon.ico/);assert.match(html,/referrerpolicy="no-referrer"/);assert.ok(!html.includes('<script>'));
 const previous=globalThis.document,handlers={};globalThis.document={addEventListener(name,fn){handlers[name]=fn}};installClientFavicons();const initials={hidden:false};const img={hidden:true,src:'site',dataset:{faviconFallback:'fallback'},matches(){return true},parentElement:{querySelector(){return initials},classList:{add(){},remove(){}}}};
 handlers.error({target:img});assert.equal(img.src,'fallback');assert.equal(img.dataset.faviconFallback,undefined);handlers.load({target:img});assert.equal(img.hidden,false);assert.equal(initials.hidden,true);handlers.error({target:img});assert.equal(img.hidden,true);assert.equal(initials.hidden,false);globalThis.document=previous;
});
test('USD demonstration accounts rescale every monetary field and retain counts; live currency is never overridden',async()=>{
 const {demoClients}=await import('../../public/client/data/demo.js');const c=demoClients.find(c=>c.id==='mebel'),google=c.accounts.find(a=>a.platform==='google');assert.equal(google.currency,'USD');assert.equal(google.days.reduce((n,d)=>n+d.spend,0),1232);assert.equal(google.balance,277.2);assert.equal(google.days.reduce((n,d)=>n+d.clicks,0),3422);
 const tiktok=demoClients.find(c=>c.id==='mrt').accounts.find(a=>a.platform==='tiktok');assert.equal(tiktok.currency,'USD');assert.equal(tiktok.balance,520);assert.equal(tiktok.plan,3000);assert.equal(tiktok.dailyBudget,61.33);assert.ok(Math.abs(tiktok.days.reduce((n,d)=>n+d.spend,0)-319.98)<.001);assert.ok(Math.abs(tiktok.history.reduce((n,d)=>n+d.spend,0)-291.3)<.001);assert.equal(tiktok.days.reduce((n,d)=>n+d.clicks,0),889);
 const live=normalizeWorkspace({clients:[{id:'live',name:'Live',accounts:[{id:'g',platform:'google',currency:'KZT',days:[{date:p.from,spend:77000}]}]}]})[0];assert.equal(live.accounts[0].currency,'KZT');assert.equal(live.accounts[0].days[0].spend,77000);
});
