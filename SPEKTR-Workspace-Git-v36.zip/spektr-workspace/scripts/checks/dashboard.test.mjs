import test from 'node:test';
import assert from 'node:assert/strict';
import {accountSnapshot,accountURL,validAccountURL,dailySeries,spendByCurrency} from '../../public/client/domain/dashboard.js';
import {makePeriod} from '../../public/client/domain/dates.js';
import {currencyMoney} from '../../public/client/ui/components.js';
const p=makePeriod('week','2026-10-05','2026-10-11');
const rows=(from,spend)=>Array.from({length:7},(_,i)=>({date:new Date(Date.parse(from)+86400000*i).toISOString().slice(0,10),spend,clicks:100,impressions:1000,conversions:10}));
const account={id:'one',platform:'google',currency:'KZT',name:'Search KZ',state:'fresh',updated:'2026-10-12T05:00:00Z',asOf:'2026-10-12T05:00:00Z',balance:100000,payment:'prepay',days:rows('2026-10-05',200),history:rows('2026-09-28',100)};
const reference=Date.parse('2026-10-12T06:00:00Z');
test('channel diagnostics require complete comparable periods, enough results and fresh data',()=>{
 const s=accountSnapshot(account,p,{budgetDays:3,cpaPercent:30,minResults:5},reference);
 assert.equal(s.comparable,true);assert.equal(s.priceChange,100);assert.equal(s.tone,'critical');
 assert.equal(s.current.cr,10);assert.equal(s.current.cpa,20);
 const partial=accountSnapshot({...account,history:account.history.slice(1)},p,{},reference);
 assert.equal(partial.comparable,false);assert.equal(partial.priceChange,null);
 const stale=accountSnapshot(account,p,{},reference+48*3600000);assert.equal(stale.fresh,false);assert.equal(stale.priceChange,null);
 const sparse=accountSnapshot(account,p,{minResults:100},reference);assert.equal(sparse.priceChange,null);
});
test('daily charts preserve missing days separately from recorded zeros',()=>{
 const a=structuredClone(account);a.days[1].spend=0;a.days.splice(2,1);
 const series=dailySeries(a,p);assert.equal(series.length,7);assert.equal(series[1].value,0);assert.equal(series[2].value,null);
});
test('currency totals cannot combine USD and KZT or turn missing account data into zero',()=>{
 const totals=spendByCurrency([account,{...account,currency:'USD',days:[],history:[]}],p);
 assert.deepEqual(totals.map(r=>[r.currency,r.value,r.partial]),[['KZT',1400,false],['USD',null,true]]);
 assert.match(currencyMoney(.47,'USD'),/0,47/);
});
test('cabinet links are explicit and constrained to the corresponding advertising service',()=>{
 assert.equal(accountURL(account),null);
 assert.equal(validAccountURL('https://ads.google.com/aw/campaigns?ocid=123','google'),'https://ads.google.com/aw/campaigns?ocid=123');
 for(const link of ['javascript:alert(1)','https://ads.google.com.attacker.test/','https://user:password@ads.google.com/','https://ads.google.com:444/','https://business.facebook.com/'])assert.equal(validAccountURL(link,'google'),null);
 assert.equal(validAccountURL('https://direct.yandex.ru/','yandex'),'https://direct.yandex.ru/');
});
