import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import ts from 'typescript';
import {attachmentReferencesOK,TASK_FILE_MAX_BYTES} from '../../public/client/domain/task-files.js';
const db=new DatabaseSync(':memory:');db.exec(readFileSync('drizzle/0000_clear_microchip.sql','utf8'));
const objects=new Map();let writes=0;
globalThis.__taskFilesEnv={DB:{prepare(sql){let args=[];return {bind(...values){args=values;return this},async first(){return db.prepare(sql).get(...args)||null},async all(){return {results:db.prepare(sql).all(...args)}},async run(){return db.prepare(sql).run(...args)}}}},BUCKET:{async put(key,bytes){writes++;objects.set(key,new Uint8Array(bytes))},async get(key){const bytes=objects.get(key);return bytes?{body:new Response(bytes).body}:null}}};
async function moduleFrom(path,replacements=[]){let code=readFileSync(path,'utf8');for(const [a,b] of replacements)code=code.replace(a,b);code=code.replace(/from ['"](\.\.?\/[^'"]+\.js)['"]/g,(_,rel)=>`from '${new URL(rel,new URL('../../'+path,import.meta.url)).href}'`);return import('data:text/javascript;base64,'+Buffer.from(ts.transpileModule(code,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText).toString('base64'));}
const team=await moduleFrom('server/team.ts',[["import { env } from 'cloudflare:workers';",'const env=globalThis.__taskFilesEnv;']]);globalThis.__taskFileActor=team.actor;
const files=await moduleFrom('server/task-files.ts',[["import {env} from 'cloudflare:workers';",'const env=globalThis.__taskFilesEnv;'],["import {actor} from './team';",'const actor=globalThis.__taskFileActor;']]);
const id='a1234567-1234-4123-8123-123456789abc';
const headers=user=>({'oai-authenticated-user-id':user,'oai-authenticated-user-full-name':user,Origin:'https://workspace.test'});
const upload=(text='sample content',name='Макет объявления.txt',user='owner',fileId=id)=>{const body=new FormData();body.set('id',fileId);body.set('taskId','task-one');body.set('clientId','client-one');body.set('file',new File([text],name,{type:'text/plain'}));return new Request('https://workspace.test/api/task-files',{method:'POST',headers:headers(user),body})};
const download=user=>new Request('https://workspace.test/api/task-files?id='+id,{headers:headers(user)});
const task={id:'task-one',client:'client-one',title:'Inspect Ads',assignee:'Manager',due:'2026-11-02',status:'todo',repeat:'none'};
test('uploads persist in object storage, retries are idempotent and draft files are private to their uploader',async()=>{
 const result=await files.uploadTaskFile(upload());assert.equal(result.file.name,'Макет объявления.txt');assert.equal(result.file.size,14);assert.equal(objects.size,1);
 const again=await files.uploadTaskFile(upload());assert.deepEqual(again,result);assert.equal(writes,1);
 await assert.rejects(()=>files.uploadTaskFile(upload('different bytes')),/ID вложения/);assert.equal(objects.size,1);
 const response=await files.downloadTaskFile(download('owner'));assert.equal(await response.text(),'sample content');assert.match(response.headers.get('Content-Disposition'),/^attachment;/);assert.equal(response.headers.get('X-Content-Type-Options'),'nosniff');assert.equal(response.headers.get('Content-Type'),'application/octet-stream');
 await assert.rejects(()=>files.downloadTaskFile(download('another-user')),/ещё не сохранено/);
 await assert.rejects(()=>files.downloadTaskFile(new Request('https://workspace.test/api/task-files?id='+id)),/Войдите/);
});
test('task save validates ownership and replaces user-supplied file metadata with server metadata; teammates can download after save',async()=>{
 await assert.rejects(()=>team.saveTeam(download('owner'),{key:'task.other',value:{...task,id:'other',attachments:[{id,name:'x',size:0}]},revision:0}),/не относится/);
 const saved=await team.saveTeam(download('owner'),{key:'task.task-one',value:{...task,attachments:[{id,name:'forged name.html',size:0}]},revision:0});assert.equal(saved.item.value.attachments[0].name,'Макет объявления.txt');assert.equal(saved.item.value.attachments[0].size,14);assert.ok(!('key' in saved.item.value.attachments[0]));
 assert.equal(await (await files.downloadTaskFile(download('another-user'))).text(),'sample content');
 const shared=await team.readTeam(download('another-user'));assert.ok(!shared.items.some(item=>item.key.startsWith('taskFile.')));assert.ok(shared.items.some(item=>item.key==='task.task-one'));
 assert.throws(()=>team.validateRecord('taskFile.'+id,{id},0),/Неподдерживаемая/);
});
test('file limits reject oversize bodies, duplicate IDs and excessive task payloads',async()=>{
 const req=new Request('https://workspace.test/api/task-files',{method:'POST',headers:{...headers('owner'),'content-length':String(TASK_FILE_MAX_BYTES+100000),'content-type':'multipart/form-data; boundary=test'},body:'x'});await assert.rejects(()=>files.uploadTaskFile(req),error=>error.status===413);
 assert.equal(attachmentReferencesOK([{id,name:'A',size:1},{id,name:'B',size:1}]),false);assert.equal(attachmentReferencesOK([{id,name:'A',size:TASK_FILE_MAX_BYTES+1}]),false);assert.equal(attachmentReferencesOK([{id,name:'A',size:0}]),true);
 const original=globalThis.__taskFilesEnv.BUCKET;globalThis.__taskFilesEnv.BUCKET=undefined;try{await assert.rejects(()=>files.downloadTaskFile(download('owner')),error=>error.status===503)}finally{globalThis.__taskFilesEnv.BUCKET=original}
});
