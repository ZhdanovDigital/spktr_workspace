import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import ts from 'typescript';
import {attachShared} from '../../public/client/data/shared.js';

const db=new DatabaseSync(':memory:');
db.exec(readFileSync(new URL('../../drizzle/0000_clear_microchip.sql',import.meta.url),'utf8'));
globalThis.__teamTestEnv={DB:{prepare(sql){let args=[];return {bind(...values){args=values;return this},async first(){return db.prepare(sql).get(...args)||null},async all(){return {results:db.prepare(sql).all(...args)}},async run(){return db.prepare(sql).run(...args)}}}}};
async function sourceModule(path,replacements=[]){let text=readFileSync(new URL(path,import.meta.url),'utf8');for(const [a,b] of replacements)text=text.replace(a,b);text=text.replace(/from ['"](\.\.?\/[^'"]+\.js)['"]/g,(_,rel)=>`from '${new URL(rel,new URL(path,import.meta.url)).href}'`);const output=ts.transpileModule(text,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;return import('data:text/javascript;base64,'+Buffer.from(output).toString('base64'));}
const team=await sourceModule('../../server/team.ts',[["import { env } from 'cloudflare:workers';",'const env=globalThis.__teamTestEnv;']]);
const security=await sourceModule('../../server/security.ts');
globalThis.__securityFunctions=security;
const metabase=await sourceModule('../../server/metabase.ts',[["import { env } from 'cloudflare:workers';",'const env=globalThis.__teamTestEnv;'],["import { safeEndpoint } from './security';",'const {safeEndpoint}=globalThis.__securityFunctions;']]);
class MemoryStorage {data=new Map();get length(){return this.data.size}getItem(k){return this.data.get(k)??null}setItem(k,v){this.data.set(k,String(v))}removeItem(k){this.data.delete(k)}key(i){return [...this.data.keys()][i]??null}}
globalThis.localStorage=new MemoryStorage();globalThis.window={dispatchEvent(){}};globalThis.CustomEvent=class {constructor(name){this.type=name}};
const req=(path='/api/team',method='GET',input)=>new Request('https://workspace.test'+path,{method,headers:{'oai-authenticated-user-id':'verified-user','oai-authenticated-user-email':'user@example.test',Origin:'https://workspace.test','Content-Type':'application/json'},...(input?{body:JSON.stringify(input)}:{})});
let failMode='';
globalThis.fetch=async(path,init={})=>{if(failMode==='before'){failMode='';throw new Error('network interrupted')}const request=req(path,init.method||'GET',init.body?JSON.parse(init.body):undefined);security.authorize(request);const data=init.method==='POST'?await team.saveTeam(request,JSON.parse(init.body)):await team.readTeam(request);if(failMode==='after'){failMode='';throw new Error('lost response')}return Response.json(data,{status:data.conflict?409:200})};
function repository(){const r={runtime:{},read(key,fallback){try{return JSON.parse(localStorage.getItem('spektr.workspace.v1.'+key))??structuredClone(fallback)}catch{return structuredClone(fallback)}},write(key,value){localStorage.setItem('spektr.workspace.v1.'+key,JSON.stringify(value))}};attachShared(r);return r;}
const task={id:'task-one',client:'client-one',title:'Проверить рекламу',assignee:'Менеджер',due:'2026-10-12',status:'todo',repeat:'weekly'};

test('persistent writes, verified actor attribution, and stale edit protection',async()=>{
  const a=repository();await a.loadShared();const saved=await a.saveEntity('task',task);assert.equal(saved.revision,1);assert.equal(saved.serverMeta.author,'user@example.test');
  const b=repository();await b.loadShared();await a.saveEntity('task',{...task,status:'progress'});
  await assert.rejects(()=>b.saveEntity('task',{...task,title:'Stale title'}),/Другой участник/);
  const raw=JSON.parse(db.prepare('SELECT value_json FROM workspace_records WHERE key=?').get('task.task-one').value_json);
  assert.equal(raw.status,'progress');assert.equal(raw.title,task.title);assert.ok(b.sharedConflicts.has('task.task-one'));
});
test('pending drafts survive reload, and retries cannot overwrite newer server records',async()=>{
  const a=repository();await a.loadShared();failMode='before';await assert.rejects(()=>a.persist('settings.network',{budgetDays:3}));
  const restarted=repository();assert.ok(restarted.sharedFailed.has('settings.network'));await restarted.loadShared();
  await team.saveTeam(req(),{key:'settings.network',value:{budgetDays:7},revision:0});
  await assert.rejects(()=>restarted.retryFailed(),/Другой участник/);assert.equal(JSON.parse(db.prepare('SELECT value_json FROM workspace_records WHERE key=?').get('settings.network').value_json).budgetDays,7);
});
test('lost acknowledgements are reconciled idempotently without duplicate records',async()=>{
  const a=repository();await a.loadShared();failMode='after';await assert.rejects(()=>a.persist('settings.ack',{budgetDays:4}));
  // Retry only this draft because other test cases intentionally retain conflicts.
  const draft=a.sharedFailed.get('settings.ack');await a.persist('settings.ack',draft.value,draft.baseRevision);
  assert.equal(a.sharedRecords.get('settings.ack').revision,1);assert.equal(a.sharedFailed.has('settings.ack'),false);assert.equal(a.sharedConflicts.has('settings.ack'),false);
});
test('rapid changes are queued and the final value is retained',async()=>{
  const a=repository();await a.loadShared();a.write('settings.rapid',{budgetDays:3});a.write('settings.rapid',{budgetDays:9});await Promise.all([...a.sharedQueues.values()]);
  const raw=db.prepare('SELECT revision,value_json FROM workspace_records WHERE key=?').get('settings.rapid');assert.equal(raw.revision,2);assert.equal(JSON.parse(raw.value_json).budgetDays,9);
});
test('writes reject credentials, ID mismatches, and requests without the correct origin',async()=>{
  assert.throws(()=>team.validateRecord('ai.config',{apiKey:'not-a-real-key'},0),/Секреты/);
  assert.throws(()=>team.validateRecord('task.task-two',task,0),/ID записи/);
  assert.throws(()=>security.authorize(new Request('https://workspace.test/api/team',{method:'POST',headers:{'oai-authenticated-user-id':'user',Origin:'https://other.test'}})),/этого сайта/);
  assert.throws(()=>team.actor(new Request('https://workspace.test')),/Войдите/);
  assert.throws(()=>team.validateRecord('task.task-one',{...task,kind:'review',status:'done',checks:[true]},0),/чеклиста/);
  assert.throws(()=>team.validateRecord('log.invalid',{id:'invalid',client:'client-one',text:'Change',date:'2026-02-30'},0),/дату/);
  assert.doesNotThrow(()=>team.validateRecord('settings.agency/client:one',{budgetDays:7},0));
});

test('review status, subtasks and comments persist together and malformed task additions are rejected',async()=>{
 const value={...task,id:'task-review-fields',status:'review',repeat:'none',subtasks:[{id:'s1',title:'Проверить цели',done:false}],comments:[{id:'c1',text:'Проверить WhatsApp',author:'Участник',at:'2026-10-31T10:00:00Z'}]};
 const a=repository();await a.loadShared();await a.saveEntity('task',value);const b=repository();await b.loadShared();assert.deepEqual(b.sharedRecords.get('task.task-review-fields').value,value);
 assert.throws(()=>team.validateRecord('task.task-review-fields',{...value,subtasks:[{id:'s',title:'Bad',done:'yes'}]},0),/подзадач/);
 assert.throws(()=>team.validateRecord('task.task-review-fields',{...value,comments:[{id:'c',text:'Bad',author:'User',at:'not-date'}]},0),/комментарии/);
 assert.doesNotThrow(()=>team.validateRecord('settings.exchange',{mode:'manual',rates:{USD:500},asOf:'2026-10-31'},0));
 assert.throws(()=>team.validateRecord('settings.exchange',{mode:'manual',rates:{USD:-1},asOf:'2026-10-31'},0),/курс/);
});
test('Metabase signs only the dashboard bound to a client and keeps the signing secret server-side',async()=>{
  await team.saveTeam(req(),{key:'metabase.client-one',value:{dashboardId:4,parameterName:'client_id',clientValue:'client-one'},revision:0});
  process.env.METABASE_URL='https://metabase.example.test';process.env.METABASE_EMBED_SECRET='test-secret-not-for-production';
  const result=await metabase.metabaseToken('client-one',4);const [head,payload,signature]=result.jwt.split('.');const decoded=JSON.parse(Buffer.from(payload,'base64url'));
  assert.deepEqual(decoded.resource,{dashboard:4});assert.deepEqual(decoded.params,{client_id:'client-one'});assert.ok(decoded.exp>Date.now()/1000);
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(process.env.METABASE_EMBED_SECRET),{name:'HMAC',hash:'SHA-256'},false,['verify']);
  assert.ok(await crypto.subtle.verify('HMAC',key,Buffer.from(signature,'base64url'),new TextEncoder().encode(head+'.'+payload)));
  await assert.rejects(()=>metabase.metabaseToken('client-one',999),/не совпадает/);assert.ok(!JSON.stringify(result).includes(process.env.METABASE_EMBED_SECRET));
  delete process.env.METABASE_URL;delete process.env.METABASE_EMBED_SECRET;
});

test('only the verified owner can bind the admin identity and save client assignments',async()=>{
 const assignment={clientId:'client-one',origin:'database',manager:'Мадина',accountLinks:{google:'https://ads.google.com/aw/campaigns?ocid=123'}};
 await assert.rejects(()=>team.saveTeam(req(),{key:'clientConfig.database.client-one',value:{...assignment,role:'admin'},revision:0}),/Только администратор/);
 const ownerRequest=(id,email)=>new Request('https://workspace.test/api/team',{headers:{'oai-authenticated-user-id':id,'oai-authenticated-user-email':email}});
 const owner=ownerRequest('site-owner-identity','zhdanov.roman91@gmail.com');
 assert.equal((await team.workspacePermissions(owner)).manageClients,true);
 const saved=await team.saveTeam(owner,{key:'clientConfig.database.client-one',value:assignment,revision:0});
 assert.equal(saved.item.value.manager,'Мадина');assert.equal(saved.item.meta.authorId,'site-owner-identity');
 assert.equal((await team.workspacePermissions(ownerRequest('site-owner-identity','changed@example.test'))).manageClients,true);
 assert.equal((await team.workspacePermissions(ownerRequest('different-identity','zhdanov.roman91@gmail.com'))).manageClients,false);
 assert.throws(()=>team.validateRecord('access.owner',{userId:'different-identity'},1),/Неподдерживаемая/);
 assert.throws(()=>team.validateRecord('clientConfig.database.other',assignment,0),/карточка/);
 assert.throws(()=>team.validateRecord('clientConfig.database.client-one',{...assignment,accountLinks:{google:'https://ads.google.com.attacker.test/'}},0),/HTTPS/);
 const fresh=repository();await fresh.loadShared();assert.equal(fresh.read('clientConfig.database.client-one',{}).manager,'Мадина');assert.equal(fresh.sharedUser.permissions.manageClients,false);
});

test('budget plans persist across team sessions, validate server-side and protect captured revisions',async()=>{
 const value={client:'client-one',origin:'database',from:'2026-10-01',to:'2026-10-31',source:'paid',note:'Рекламный бюджет',amounts:[{currency:'KZT',amount:500000}]},key='budgetPlan.database.client-one.2026-10-01.2026-10-31';
 const a=repository();await a.loadShared();await a.persist(key,value,0);const b=repository();await b.loadShared();assert.equal(b.sharedList('budgetPlan').find(p=>p.client===value.client).amounts[0].amount,500000);
 const revision=b.sharedRecords.get(key).revision;await a.persist(key,{...value,note:'Обновлено'},1);await assert.rejects(()=>b.persist(key,{...value,amounts:[{currency:'KZT',amount:600000}]},revision),/Другой участник/);
 assert.equal(JSON.parse(db.prepare('SELECT value_json FROM workspace_records WHERE key=?').get(key).value_json).note,'Обновлено');
 for(const patch of [{client:'wrong-client'},{from:'2026-02-30'},{source:'other'},{amounts:[{currency:'USD',amount:-1}]},{amounts:[{currency:'USD',amount:1},{currency:'USD',amount:2}]},{amounts:[{currency:'KZT',amount:1.234}]}])assert.throws(()=>team.validateRecord(key,{...value,...patch},1));
});

test('favorite goal preferences are shared per client/source, validate types and cannot overwrite stale edits',async()=>{
 const key='analytics.config.favorites.database.goal-client',value={clientId:'goal-client',origin:'database',sources:[{provider:'ga4',sourceId:'counter-1',goals:[{id:'form',name:'Form submit',kind:'lead'}]}]};
 const a=repository();await a.loadShared();const saved=await a.persist(key,value,0);assert.equal(saved.revision,1);
 const b=repository();await b.loadShared();assert.deepEqual(b.read(key,null).sources[0].goals[0],value.sources[0].goals[0]);
 await a.persist(key,{...value,sources:[{...value.sources[0],goals:[]}]},1);await assert.rejects(()=>b.persist(key,value,1),/Другой участник/);
 for(const patch of [{origin:'wrong'},{clientId:'another-client'},{sources:[{provider:'unknown',sourceId:'counter',goals:[]}]},{sources:[{provider:'ga4',sourceId:'c',goals:[{id:'a',name:'A',kind:'other'}]}]},{sources:[{provider:'ga4',sourceId:'c',goals:[{id:'a',name:'A',kind:'lead'},{id:'a',name:'Again',kind:'call'}]}]}])assert.throws(()=>team.validateRecord(key,{...value,...patch},1));
});

test('client folders persist for the team, remain isolated by client and origin, and reject stale edits',async()=>{
 const key='clientFolders.database.folder-client',value={clientId:'folder-client',origin:'database',links:{general:'https://drive.google.com/drive/folders/GENERAL_fixture?usp=sharing',digital:'https://drive.google.com/drive/u/0/folders/DIGITAL_fixture?resourcekey=fixture-key'}};
 const a=repository();await a.loadShared();await a.persist(key,value,0);const b=repository();await b.loadShared();assert.deepEqual(b.read(key,null).links,value.links);
 await a.persist(key,{...value,links:{...value.links,digital:'https://drive.google.com/drive/folders/DIGITAL_new'}},1);await assert.rejects(()=>b.persist(key,{...value,links:{}},1),/Другой участник/);const saved=JSON.parse(db.prepare('SELECT value_json FROM workspace_records WHERE key=?').get(key).value_json);assert.equal(saved.links.digital,'https://drive.google.com/drive/folders/DIGITAL_new');assert.equal(saved.links.general,value.links.general);
 await team.saveTeam(req(),{key:'clientFolders.demonstration.folder-client',value:{...value,origin:'demonstration',links:{}},revision:0});assert.deepEqual(JSON.parse(db.prepare('SELECT value_json FROM workspace_records WHERE key=?').get(key).value_json),saved);
 await team.saveTeam(req(),{key,value:{...saved,links:{digital:saved.links.digital}},revision:2});assert.equal(JSON.parse(db.prepare('SELECT value_json FROM workspace_records WHERE key=?').get(key).value_json).links.general,undefined);
});
test('client folder validation accepts Drive folders only and prevents cross-client writes',()=>{
 const key='clientFolders.database.safe-client',value={clientId:'safe-client',origin:'database',links:{}};
 for(const bad of ['javascript:alert(1)','https://drive.google.com.attacker.test/drive/folders/abc','https://user:pass@drive.google.com/drive/folders/abc','https://drive.google.com/file/d/abc/view','https://docs.google.com/document/d/abc/edit','http://drive.google.com/drive/folders/abc'])assert.throws(()=>team.validateRecord(key,{...value,links:{general:bad}},0),/HTTPS/);
 assert.throws(()=>team.validateRecord(key,{...value,clientId:'other-client'},0),/папки/);assert.throws(()=>team.validateRecord(key,{...value,links:{unexpected:'https://drive.google.com/drive/folders/abc'}},0),/папки/);assert.doesNotThrow(()=>team.validateRecord(key,{...value,links:{general:'https://drive.google.com/drive/folders/abc_123-456?resourcekey=0-test'}},0));
});

test('media footnote templates persist independently for the team and protect captured revisions',async()=>{
 const a=repository();await a.loadShared();const v={id:'standard',name:'Стандартная сноска',content:'Прогноз не гарантирует результат.',active:true};
 await a.persist('mediaFootnote.standard',v,0);const b=repository();await b.loadShared();assert.equal(b.sharedList('mediaFootnote')[0].content,v.content);
 await a.persist('mediaFootnote.another',{...v,id:'another',name:'Другой шаблон'},0);await a.persist('mediaFootnote.standard',{...v,content:'Обновлённые условия'},1);
 await assert.rejects(()=>b.persist('mediaFootnote.standard',{...v,content:'Устаревший текст'},1),/Другой участник/);
 assert.throws(()=>team.validateRecord('mediaFootnote.wrong',v,0),/ID/);assert.throws(()=>team.validateRecord('mediaFootnote.standard',{...v,content:''},0),/текст/);
});
