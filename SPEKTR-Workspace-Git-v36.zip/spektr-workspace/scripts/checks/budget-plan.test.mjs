import test from 'node:test';
import assert from 'node:assert/strict';
import {budgetKey,validateBudgetPlan,budgetProgress,matchingBudget} from '../../public/client/domain/budget-plan.js';
const plan={client:'a/b',origin:'database',from:'2026-10-01',to:'2026-10-03',source:'paid',note:'Оплата',amounts:[{currency:'KZT',amount:100},{currency:'USD',amount:10}]};
const account=(currency,days,history=[])=>({currency,days,history});
const client={accounts:[account('KZT',[{date:'2026-10-01',spend:30},{date:'2026-10-02',spend:50},{date:'2026-10-03',spend:40}]),account('USD',[{date:'2026-10-01',spend:0},{date:'2026-10-02',spend:0},{date:'2026-10-03',spend:0}])]};
test('plan validation requires a real period, positive amounts and separate nonduplicated currencies',()=>{
 assert.equal(validateBudgetPlan(plan),plan);assert.equal(budgetKey(plan),'budgetPlan.database.a%2Fb.2026-10-01.2026-10-03');
 for(const patch of [{from:'2026-02-30'},{to:'2026-09-30'},{to:'2028-10-01'},{source:'__proto__'},{origin:'wrong'},{note:'x'.repeat(1001)},{amounts:[]},{amounts:[{currency:'KZT',amount:0}]},{amounts:[{currency:'KZT',amount:Infinity}]},{amounts:[{currency:'USD',amount:1.234}]},{amounts:[{currency:'KZT',amount:1},{currency:'KZT',amount:2}]}])assert.throws(()=>validateBudgetPlan({...plan,...patch}),JSON.stringify(patch));
});
test('budget totals preserve currencies, measured zero, and full saved-period spend',()=>{
 const [kzt,usd]=budgetProgress(client,plan,'2026-10-05');assert.equal(kzt.actual,120);assert.equal(kzt.remaining,-20);assert.equal(kzt.used,120);assert.equal(kzt.tone,'critical');assert.equal(kzt.complete,true);assert.equal(usd.actual,0);assert.equal(usd.remaining,10);assert.equal(usd.used,0);assert.equal(usd.complete,true);
});
test('coverage detects missing days and missing accounts without manufacturing zero spend',()=>{
 const c={accounts:[account('KZT',[{date:'2026-10-01',spend:20},{date:'2026-10-03',spend:50}]),account('KZT',[])]};const [kzt,usd]=budgetProgress(c,plan,'2026-10-06');assert.equal(kzt.actual,70);assert.equal(kzt.complete,false);assert.equal(kzt.tone,'neutral');assert.equal(usd.actual,null);assert.equal(usd.remaining,null);assert.equal(usd.complete,false);
 const missing=budgetProgress({accounts:[account('KZT',[{date:'2026-10-01',spend:null}])]},plan,'2026-10-06')[0];assert.equal(missing.actual,null);
});
test('known overspend is highlighted even with incomplete coverage; future rows do not count',()=>{
 const c={accounts:[account('KZT',[{date:'2026-10-01',spend:110},{date:'2026-10-03',spend:500}])]};const r=budgetProgress(c,plan,'2026-10-02')[0];assert.equal(r.actual,110);assert.equal(r.tone,'critical');assert.equal(r.complete,true);
 const before=budgetProgress(c,plan,'2026-09-30')[0];assert.equal(before.actual,0);assert.equal(before.notStarted,true);
});
test('daily records override their history duplicates and fractional amounts do not create false overspend',()=>{
 const c={accounts:[account('KZT',[{date:'2026-10-01',spend:.1},{date:'2026-10-02',spend:.2}],[{date:'2026-10-01',spend:40}])]};const r=budgetProgress(c,{...plan,to:'2026-10-02',amounts:[{currency:'KZT',amount:.3}]},'2026-10-05')[0];assert.equal(r.actual,.3);assert.equal(r.used,100);assert.notEqual(r.tone,'critical');
});
test('selected period resolves the closest containing budget and never applies a partial overlap',()=>{
 const month={...plan,from:'2026-10-01',to:'2026-10-31'},week={...plan,from:'2026-10-01',to:'2026-10-07'};assert.equal(matchingBudget([month,week],{from:'2026-10-02',to:'2026-10-03'}),week);assert.equal(matchingBudget([week],{from:'2026-10-07',to:'2026-10-08'}),null);assert.equal(matchingBudget([month],{from:'2026-11-01',to:'2026-11-02'}),null);
});
