const PREFIX='spektr.workspace.v1.';
const TRACKED=/^(mediaFootnote\.|budgetPlan\.|clientConfig\.|clientFolders\.|task\.|log\.|report\.|prompt\.|settings\.|ai\.(config|models)$|metabase\.|analytics\.config\.|revenue\.|keywords\.|ads\.|(database\.)?sales\.|integration\.|activePlan\.|plans$|customClients$|dataSource$)/;

export function attachShared(R) {
  R.sharedRecords=new Map(); R.sharedReady=false; R.sharedError=''; R.sharedPending=0;
  R.sharedConflicts=new Map(); R.sharedFailed=new Map(); R.sharedQueues=new Map();
  const localRead=R.read.bind(R), localWrite=R.write.bind(R);
  const cache=(key,value)=>{try{localWrite(key,value)}catch{}};
  const clearPending=key=>{try{localStorage.removeItem(PREFIX+'pending.'+key)}catch{}};
  try{for(let i=0;i<localStorage.length;i++){const rawKey=localStorage.key(i);if(!rawKey?.startsWith(PREFIX+'pending.'))continue;const key=rawKey.slice((PREFIX+'pending.').length),item=localRead('pending.'+key,null);if(item){R.sharedFailed.set(key,item);if(item.conflict)R.sharedConflicts.set(key,item.conflict);}}}catch{}
  const emit=()=>window.dispatchEvent(new CustomEvent('spektr:shared'));
  R.read=function(key,fallback){const row=this.sharedRecords.get(key);return row?structuredClone(row.value):localRead(key,fallback)};
  R.sharedList=function(prefix){return [...this.sharedRecords].filter(([key])=>key.startsWith(prefix+'.')).map(([,row])=>({...structuredClone(row.value),serverMeta:row.meta,revision:row.revision}));};
  R.loadShared=async function(){
    const fresh=new Map();let cursor='',user;
    for(let page=0;page<100;page++) {
      const response=await fetch('/api/team'+(cursor?'?cursor='+encodeURIComponent(cursor):''),{cache:'no-store'});
      const data=await response.json();if(!response.ok)throw new Error(data.message||'Командное хранилище недоступно');
      for(const item of data.items)fresh.set(item.key,item);user=data.user;
      if(!data.nextCursor)break;if(cursor===data.nextCursor)throw new Error('Хранилище повторяет страницу');cursor=data.nextCursor;
      if(page===99)throw new Error('Слишком много командных записей');
    }
    // Polling never discards a record that has a pending write or a local conflict.
    for(const [key] of this.sharedQueues)if(this.sharedRecords.has(key))fresh.set(key,this.sharedRecords.get(key));
    // Connector writes use a dedicated endpoint; an older poll must not roll them back.
    for(const [key,row] of this.sharedRecords)if(key.startsWith('integration.onec.')&&row.revision>(fresh.get(key)?.revision||0))fresh.set(key,row);
    this.sharedRecords=fresh;this.sharedReady=true;this.sharedUser=user;this.sharedError=this.sharedFailed.size?'Остались несохранённые записи. Откройте «Сохранение».':'';
    for(const [key,row] of fresh)try{localWrite(key,row.value)}catch{}
    emit();return fresh;
  };
  R.persist=async function(key,value,expectedRevision=null){
    if(!this.sharedReady)throw new Error('Командное хранилище недоступно. Дождитесь загрузки или обновите страницу.');
    if(this.sharedConflicts.has(key))throw new Error('Запись изменена другим участником. Откройте «Сохранение» и разрешите конфликт.');
    const previous=this.sharedQueues.get(key)||Promise.resolve();let attemptedRevision=expectedRevision;
    this.sharedPending++;emit();
    const queued=previous.catch(()=>{}).then(async()=>{
      if(this.sharedConflicts.has(key))throw new Error('Запись изменена другим участником; обновите её перед повторным сохранением.');
      const revision=expectedRevision??this.sharedRecords.get(key)?.revision??0;attemptedRevision=revision;
      const response=await fetch('/api/team',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,value,revision})});
      const data=await response.json();
      if(response.status===409){if(data.current&&JSON.stringify(data.current.value)===JSON.stringify(value)){this.sharedRecords.set(key,data.current);this.sharedFailed.delete(key);clearPending(key);cache(key,data.current.value);this.sharedError=this.sharedFailed.size?this.sharedError:'';return data.current;}this.sharedConflicts.set(key,{draft:value,current:data.current});if(data.current)this.sharedRecords.set(key,data.current);throw new Error('Другой участник изменил запись. Ваш вариант сохранён в разделе «Сохранение».');}
      if(!response.ok)throw new Error(data.message||'Не удалось сохранить в команде');
      this.sharedRecords.set(key,data.item);this.sharedFailed.delete(key);clearPending(key);cache(key,data.item.value);this.sharedError=this.sharedFailed.size?this.sharedError:'';return data.item;
    }).catch(err=>{this.sharedError=err.message;const failed={value,message:err.message,baseRevision:attemptedRevision,conflict:this.sharedConflicts.get(key)||null};this.sharedFailed.set(key,failed);try{localWrite('pending.'+key,failed)}catch{}throw err}).finally(()=>{
      this.sharedPending--;if(this.sharedQueues.get(key)===queued)this.sharedQueues.delete(key);emit();
    });
    this.sharedQueues.set(key,queued);queued.catch(()=>{});return queued;
  };
  R.write=function(key,value){if(TRACKED.test(key)){cache(key,value);if(!this.sharedReady){const failed={value,message:'Командное хранилище недоступно',baseRevision:null};this.sharedFailed.set(key,failed);cache('pending.'+key,failed);this.sharedError='Изменения пока сохранены только на этом устройстве';emit();}else{this.sharedRecords.set(key,{...this.sharedRecords.get(key),key,value:structuredClone(value),revision:this.sharedRecords.get(key)?.revision||0});this.persist(key,structuredClone(value)).catch(()=>{});}}else localWrite(key,value);return true;};
  R.flush=async function(){await Promise.all([...this.sharedQueues.values()]);if(this.sharedFailed.size)throw new Error(this.sharedError||'Есть несохранённые командные записи');};
  R.saveEntity=async function(kind,value){const {serverMeta,revision,...clean}=value;const key=kind+'.'+clean.id;const item=await this.persist(key,clean);return {...item.value,serverMeta:item.meta,revision:item.revision};};
  R.logs=function(client){const all=this.sharedList('log');const legacy=localRead('logs',this.runtime.database||this.read('dataSource',{}).enabled?[]:[]);const byId=new Map(legacy.map(l=>[l.id,l]));for(const l of all)byId.set(l.id,l);return [...byId.values()].filter(l=>l.client===client&&(!l.origin||l.origin===(this.runtime.database||this.read('dataSource',{}).enabled?'database':'demonstration'))).sort((a,b)=>b.date.localeCompare(a.date));};
  R.saveLog=function(log){return this.saveEntity('log',{...log,origin:this.runtime.database||this.read('dataSource',{}).enabled?'database':'demonstration'});};
  R.reports=function(){const legacy=localRead('reports',[]);const byId=new Map(legacy.map(r=>[r.id,r]));for(const r of this.sharedList('report'))byId.set(r.id,r);return [...byId.values()].sort((a,b)=>(b.updated||'').localeCompare(a.updated||''));};
  R.saveReport=function(report){return this.saveEntity('report',report);};
  R.tasks=function(){const origin=this.runtime.database||this.read('dataSource',{}).enabled?'database':'demonstration';return this.sharedList('task').filter(t=>!t.origin||t.origin===origin);};
  R.prompts=function(){return this.sharedList('prompt').filter(p=>p.active!==false);};
  R.retryFailed=async function(){for(const [key,item] of [...this.sharedFailed]){if(!this.sharedConflicts.has(key))await this.persist(key,item.value,item.baseRevision);}};
  R.exportLocalDrafts=function(){const data={};for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(key?.startsWith(PREFIX))data[key.slice(PREFIX.length)]=localStorage.getItem(key);}return data;};
}
