export type SourceState='loading'|'fresh'|'stale'|'partial'|'error'|'empty'|'unavailable'|'never';
export type Platform='google'|'yandex'|'meta'|'tiktok';
export interface Client {id:string;name:string;site:string;manager:string;sector:string;initials:string;accounts:AdAccount[];sales:ClientSalesData[];previous:ClientSalesData[];targets:{ctr:number;cr:number;cpl:number;cpa:number};monthly:number;}
export interface AdAccount {id:string;platform:Platform;name:string;currency:string;state:SourceState;updated:string;balance:number|null;payment:'prepay'|'postpay';limit:number|null;dailyBudget:number;plan:number;days:DailyMetrics[];history:DailyMetrics[];campaigns:Campaign[];}
export interface DailyMetrics {date:string;spend:number;impressions:number;clicks:number;conversions:number;}
export interface Campaign {id:string;name:string;goal:string;weight:number;}
export interface ClientSalesData {date:string;source:string;leads:number;qualified:number;poor:number;unrated:number;sales:number;revenue:number;attributed:boolean;comment?:string;}
export interface ClientMetrics {spend:number;leads:number|null;qualified:number|null;sales:number|null;revenue:number|null;ctr:number|null;cr:number|null;cpl:number|null;cpa:number|null;roas:number|null;drr:number|null;}
export interface MediaFootnote {templateId:string;name:string;content:string;}
export interface MediaPlan {id:string;client:string;month:string;budget:number;finance?:{topupRate:number;vatRate:number;agencyGross:number};footnote?:MediaFootnote|null;scenario:string;rows:MediaPlanRow[];savedAt:string;}
export interface MediaPlanRow {platform:Platform;share:number;mode:'cpc'|'cpm';cpc:number;cpm:number;ctr:number;cr:number;saleCR:number;check:number;}
export interface BudgetForecast {balance:number|null;daily:number;days:number|null;date:string|null;window:number;}
export interface Alert {id:string;level:'critical'|'warning'|'info';title:string;detail:string;source:string;tab:string;}
export interface WorkLogEntry {id:string;client:string;date:string;manager:string;platform:string;campaign:string;text:string;goal:string;result:string;status:string;}
export interface Report {id:string;client:string;period:string;brief:string[];text:string;status:'draft'|'ready';updated:string;}
export interface Keyword {id:string;text:string;frequency:number|null;intent:string;campaign:string;group:string;match:string;excluded:boolean;comment:string;}
export interface KeywordCluster {name:string;keywords:Keyword[];}
export interface AdDraft {id:string;client:string;campaign:string;group:string;platform:Platform;headlines:string[];descriptions:string[];url:string;utm:string;cta:string;sitelinks:{text:string;url:string}[];}
export interface AgencyRepository {getClients():Promise<Client[]>;savePlan(plan:MediaPlan):Promise<void>;getPlans():MediaPlan[];saveReport(report:Report):Promise<void>;}

export type WebDimension='devices'|'gender'|'age'|'cities'|'countries'|'visitorType'|'browsers'|'landingPages';
export interface WebBreakdown {dimension:WebDimension;metric:'sessions'|'users'|'pageviews';from:string;to:string;total:number|null;exclusive:boolean;complete:boolean;sampled?:boolean;rows:{label:string;value:number|null}[];}
