import {oneCKey} from '../domain/onec.js';
import {goalPreferenceKey} from '../domain/web-goals.js';
import {attachShared} from './shared.js';
import {demoClients,demoKeywords,demoLogs} from './demo.js';
import {normalizeWorkspace,api} from './remote.js';
import {periods,isoDate,shiftDate} from '../domain/dates.js';
const prefix='spektr.workspace.v1.';
export const repository={
 remoteClients:[],remoteState:'idle',remoteError:'',remoteAsOf:null,runtime:{},sessionDBToken:'',
 read(key,fallback){try{return JSON.parse(localStorage.getItem(prefix+key))??structuredClone(fallback)}catch{return structuredClone(fallback)}},
 write(key,value){try{localStorage.setItem(prefix+key,JSON.stringify(value));return true}catch{throw new Error('Не удалось сохранить: хранилище браузера недоступно или заполнено. Экспортируйте данные.')}},
 clients(){const remote=this.read('dataSource',{}).enabled||this.runtime.database;const base=remote?this.remoteClients:structuredClone(demoClients);const source=[...base,...this.read('customClients',[]).filter(c=>!base.some(existing=>existing.id===c.id))];return structuredClone(source).map(c=>{const key=(remote?'database.sales.':'sales.')+c.id,saved=this.read(key,null);const goalConfig=this.read(goalPreferenceKey({...c,dataOrigin:remote?'database':'demonstration'}),{});return {...c,oneCRecord:remote&&this.sharedReady?this.sharedRecords?.get(oneCKey(c.id))?.value||null:null,analytics:(c.analytics||[]).map(source=>{const choice=goalConfig.sources?.find(s=>s.provider===source.provider&&s.sourceId===source.id);return choice?{...source,favoriteGoals:choice.goals}:source}),sales:saved??c.sales,manager:this.read(this.clientConfigKey(c.id),{}).manager??(c.manager==='Роман'?'Мадина':c.manager),accounts:c.accounts.map(a=>({...a,workspaceUrl:this.read(this.clientConfigKey(c.id),{}).accountLinks?.[a.id]??a.workspaceUrl})),salesOrigin:saved?(this.sharedRecords?.has(key)?'workspace':'local'):remote?'database':'demo'};})},
 clientConfigKey(client){return 'clientConfig.'+(this.read('dataSource',{}).enabled||this.runtime.database?'database':'demonstration')+'.'+client},
 canManageClients(){return this.sharedReady&&this.sharedUser?.permissions?.manageClients===true},
 salesKey(client){return (this.read('dataSource',{}).enabled||this.runtime.database?'database.sales.':'sales.')+client},
 async getClients(period=periods.this_month){const config=this.read('dataSource',{});this.remoteState='loading';this.remoteError='';try{const result=await api('/api/workspace',{sourceUrl:config.enabled?config.url:undefined,accessToken:config.enabled?this.sessionDBToken:undefined,from:[period.previousFrom,shiftDate(isoDate(),-31)].sort()[0],to:[period.to,isoDate()].sort().at(-1),analyticsPeriods:period.analyticsPeriods||[{from:period.from,to:period.to},{from:period.previousFrom,to:period.previousTo}].filter(r=>r.from&&r.to)});if(!result.configured){this.remoteState='demo';return this.clients()}const clients=normalizeWorkspace(result);this.runtime.exchangeRates=result.exchangeRates??null;this.runtime.database=true;this.remoteClients=clients;this.remoteState='ready';this.remoteAsOf=result.asOf||new Date().toISOString();return this.clients()}catch(err){this.remoteState='error';this.remoteError=err.message;throw err}},
 plans(){return this.read('plans',[])},
 savePlan(plan){const list=this.plans();this.write('plans',[plan,...list.filter(x=>x.id!==plan.id)]);this.write('activePlan.'+plan.client,plan.id)},
 activePlan(client,month=periods.this_month.from.slice(0,7)){const id=this.read('activePlan.'+client,null);return this.plans().find(p=>p.id===id&&p.month===month)},
 keywords(client){return this.read('keywords.'+client,client==='mrt'&&!this.runtime.database&&!this.read('dataSource',{}).enabled?demoKeywords:[])},
 ads(client){return this.read('ads.'+client,[])},
 logs(client){return this.read('logs',this.runtime.database||this.read('dataSource',{}).enabled?[]:demoLogs).filter(l=>l.client===client)},
 saveLog(log){this.write('logs',[log,...this.read('logs',this.runtime.database||this.read('dataSource',{}).enabled?[]:demoLogs)])},
 reports(){return this.read('reports',[])},
 saveReport(report){this.write('reports',[report,...this.reports().filter(x=>x.id!==report.id)])},
 settings(client='global'){return this.read('settings.'+client,{budgetDays:3,cplPercent:30,staleHours:24,namingURL:''})},
 async sync(client,period=periods.this_month){if(this.read('dataSource',{}).enabled||this.runtime.database)await this.getClients(period);else await new Promise(r=>setTimeout(r,700));return this.clients().find(c=>c.id===client)?.accounts.map(a=>({platform:a.platform,state:a.state}))??[]}
};
// Replace this repository with implementations of types.d.ts; keep calculations in domain/metrics.js.
// No credentials or tokens are persisted in browser storage. Real integrations require a server.

attachShared(repository);
