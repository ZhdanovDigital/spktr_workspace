import {uploadTaskAttachments,finishTaskAttachments} from './ui/task-editor.js';
import {installTaskBoard} from './ui/task-board.js';
import {reportFileName} from './domain/report-files.js';
import {S,currentClient} from './ui/state.js';
import {repository as R} from './data/repository.js';
import {api} from './data/remote.js';
import {download,exportXLSX} from './domain/spreadsheet.js';
import {isoDate,periods} from './domain/dates.js';
import {openTask,overdue,nextDue,taskDueAt,checklistItems,logInPeriod,composePrompt} from './domain/operations.js';
import {buildReportContext,webReportSheets} from './domain/report.js';
import {defaultAI} from './data/ai-settings.js';
import {teamIssues,applicablePrompts} from './ui/team.js';

const origin=()=>R.runtime.database||R.read('dataSource',{}).enabled?'database':'demonstration';
const stripMeta=({revision,serverMeta,draftId,checkDraft,...value})=>value;
export function captureReportInputs(){
  const c=currentClient(),cfg={...defaultAI,...R.read('ai.config',{})},composed=composePrompt(cfg,R.prompts(),c,S.reportPromptIds||[]);
  if(composed.skill.length>30000)throw new Error('Слишком большой набор инструкций. Оставьте только нужные модули.');
  S.reportPromptSnapshot={provider:cfg.provider,model:cfg.model,basePrompt:cfg.prompt,skill:cfg.skill,layers:composed.layers};
  S.reportDataSnapshot=buildReportContext(c,periods[S.reportPeriod],S.brief,S.confirmLogs?logInPeriod(R.logs(c.id),periods[S.reportPeriod]):[],R.settings(c.id),R.activePlan(c.id));
  S.reportDataSnapshot.completedTasks=R.tasks().filter(t=>t.client===c.id&&t.status==='done'&&t.completedAt&&isoDate(new Date(t.completedAt))>=periods[S.reportPeriod].from&&isoDate(new Date(t.completedAt))<=periods[S.reportPeriod].to).map(t=>({title:t.title,assignee:t.assignee,completedAt:t.completedAt,description:t.description,checks:t.checks}));
  return {cfg:{...cfg,prompt:composed.prompt,skill:composed.skill},data:S.reportDataSnapshot};
}
export function initializeReport(){
  const c=currentClient(),logs=logInPeriod(R.logs(c.id),periods[S.reportPeriod]);
  const target=Object.entries(c.targets||{}).filter(([k,v])=>v!=null).map(([k,v])=>k.toUpperCase()+': '+v).join('; ');
  S.brief=[c.goal|| (target?'Ориентиры карточки: '+target:'Нет информации'),logs.length?logs.map(l=>`${l.date}: ${l.text}. Цель: ${l.goal}. Результат: ${l.result}`).join('\n'):'Нет информации','Нет информации','Нет информации','Нет информации','Нет информации'];
  S.briefAutofilled=new Set([1]);S.confirmLogs=true;
  const modules=applicablePrompts().filter(p=>p.autoSelect);let format=false;
  S.reportPromptIds=modules.filter(p=>p.scope!=='format'||(!format&&(format=true))).map(p=>p.id);
  S.reportPromptSnapshot=null;S.reportDataSnapshot=null;
}

export function installTeam(actions,{render,toast,openModal,closeModal,navigate,persistReport}){
  const refreshing={active:false};
  async function refresh(){if(refreshing.active||R.sharedPending)return;refreshing.active=true;try{await R.loadShared();if(!S.modal)render()}catch(err){R.sharedError=err.message;toast(err.message);if(!S.modal)render()}finally{refreshing.active=false}}
  function newTask(client=S.client,kind='other',status='todo'){const c=R.clients().find(c=>c.id===client)||R.clients()[0];if(!c){toast('Сначала создайте клиентский проект');return;}S.taskDraft={draftId:crypto.randomUUID(),client:c.id,assignee:c.manager||R.sharedUser?.name||'',kind,title:kind==='review'?'Плановая проверка рекламы: '+c.name:'',due:isoDate(),time:'18:00',status,repeat:kind==='review'?'weekly':'none',checks:Array(checklistItems.length).fill(false),platform:'all',remindMinutes:60};openModal('task-edit')}
  async function saveTask(fields,old={}){
    const value={...stripMeta(old),...fields,id:old.id||old.draftId||crypto.randomUUID(),origin:old.origin||origin(),checks:checklistItems.map((_,i)=>fields['check-'+i]==='on'),remindMinutes:Number(fields.remindMinutes)||0,anchorDay:old.anchorDay||Number(fields.due.slice(8)),updated:new Date().toISOString()};
    for(const k of Object.keys(value))if(k.startsWith('check-'))delete value[k];
    if(value.kind==='review'&&value.status==='done'&&value.checks.some(v=>!v))throw new Error('Отметьте все пункты проверки перед завершением задачи.');
    if(value.status==='done'&&old.status!=='done')value.completedAt=new Date().toISOString();
    const additions=String(fields.subtaskText||'').split(/\r?\n/).map(t=>t.trim()).filter(Boolean);
    value.subtasks=[...(old.subtasks||[]).map((t,i)=>({...t,done:fields['subtask-'+i]==='on'})),...additions.map(title=>({id:crypto.randomUUID(),title,done:false}))];
    if(value.subtasks.length>30)throw new Error('До 30 подзадач в одной задаче');
    value.comments=[...(old.comments||[])];if(String(fields.commentText||'').trim())value.comments.push({id:crypto.randomUUID(),text:fields.commentText.trim(),author:R.sharedUser?.name||'Участник команды',at:new Date().toISOString()});
    for(const key of Object.keys(value))if(key.startsWith('subtask-')||['subtaskText','commentText'].includes(key))delete value[key];
    value.attachments=await uploadTaskAttachments({...old,id:value.id,client:value.client},{render});
    await R.persist('task.'+value.id,value,old.revision??0);
    finishTaskAttachments({...old,id:value.id});
    if(value.status==='done'&&value.repeat!=='none'){
      let due=nextDue(value.due,value.repeat,value.anchorDay);let loops=0;
      while(taskDueAt({...value,due})<Date.now()&&loops++<500)due=nextDue(due,value.repeat,value.anchorDay);
      const series=old.series||old.id||value.id,id=series+'-'+due.replaceAll('-','');
      if(!R.sharedRecords.has('task.'+id))await R.saveEntity('task',{...value,id,series,due,status:'todo',completedAt:null,checks:Array(checklistItems.length).fill(false),created:new Date().toISOString(),subtasks:(value.subtasks||[]).map(t=>({...t,done:false})),comments:[],attachments:[]});
    }
    return value;
  }
  installTaskBoard(actions,{render,toast,move:async(id,status)=>{
    if(S.teamBusy||!['todo','progress','review','done','cancelled'].includes(status))return;
    const task=R.tasks().find(t=>t.id===id);if(!task||task.status===status)return;
    const fields={...stripMeta(task),status};for(let i=0;i<checklistItems.length;i++)fields['check-'+i]=task.checks?.[i]?'on':'';for(let i=0;i<(task.subtasks||[]).length;i++)fields['subtask-'+i]=task.subtasks[i].done?'on':'';
    S.teamBusy=true;render();try{await saveTask(fields,task);toast('Статус задачи сохранён')}catch(error){toast(error.message)}finally{S.teamBusy=false;render()}
  }});
  Object.assign(actions,{
    'to-tasks':()=>navigate('tasks'),
    'notifications':()=>openModal('notifications'),
    'team-sync':()=>openModal('team-sync'),
    'team-refresh':refresh,
    'task-new':el=>newTask(el?.dataset.client||(S.taskClient&&S.taskClient!=='all'?S.taskClient:S.client),'other',el?.dataset.status||'todo'),
    'task-new-client':()=>newTask(S.client),
    'client-review':()=>newTask(S.client,'review'),
    'client-task-state':el=>{S.clientTaskState=el.dataset.value;render()},
    'client-chart':el=>{S.channelChart=el.dataset.value;render()},
    'client-focus-account':el=>{const account=el.dataset.account;el.closest('[data-client-control]')?.removeAttribute('open');if(S.tab!=='overview'){S.tab='overview';render()}const node=document.getElementById('channel-'+encodeURIComponent(account));node?.scrollIntoView({behavior:window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});node?.focus({preventScroll:true})},
    'task-new-account':el=>{const a=currentClient().accounts.find(a=>a.id===el.dataset.account);newTask(S.client);if(a){S.taskDraft.platform=a.platform;S.taskDraft.title='Проверить '+a.name;render()}},
    'task-edit':el=>{S.taskDraft=structuredClone(R.tasks().find(t=>t.id===el.dataset.id));if(!S.taskDraft)return;openModal('task-edit')},
    'task-filter':el=>{S.taskFilter=el.dataset.value;render()},
    'seed-reviews':()=>openModal('seed-reviews'),
    'attention-open':el=>{S.modalReturn=null;S.client=el.dataset.client;if(el.dataset.task){S.taskDraft=structuredClone(R.tasks().find(t=>t.id===el.dataset.task));openModal('task-edit')}else if(el.dataset.kind==='no-review')newTask(S.client,'review');else{closeModal();navigate('client/'+S.client);S.tab=el.dataset.tab||'accounts';render()}},
    'team-log-new':()=>{S.logDraft={client:S.journalClient&&S.journalClient!=='all'?S.journalClient:S.client};openModal('journal-edit')},
    'work-log':el=>{const a=currentClient().accounts.find(a=>a.id===el?.dataset.account);S.logDraft={client:S.client,platform:a?.platform,campaign:a?.name};openModal('journal-edit')},
    'journal-edit':el=>{S.logDraft=structuredClone(R.logs(el.dataset.client).find(l=>l.id===el.dataset.id));openModal('journal-edit')},
    'prompt-new':()=>{S.promptDraft={scope:'agency'};openModal('prompt-edit')},
    'prompt-edit':el=>{S.promptDraft=structuredClone(R.prompts().find(p=>p.id===el.dataset.id));openModal('prompt-edit')},
    'prompt-import':()=>{S.importPromptError='';openModal('prompt-import')},
    'prompt-archive':async el=>{const p=R.prompts().find(p=>p.id===el.dataset.id);if(!p)return;await R.saveEntity('prompt',{...p,active:false});render();toast('Препромпт архивирован; сохранённые отчёты сохраняют свои инструкции')},
    'seed-prompts':async()=>{const defs=[
      {id:'format-client',name:'Клиентский отчёт: кратко',scope:'format',autoSelect:true,content:'Начни с резюме на 4–6 предложений: результат, подтверждённая динамика, качество данных и следующий шаг. Затем кратко разберись с каждым подключённым каналом, выполненными работами и планом. Используй понятный деловой язык без оправданий и обещаний. Конструктивный тон не должен скрывать подтверждённое ухудшение.'},
      {id:'platform-google',name:'Google Ads: контекст и результаты',scope:'platform',platform:'google',autoSelect:true,content:'Для Google Ads сравни затраты, клики, CTR, результаты, CR и цену результата. Различай конверсии кабинета и уникальные лиды CRM. Если данных по кампаниям, запросам или изменениям нет, не делай выводов об их качестве и причинах динамики. Учитывай только изменения, зафиксированные специалистом в выбранном периоде.'},
      {id:'platform-meta',name:'Meta Ads: результаты и креативы',scope:'platform',platform:'meta',autoSelect:true,content:'Для Meta сравни расходы, результаты и цену результата; укажи цель и определение результата из данных. Не называй клики, сообщения или открытия диалога подтверждёнными продажами. Усталость креативов, качество аудитории и эффект правок оценивай только при наличии соответствующих данных; иначе отметь, что причина не подтверждена.'},
      {id:'platform-yandex',name:'Яндекс Директ: цели и динамика',scope:'platform',platform:'yandex',autoSelect:true,content:'Для Яндекс Директ сравни рекламные показатели и тип выбранной конверсии. Учитывай зарегистрированные изменения сайта, целей и кампаний. Смена цели не доказывает улучшение качества заявок; проверь CRM. Не придумывай обучение алгоритма, сезонность или причины колебаний при отсутствии подтверждения.'}
    ];let count=0;for(const p of defs)if(!R.sharedRecords.has('prompt.'+p.id)){await R.saveEntity('prompt',{...p,client:'',active:true});count++;}render();toast(count?'Добавлено модулей: '+count:'Стандартные модули уже добавлены')},
    'retry-shared':async()=>{if(!R.sharedReady)await refresh();await R.retryFailed();R.sharedError='';closeModal();toast('Изменения сохранены в команде')},
    'conflict-server':el=>{const key=el.dataset.key;R.sharedConflicts.delete(key);R.sharedFailed.delete(key);localStorage.removeItem('spektr.workspace.v1.pending.'+key);R.sharedError=R.sharedFailed.size?'Есть несохранённые записи':'';render()},
    'conflict-mine':async el=>{const key=el.dataset.key,draft=R.sharedConflicts.get(key)?.draft;if(draft===undefined)return;R.sharedConflicts.delete(key);await R.persist(key,draft);R.sharedError=R.sharedFailed.size?'Есть несохранённые записи':'';render();toast('Ваш вариант сохранён новой версией')},
    'download-unsaved':()=>download('SPEKTR-unsaved.json',JSON.stringify({createdAt:new Date().toISOString(),records:[...R.sharedFailed].map(([key,v])=>({key,value:v.value})),conflicts:[...R.sharedConflicts]},null,2),'application/json'),
    'enable-notifications':async()=>{if(!('Notification' in window)){toast('Браузер не поддерживает уведомления');return}const permission=await Notification.requestPermission();R.write('notifications.enabled',permission==='granted');toast(permission==='granted'?'Уведомления включены для открытого рабочего пространства':'Напоминания останутся внутри сервиса')},
    'metabase-settings':()=>openModal('metabase-settings'),
    'metabase-open':async()=>{const config=R.read('metabase.'+S.client,{});if(config.mode!=='guest'){if(!config.url){openModal('metabase-settings');return}window.open(config.url,'_blank','noopener');return}const data=await api('/api/metabase',{client:S.client});S.metabaseEmbed=data;openModal('metabase-view');await mountMetabase(data)},
    'use-logs':()=>{const logs=logInPeriod(R.logs(S.client),periods[S.reportPeriod]);S.confirmLogs=true;S.brief[1]=logs.length?logs.map(l=>`${l.date}: ${l.text}. Цель: ${l.goal}. Результат: ${l.result}`).join('\n'):'Нет изменений в журнале за этот период';S.briefAutofilled??=new Set();S.briefAutofilled.add(1);render();toast('Подставлены записи за выбранный период')}
  });
  actions['export-report-data']=async()=>{
    if(S.aiBusy||S.teamBusy)return;S.teamBusy=true;render();try{await persistReport(S.reportStatus||'draft',{keepOpen:true});
    if(!S.reportDataSnapshot)captureReportInputs();
    const d=S.reportDataSnapshot,fields=['spend','impressions','clicks','ctr','leads','qualified','cpl','cpql','sales','cpa','revenue','roas','drr'],adFields=['spend','impressions','clicks','ctr','cpc','conversions','cr','cpa'];
    exportXLSX((S.reportFileName||reportFileName({},currentClient()))+'_data.xlsx',{
      ...webReportSheets(d),
      'Сводка':[['Показатель','Текущий период','Предыдущий период'],...fields.map(k=>[k,d.metrics[k]??'',d.previous[k]??''])],
      'Кабинеты':[['Площадка','ID','Валюта','Период',...adFields],...d.advertising.flatMap(a=>[['Текущий',a.current],['Предыдущий',a.previous]].map(([label,v])=>[a.platform,a.id,a.currency,label,...adFields.map(k=>v[k]??'')]))],
      'Журнал':[['Дата','Менеджер','Площадка','Кампания','Изменение','Цель','Результат','Статус','Версия'],...d.confirmedWorkLog.map(l=>[l.date,l.manager,l.platform,l.campaign,l.text,l.goal,l.result,l.status,l.recordVersion??''])],
      'Источники':[['Параметр','Значение'],['Клиент',d.client.name],['ID',d.client.id],['Начало',d.period.from],['Конец',d.period.to],['Сравнение с',d.period.previousFrom],['Сравнение по',d.period.previousTo],['Снимок',d.dataCollectedAt],['Источник',d.origin],['Расходы','Суммируются только внутри одной валюты'],['Лиды','Конверсии кабинетов не складываются как уникальные лиды']],
      'Препромпты':[['Модуль','Назначение','Версия','Инструкция'],['Базовый препромпт','Агентство','',S.reportPromptSnapshot?.basePrompt||''],...(S.reportPromptSnapshot?.layers||[]).map(p=>[p.name,p.scope,p.revision,p.content])]
    });
    }catch(error){toast(error.message)}finally{S.teamBusy=false;render()}
  };
  const oldApply=actions['apply-period'];actions['apply-period']=async()=>{await oldApply();if(S.modal==='report'&&S.briefAutofilled?.has(1)){const logs=logInPeriod(R.logs(S.client),periods[S.reportPeriod]);S.brief[1]=logs.length?logs.map(l=>`${l.date}: ${l.text}. Цель: ${l.goal}. Результат: ${l.result}`).join('\n'):'Нет информации';S.reportDataSnapshot=null;S.reportPromptSnapshot=null;render();}};
  const oldOpen=actions['open-report'];actions['open-report']=el=>{oldOpen(el);const r=R.reports().find(r=>r.id===el.dataset.id);S.reportPromptIds=r?.selectedModules||[];S.reportPromptSnapshot=r?.promptSnapshot||null;S.reportDataSnapshot=r?.dataSnapshot||null;S.confirmLogs=r?.includeLogs??true;render()};
  document.addEventListener('submit',async ev=>{const form=ev.target;if(!['team-task','team-reviews','team-prompt','team-log','team-metabase'].includes(form.dataset.form))return;ev.preventDefault();if(S.teamBusy)return;const fields=Object.fromEntries(new FormData(form));S.teamBusy=true;for(const b of document.querySelectorAll('.modal-footer button[type="submit"],.modal-footer button[form]'))b.disabled=true;
    try{
      if(form.dataset.form==='team-task'){await saveTask(fields,S.taskDraft||{});toast('Задача сохранена')}
      if(form.dataset.form==='team-reviews'){let count=0;for(const c of R.clients())if(fields['client-'+c.id]==='on'&&!R.tasks().some(t=>t.client===c.id&&t.kind==='review'&&openTask(t))){await saveTask({client:c.id,assignee:c.manager||R.sharedUser?.name,title:'Плановая проверка рекламы: '+c.name,kind:'review',platform:'all',due:fields.due,time:fields.time,status:'todo',repeat:'weekly',priority:'normal',remindMinutes:60});count++;}toast('Проверок назначено: '+count)}
      if(form.dataset.form==='team-prompt'){await R.saveEntity('prompt',{...stripMeta(S.promptDraft||{}),...fields,id:S.promptDraft?.id||crypto.randomUUID(),client:fields.scope==='client'?fields.client:'',platform:fields.scope==='platform'?fields.platform:'',autoSelect:fields.autoSelect==='on',active:true});toast('Препромпт сохранён')}
      if(form.dataset.form==='team-log'){await R.saveLog({...stripMeta(S.logDraft||{}),...fields,id:S.logDraft?.id||crypto.randomUUID(),updated:new Date().toISOString()});toast('Изменение сохранено и будет доступно в отчёте за его даты')}
      if(form.dataset.form==='team-metabase'){if(fields.url){const u=new URL(fields.url);if(u.protocol!=='https:'||u.username||u.password)throw new Error('Используйте HTTPS ссылку без логина и пароля');}if(fields.mode==='guest'&&(!Number.isSafeInteger(Number(fields.dashboardId))||Number(fields.dashboardId)<1))throw new Error('Для встраивания нужен ID дашборда');await R.persist('metabase.'+S.client,{...fields,dashboardId:fields.dashboardId?Number(fields.dashboardId):null});toast('Metabase привязан к клиенту')}
      S.teamBusy=false;closeModal();render();
    }catch(err){toast(err.message);for(const b of document.querySelectorAll('.modal-footer button[form]'))b.disabled=false;}finally{S.teamBusy=false;if(form.dataset.form==='team-task'&&S.modal==='task-edit')render();}
  });
  document.addEventListener('change',async ev=>{const el=ev.target;if(el.dataset.teamFilter){S[el.dataset.teamFilter]=el.value;render();}if(el.dataset.reportModule){const p=R.prompts().find(p=>p.id===el.dataset.reportModule);const ids=new Set(S.reportPromptIds||[]);if(el.checked){if(p?.scope==='format')for(const id of ids)if(R.prompts().find(m=>m.id===id)?.scope==='format')ids.delete(id);ids.add(el.dataset.reportModule)}else ids.delete(el.dataset.reportModule);S.reportPromptIds=[...ids];render();}
    if(el.dataset.teamUpload==='prompts'){if(S.teamBusy)return;S.teamBusy=true;let count=0;try{for(const file of [...el.files]){if(!/\.(md|txt)$/i.test(file.name)||file.size>100000)throw new Error('Нужен .md или .txt до 100 КБ');const content=(await file.text()).replace(/^\uFEFF/,'').trim();if(!content||content.length>30000)throw new Error('Инструкция должна содержать от 1 до 30 000 символов');await R.saveEntity('prompt',{id:crypto.randomUUID(),name:file.name.replace(/\.(md|txt)$/i,''),content,scope:'agency',client:'',platform:'',autoSelect:false,active:true});count++;}closeModal();navigate('prompts');toast('Загружено препромптов: '+count);}catch(err){S.importPromptError=(count?'Уже сохранено: '+count+'. ':'')+err.message;render();}finally{S.teamBusy=false;}}
  });
  document.addEventListener('input',ev=>{const el=ev.target;if(el.dataset.teamFilter){S[el.dataset.teamFilter]=el.value;render()}if(el.dataset.brief!==undefined)S.briefAutofilled?.delete(Number(el.dataset.brief));});
  window.addEventListener('spektr:shared',()=>{if(!S.modal)render()});
  setInterval(()=>{if(!document.hidden&&!S.modal)refresh()},60000);
  const seen=new Set();
  async function remind(){if(S.teamBusy||R.sharedPending)return;if(document.hidden){if(!R.read('notifications.enabled',false))return;try{await R.loadShared()}catch{return;}}const due=R.tasks().filter(t=>openTask(t)&&Date.now()>=taskDueAt(t)-(t.remindMinutes??60)*60000);for(const t of due){const key=t.id+':'+t.due;if(seen.has(key))continue;seen.add(key);toast((overdue(t)?'Просрочено: ':'Напоминание: ')+t.title+' · '+t.assignee);if(R.read('notifications.enabled',false)&&'Notification' in window&&Notification.permission==='granted'){const notification=new Notification('SPEKTR · '+(overdue(t)?'Просроченная задача':'Срок задачи'),{body:t.title+' · '+t.assignee,tag:key});notification.onclick=()=>{window.focus();S.taskDraft=structuredClone(t);openModal('task-edit');notification.close()};}}}
  setInterval(remind,30000);window.addEventListener('focus',()=>{if(!S.modal)refresh();remind()});
}

async function mountMetabase(data){
  window.metabaseConfig={isGuest:true,instanceUrl:data.instanceUrl,guestEmbedProviderUri:'/api/metabase',locale:'ru'};
  if(!document.getElementById('metabase-guest-script')){await new Promise((resolve,reject)=>{const script=document.createElement('script');script.id='metabase-guest-script';script.src=data.instanceUrl+'/app/embed.js';script.onload=resolve;script.onerror=()=>{script.remove();reject(new Error('Metabase не загрузил Guest embed. Проверьте версию, URL и разрешённые домены.'))};document.head.appendChild(script);});}
  const container=document.getElementById('metabase-container');if(!container)return;container.textContent='';const dashboard=document.createElement('metabase-dashboard');dashboard.setAttribute('token',data.jwt);dashboard.setAttribute('dashboard-id',String(data.dashboardId));dashboard.setAttribute('custom-context',S.client);dashboard.setAttribute('with-title','true');container.appendChild(dashboard);
}
