import {dayCount} from './dates.js';
export const goalKinds={lead:'Лиды / заявки',whatsapp:'WhatsApp',call:'Звонки'};
export const goalPreferenceKey=c=>'analytics.config.favorites.'+(c.dataOrigin==='database'?'database':'demonstration')+'.'+encodeURIComponent(c.id);
const validDate=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d;
const number=n=>typeof n==='number'&&Number.isFinite(n)&&n>=0;
export function normalizeWebGoals(input){
 if(input==null)return [];if(!Array.isArray(input)||input.length>200)throw Error('analytics.goals: максимум 200 целей');const ids=new Set();
 return input.map(g=>{
  if(!g||!['string','number'].includes(typeof g.id)||!String(g.id).trim()||String(g.id).length>150||ids.has(String(g.id))||typeof g.name!=='string'||!g.name.trim()||g.name.length>200)throw Error('analytics.goals: нужны уникальные id и name');ids.add(String(g.id));
  if(g.days!=null&&!Array.isArray(g.days)||g.days?.length>10000)throw Error('analytics.goals.days: ожидается массив до 10 000 дней');const dates=new Set();
  const days=(g.days||[]).map(d=>{if(!d||!validDate(d.date)||dates.has(d.date)||['conversions','goalSessions'].some(k=>d[k]!=null&&!number(d[k])))throw Error('analytics.goals.days: проверьте дату, дубли и значения');dates.add(d.date);return {date:d.date,conversions:d.conversions??null,goalSessions:d.goalSessions??null}});
  return {id:String(g.id),name:g.name,kind:Object.hasOwn(goalKinds,g.kind)?g.kind:'other',favorite:g.favorite===true,days};
 });
}
export function favoriteGoals(source){
 const selections=Array.isArray(source.favoriteGoals)?source.favoriteGoals:(source.goals||[]).filter(g=>g.favorite&&Object.hasOwn(goalKinds,g.kind)).map(g=>({id:g.id,kind:g.kind}));
 return selections.map(item=>{const goal=source.goals?.find(g=>g.id===item.id);return {...item,name:goal?.name||item.name||item.id,goal:goal||null}}).filter(item=>Object.hasOwn(goalKinds,item.kind));
}
export function goalMetrics(source,goal,p){
 const rows=(goal?.days||[]).filter(r=>r.date>=p.from&&r.date<=p.to),base=(source.days||[]).filter(r=>r.date>=p.from&&r.date<=p.to),dates=new Map(base.map(r=>[r.date,r]));
 const count=key=>rows.length&&rows.every(r=>number(r[key]))?rows.reduce((n,r)=>n+r[key],0):null,conversions=count('conversions'),goalSessions=count('goalSessions');
 const sameDays=rows.length>0&&rows.length===base.length&&rows.every(r=>dates.has(r.date)&&number(r.goalSessions)&&number(dates.get(r.date)?.sessions)&&r.goalSessions<=dates.get(r.date).sessions);
 const sessions=sameDays?base.reduce((n,r)=>n+r.sessions,0):null,cr=goalSessions!=null&&sessions>0?goalSessions/sessions*100:null;
 return {conversions,goalSessions,cr,days:rows.length,expectedDays:dayCount(p),complete:rows.length===dayCount(p)&&conversions!==null,crComplete:sameDays&&base.length===dayCount(p)&&goalSessions!==null};
}
export function favoriteGoalSnapshot(source,p){return favoriteGoals(source).map(item=>({id:item.id,name:item.name,kind:item.kind,available:Boolean(item.goal),current:goalMetrics(source,item.goal,p),previous:goalMetrics(source,item.goal,{from:p.previousFrom,to:p.previousTo})}))}
