export const timeZone='Asia/Almaty';
export const isoDate=(value=new Date())=>new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).format(value);
export const shiftDate=(date,days)=>new Date(Date.parse(date+'T12:00:00Z')+days*86400000).toISOString().slice(0,10);
export const dayCount=p=>Math.round((Date.parse(p.to)-Date.parse(p.from))/86400000)+1;
export const shortDate=date=>new Date(date+'T12:00:00Z').toLocaleDateString('ru-RU',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'});
export function makePeriod(label,from,to,comparison='auto'){
 const days=dayCount({from,to});
 const wholeMonth=from.endsWith('-01')&&from.slice(0,7)===to.slice(0,7)&&shiftDate(to,1).endsWith('-01');
 const mode=comparison==='auto'?(wholeMonth?'month':'range'):comparison;
 let previousFrom=shiftDate(from,-days),previousTo=shiftDate(from,-1);
 if(mode==='month'){previousTo=shiftDate(from.slice(0,7)+'-01',-1);previousFrom=previousTo.slice(0,7)+'-01'}
 if(mode==='week'){const weekday=(new Date(from+'T12:00:00Z').getUTCDay()+6)%7;previousTo=shiftDate(from,-weekday-1);previousFrom=shiftDate(previousTo,-6)}
 return {label,from,to,previousFrom,previousTo,comparison:mode};
}
export function createPeriods(today=isoDate()){const d=new Date(today+'T12:00:00Z'),month=today.slice(0,7)+'-01',weekday=(d.getUTCDay()+6)%7,weekStart=shiftDate(today,-weekday);const lastMonthEnd=shiftDate(month,-1);return {today:makePeriod('Сегодня',today,today,'range'),yesterday:makePeriod('Вчера',shiftDate(today,-1),shiftDate(today,-1),'range'),this_week:makePeriod('Эта неделя',weekStart,today,'week'),last_week:makePeriod('Прошлая неделя',shiftDate(weekStart,-7),shiftDate(weekStart,-1),'week'),this_month:makePeriod('Этот месяц',month,today,'month'),last_month:makePeriod('Прошлый месяц',lastMonthEnd.slice(0,7)+'-01',lastMonthEnd,'month'),custom:makePeriod('Произвольный период',month,today)}}
export const comparisonCaption=p=>`${shortDate(p.previousFrom)}${p.previousFrom===p.previousTo?'':' — '+shortDate(p.previousTo)}`;
export const periods=createPeriods();
export const periodCaption=key=>{const p=periods[key]||periods.this_month;return `${shortDate(p.from)}${p.from===p.to?'':' — '+shortDate(p.to)}`};
export function setCustomPeriod(from,to){if(!/^\d{4}-\d{2}-\d{2}$/.test(from)||!/^\d{4}-\d{2}-\d{2}$/.test(to)||!Number.isFinite(Date.parse(from))||!Number.isFinite(Date.parse(to))||new Date(from).toISOString().slice(0,10)!==from||new Date(to).toISOString().slice(0,10)!==to||from>to||dayCount({from,to})>366)throw new Error('Выберите корректный период, не более 366 дней');periods.custom=makePeriod('Произвольный период',from,to);return periods.custom;}
