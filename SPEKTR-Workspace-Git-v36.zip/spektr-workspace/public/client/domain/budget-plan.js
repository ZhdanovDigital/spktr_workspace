import {allAccountDays} from './analytics.js';
import {dayCount,isoDate,shiftDate} from './dates.js';
export const budgetSources={manual:'Ручной план',media:'По медиаплану',paid:'Оплачено клиентом'};
export const budgetKey=p=>`budgetPlan.${p.origin}.${encodeURIComponent(p.client)}.${p.from}.${p.to}`;
export function validateBudgetPlan(p){
 const valid=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d;
 if(!p||!['database','demonstration'].includes(p.origin)||typeof p.client!=='string'||!p.client||budgetKey(p).length>200)throw new Error('Некорректный проект плана');
 if(!valid(p.from)||!valid(p.to)||p.from>p.to||dayCount(p)>366)throw new Error('Укажите корректный период до 366 дней');
 if(!Object.hasOwn(budgetSources,p.source))throw new Error('Выберите основание плана');
 if(typeof p.note!=='string'||p.note.length>1000)throw new Error('Комментарий: до 1000 символов');
 if(!Array.isArray(p.amounts)||!p.amounts.length||p.amounts.length>20)throw new Error('Укажите хотя бы одну сумму');
 const seen=new Set();for(const row of p.amounts){if(!row||!/^[A-Z]{3}$/.test(row.currency)||seen.has(row.currency)||typeof row.amount!=='number'||!Number.isFinite(row.amount)||row.amount<=0||row.amount>1e12||Math.abs(row.amount*100-Math.round(row.amount*100))>.01)throw new Error('Суммы должны быть больше нуля, до 1 трлн и с точностью до копеек; валюты не повторяются');seen.add(row.currency)}
 return p;
}
export function matchingBudget(plans,p){return plans.filter(b=>b.from<=p.from&&b.to>=p.to).sort((a,b)=>dayCount(a)-dayCount(b)||a.from.localeCompare(b.from))[0]||null}
// Actual spend always belongs to the entire saved budget period, never the dashboard subrange.
export function budgetProgress(client,plan,today=isoDate()){
 const end=plan.to<today?plan.to:today,fullEnd=plan.to<today?plan.to:shiftDate(today,-1),started=plan.from<=end;
 return plan.amounts.map(({currency,amount})=>{
  const accounts=client.accounts.filter(a=>a.currency===currency);let spend=0,known=0,covered=0;const expected=plan.from<=fullEnd?dayCount({from:plan.from,to:fullEnd}):0;
  for(const a of accounts){const rows=allAccountDays(a).filter(r=>r.date>=plan.from&&r.date<=end);for(const r of rows)if(typeof r.spend==='number'&&Number.isFinite(r.spend)&&r.spend>=0){spend+=r.spend;known++;if(r.date<=fullEnd)covered++}}
  const complete=accounts.length>0&&covered===expected*accounts.length,actual=!started?0:known?Math.round(spend*100)/100:null,used=actual===null?null:actual/amount*100,remaining=actual===null?null:amount-actual;
  const tone=actual>amount?'critical':!complete||actual===null?'neutral':used>=90?'warning':'good';
  return {currency,amount,actual,used,remaining,complete,accounts:accounts.length,tone,expectedDays:expected,covered,notStarted:!started};
 });
}
