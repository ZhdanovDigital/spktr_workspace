import {accountMetrics,allAccountDays} from './analytics.js';
import {dayCount} from './dates.js';
import {budgetForecast} from './metrics.js';

const hosts={google:['ads.google.com'],meta:['adsmanager.facebook.com','business.facebook.com'],yandex:['direct.yandex.ru','direct.yandex.com','direct.yandex.kz'],tiktok:['ads.tiktok.com','business.tiktok.com']};
export function validAccountURL(value,platform){
 try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&(hosts[platform]||[]).includes(u.hostname)?u.href:null}catch{return null}
}
export const accountURL=a=>validAccountURL(a.workspaceUrl||a.url||a.accountUrl||a.manageUrl,a.platform);
export function accountSnapshot(a,p,settings={},reference=Date.now()){
 const current=accountMetrics(a,p),previous=accountMetrics(a,p,true);
 const expected=dayCount(p),previousExpected=dayCount({from:p.previousFrom,to:p.previousTo});
 const complete=current.days===expected,previousComplete=previous.days===previousExpected;
 const age=(reference-Date.parse(a.updated))/3600000;
 const fresh=a.state==='fresh'&&Number.isFinite(age)&&age<=(settings.staleHours??24);
 const comparable=complete&&previousComplete&&fresh;
 const budget=budgetForecast(a),minimum=settings.minResults??5,threshold=settings.cpaPercent??30;
 const priceChange=comparable&&current.cpa!=null&&previous.cpa>0&&current.conversions>=minimum&&previous.conversions>=minimum?(current.cpa/previous.cpa-1)*100:null;
 let tone='neutral',headline='Данные доступны',detail='Проверьте динамику и цели кампаний.';
 if(!fresh){tone='warning';headline={never:'Кабинет не подключён',error:'Ошибка загрузки',unavailable:'Источник недоступен',partial:'Неполный источник',empty:'Нет данных'}[a.state]||'Проверьте свежесть данных';detail='Обновите источник перед выводами об эффективности.'}
 else if(!complete){tone='warning';headline='Период покрыт частично';detail=`Загружено ${current.days} из ${expected} дней. Динамика периода не оценивается.`}
 else if([current.spend,current.clicks,current.impressions,current.conversions].some(v=>v===null)){tone='warning';headline='Не хватает показателей';detail='В источнике есть дни без расхода, кликов, показов или результатов. Проверьте полноту выгрузки.'}
 else if(budget.days!==null&&budget.days<(settings.budgetDays??3)){tone='critical';headline='Бюджет заканчивается';detail=`При текущем расходе осталось ${Math.max(0,budget.days).toFixed(1)} дня. Проверьте пополнение.`}
 else if(priceChange!==null&&priceChange>threshold){tone='critical';headline='Цена результата выросла';detail=`Рост ${priceChange.toFixed(1)}% к предыдущему периоду при пороге ${threshold}%. Проверьте кампании и цели.`}
 else if(priceChange!==null&&priceChange<0){tone='good';headline='Цена результата снизилась';detail='Улучшение цены подтверждено данными. Сопоставьте с объёмом и качеством обращений.'}
 else if(!previousComplete){headline='Нет полной базы сравнения';detail=`Предыдущий период: ${previous.days} из ${previousExpected} дней.`}
 return {current,previous,expected,previousExpected,complete,previousComplete,fresh,comparable,budget,tone,headline,detail,priceChange};
}
export function spendByCurrency(accounts,p){const totals=new Map();for(const a of accounts){const m=accountMetrics(a,p),r=totals.get(a.currency)||{currency:a.currency,value:0,available:0,accounts:0};r.accounts++;if(m.spend!==null){r.value+=m.spend;r.available++}totals.set(a.currency,r)}return [...totals.values()].map(r=>({...r,value:r.available?r.value:null,partial:r.available<r.accounts}));}
export function dailySeries(a,p,key='spend'){
 const days=new Map(allAccountDays(a).filter(d=>d.date>=p.from&&d.date<=p.to).map(d=>[d.date,d]));
 return Array.from({length:dayCount(p)},(_,i)=>{const date=new Date(Date.parse(p.from+'T12:00:00Z')+i*86400000).toISOString().slice(0,10);return {date,value:days.get(date)?.[key]??null}});
}
