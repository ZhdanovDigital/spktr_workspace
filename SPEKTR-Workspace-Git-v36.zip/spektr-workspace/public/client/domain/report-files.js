import {isoDate} from './dates.js';
const translit={'а':'a','б':'b','в':'v','г':'g','д':'d','е':'e','ё':'e','ж':'zh','з':'z','и':'i','й':'y','к':'k','л':'l','м':'m','н':'n','о':'o','п':'p','р':'r','с':'s','т':'t','у':'u','ф':'f','х':'h','ц':'ts','ч':'ch','ш':'sh','щ':'sch','ы':'y','э':'e','ю':'yu','я':'ya','ь':'','ъ':''};
export function reportFileName(report={},client={}){
 if(/^[a-z0-9][a-z0-9_-]{0,149}_ads-report-\d{2}\.\d{2}\.\d{4}$/.test(report.fileName||''))return report.fileName;
 let slug='';try{const site=report.dataSnapshot?.client?.site||client.site;if(site)slug=new URL(/^https?:/.test(site)?site:'https://'+site).hostname.replace(/^www\./,'').split('.')[0]}catch{}
 slug=String(slug||report.clientName||client.name||report.client||client.id||'project').toLowerCase().split('').map(c=>translit[c]??c).join('').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,100)||'project';
 const raw=String(report.reportDate||report.createdAt||report.updated||isoDate()).slice(0,10),date=/^\d{4}-\d{2}-\d{2}$/.test(raw)?raw:isoDate();return slug+'_ads-report-'+date.split('-').reverse().join('.');
}
export function projectReports(reports,client){return reports.filter(r=>r.client===client.id&&(!r.origin||!client.dataOrigin||r.origin===client.dataOrigin)).sort((a,b)=>String(b.updated).localeCompare(String(a.updated)))}
