// Templates and abbreviations ported from the user supplied naming generator.
const GEO=['KZ','ALA','AST','SHY','KRG','RU','UZ','KG','CIS','WW'];
const LANG=[['RU','русский'],['KZ','казахский'],['EN','английский']];
const FUNNEL=[['TOF','холодная аудитория'],['MOF','тёплая аудитория'],['BOF','горячая аудитория'],['RET','ретаргет']];
const SEGMENT=[['BRAND','брендовые запросы'],['GENERIC','общие запросы'],['COMP','конкуренты'],['CAT','категории и товары'],['RMKT','ремаркетинг'],['NEW','новая аудитория']];
const DEVICE=[['All','все устройства'],['Mob','мобильные'],['Desk','десктоп']];
const AD_TAIL=[
  {k:'concept',l:'Концепт',t:'text',d:'UGC-Review'},
  {k:'angle',l:'Хук или угол',t:'text',d:'Price'},
  {k:'lang',l:'Язык',t:'select',d:'RU',o:LANG},
  {k:'ver',l:'Версия',t:'ver',d:'1'},
  {k:'date',l:'Дата, ГГММДД',t:'date',fmt:'ymd'}
];
const CAMP_HEAD=[
  {k:'client',l:'Клиент (код)',t:'text',d:'F7'},
  {k:'geo',l:'Гео',t:'combo',d:'KZ',o:GEO}
];
const P={
  meta:{label:'Meta',levels:[
    {id:'camp',title:'Кампания',fields:[
      {k:'client',l:'Клиент (код)',t:'text',d:'F7'},
      {k:'obj',l:'Цель',t:'select',d:'LEAD',o:[['AWR','узнаваемость и охват'],['TRF','трафик'],['ENG','вовлечённость'],['LEAD','лиды'],['SALES','продажи'],['APP','приложение']]},
      {k:'offer',l:'Продукт и оффер',t:'text',d:'Tires-Winter'},
      {k:'date',l:'Запуск, ГГММ',t:'date',fmt:'ym'}]},
    {id:'group',title:'Группа объявлений',fields:[
      {k:'aud',l:'Тип аудитории',t:'select',d:'INT',o:[['BROAD','широкая'],['INT','интересы'],['LAL','похожие'],['RET','ретаргет'],['CRM','база клиента']]},
      {k:'detail',l:'Детали аудитории',t:'text',d:'Auto-Owners'},
      {k:'geo',l:'Гео',t:'multi',d:['ALA'],all:'KZ',h:'Можно отметить несколько городов или весь Казахстан',
        sub:['ALA','AST','SHY','KRG','AKT','ATY','AKU','PVL','UKK','SEM','KST','URA','TRZ','KZO','PTR','KOK','TLD','TRK','ZHZ'],
        o:[['KZ','весь Казахстан'],['ALA','Алматы'],['AST','Астана'],['SHY','Шымкент'],['KRG','Караганда'],['AKT','Актобе'],['ATY','Атырау'],['AKU','Актау'],['PVL','Павлодар'],['UKK','Усть-Каменогорск'],['SEM','Семей'],['KST','Костанай'],['URA','Уральск'],['TRZ','Тараз'],['KZO','Кызылорда'],['PTR','Петропавловск'],['KOK','Кокшетау'],['TLD','Талдыкорган'],['TRK','Туркестан'],['ZHZ','Жезказган'],['UZ','Узбекистан'],['KG','Кыргызстан']]},
      {k:'ga',l:'Пол и возраст',t:'ga',d:['M','25','54']},
      {k:'place',l:'Плейсмент',t:'multi',d:['Advg+'],all:'Advg+',o:[['Advg+','Advantage+ плейсменты'],['Inst','Instagram'],['FB','Facebook'],['Threads','Threads'],['WA','WhatsApp']]},
      {k:'opt',l:'Оптимизация',t:'select',d:'Lead',o:[['Lead','лиды'],['Purchase','покупки'],['MsgWA','переписки в WhatsApp'],['MsgDIR','переписки в Direct'],['IGVisit','переходы в профиль Instagram'],['LPV','просмотры посадочной'],['Click','клики'],['Reach','охват'],['ThruPlay','досмотры видео']]}]},
    {id:'ad',title:'Объявление',fields:[
      {k:'fmt',l:'Формат',t:'select',d:'VID',o:[['IMG','статика'],['VID','видео'],['CAR','карусель'],['COL','коллекция'],['DPA','каталог']]},
      {k:'src',l:'Источник креатива',t:'select',d:'UPL',h:'Приписка в названии объявления сразу после формата',o:[['Post','существующий пост из Instagram'],['UPL','ручная загрузка креатива']]},
      {k:'concept',l:'Концепт',t:'text',d:'UGC-Review'},
      {k:'ver',l:'Версия',t:'ver',d:'1'},
      {k:'date',l:'Дата, ГГММДД',t:'date',fmt:'ymd'}]}
  ]},
  google:{label:'Google Ads',levels:[
    {id:'camp',title:'Кампания',fields:[...CAMP_HEAD,
      {k:'type',l:'Тип кампании',t:'select',d:'SRCH',o:[['SRCH','поиск'],['PMAX','Performance Max'],['DGEN','Demand Gen'],['DISP','КМС'],['VID','видео, YouTube'],['SHOP','торговая'],['APP','приложение']]},
      {k:'seg',l:'Сегмент',t:'select',d:'GENERIC',o:SEGMENT},
      {k:'offer',l:'Продукт',t:'text',d:'Tires-Winter'},
      {k:'bid',l:'Стратегия ставок',t:'select',d:'tCPA',o:[['tCPA','целевая цена конверсии'],['tROAS','целевая рентабельность'],['MaxConv','максимум конверсий'],['MaxValue','максимум ценности'],['MaxClicks','максимум кликов'],['mCPC','ручные ставки'],['tIS','целевой процент показов']]},
      {k:'date',l:'Запуск, ГГММ',t:'date',fmt:'ym'}]},
    {id:'group',title:'Группа объявлений или объектов',fields:[
      {k:'theme',l:'Тема',t:'text',d:'Zimnie-Shiny-Kupit'},
      {k:'match',l:'Тип соответствия',t:'select',d:'PH',o:[['EX','точное'],['PH','фразовое'],['BR','широкое'],['MIX','смешанное'],['NA','без ключей']]},
      {k:'aud',l:'Аудитория',t:'select',d:'NA',o:[['NA','без аудитории'],['RMKT','ремаркетинг'],['InMarket','заинтересованные покупатели'],['Custom','особая аудитория'],['CRM','база клиента'],['LAL','похожие']]},
      {k:'lang',l:'Язык',t:'select',d:'RU',o:LANG}]},
    {id:'ad',title:'Объявление',fields:[
      {k:'fmt',l:'Формат',t:'select',d:'RSA',o:[['RSA','адаптивное поисковое'],['RDA','адаптивное медийное'],['IMG','баннер'],['VID','видео'],['CALL','только звонки'],['ASSET','группа объектов PMax']]},
      {k:'concept',l:'Концепт',t:'text',d:'Price-Delivery'},
      {k:'angle',l:'Хук или угол',t:'text',d:'Rassrochka'},
      {k:'lang',l:'Язык',t:'select',d:'RU',o:LANG},
      {k:'ver',l:'Версия',t:'ver',d:'1'},
      {k:'date',l:'Дата, ГГММДД',t:'date',fmt:'ymd'}]}
  ]},
  yandex:{label:'Яндекс Директ',levels:[
    {id:'camp',title:'Кампания',fields:[...CAMP_HEAD,
      {k:'type',l:'Тип кампании',t:'select',d:'SRCH',o:[['SRCH','ЕПК, только поиск'],['RSYA','ЕПК, только РСЯ'],['EPK','ЕПК, поиск и РСЯ'],['MK','Мастер кампаний'],['TK','товарная кампания'],['MEDIA','медийная'],['APP','приложение']]},
      {k:'seg',l:'Сегмент',t:'select',d:'GENERIC',o:SEGMENT},
      {k:'offer',l:'Продукт',t:'text',d:'Tires-Winter'},
      {k:'bid',l:'Стратегия',t:'select',d:'ConvCPA',o:[['ConvCPA','максимум конверсий, оплата за конверсии'],['ConvCPC','максимум конверсий, оплата за клики'],['DRR','целевая доля рекламных расходов'],['Clicks','максимум кликов'],['Manual','ручное управление']]},
      {k:'date',l:'Запуск, ГГММ',t:'date',fmt:'ym'}]},
    {id:'group',title:'Группа объявлений',fields:[
      {k:'theme',l:'Тема',t:'text',d:'Zimnie-Shiny-Kupit'},
      {k:'tgt',l:'Таргетинг',t:'select',d:'KW',o:[['KW','ключевые фразы'],['AUTO','автотаргетинг'],['RMKT','ретаргетинг'],['INT','интересы и привычки'],['LAL','похожие'],['SEG','сегмент Аудиторий']]},
      {k:'geo',l:'Гео',t:'combo',d:'ALA',o:GEO},
      {k:'dev',l:'Устройства',t:'select',d:'All',o:DEVICE}]},
    {id:'ad',title:'Объявление',fields:[
      {k:'fmt',l:'Формат',t:'select',d:'TGO',o:[['TGO','текстово-графическое'],['IMG','графическое'],['VID','видео'],['CAR','карусель'],['TOV','товарное'],['DYN','динамическое']]},
      {k:'concept',l:'Концепт',t:'text',d:'Price-Delivery'},
      {k:'angle',l:'Хук или угол',t:'text',d:'Rassrochka'},
      {k:'lang',l:'Язык',t:'select',d:'RU',o:LANG},
      {k:'ver',l:'Версия',t:'ver',d:'1'},
      {k:'date',l:'Дата, ГГММДД',t:'date',fmt:'ymd'}]}
  ]}
};
const UTM={
  meta:{src:'meta',med:'cpc',s:(s,m,c,g,a)=>'utm_source='+s+'&utm_medium='+m+'&utm_campaign='+c+'&utm_term='+g+'&utm_content='+a,
    n:'Названия кампании, группы и объявления подставлены из блоков выше. Вставьте строку в поле «Параметры URL» в объявлении.'},
  google:{src:'google',med:'cpc',s:(s,m,c,g,a)=>'utm_source='+s+'&utm_medium='+m+'&utm_campaign='+c+'&utm_content='+a+'&utm_term={keyword}',
    n:'Названия кампании и объявления подставлены из блоков выше, в utm_term Google передаст ключевую фразу. Вставьте строку в «Суффикс конечного URL».'},
  yandex:{src:'yandex',med:'cpc',s:(s,m,c,g,a)=>'utm_source='+s+'&utm_medium='+m+'&utm_campaign='+c+'&utm_content='+a+'&utm_term={keyword}',
    n:'Названия кампании и объявления подставлены из блоков выше, в utm_term Директ передаст ключевую фразу. Вставьте строку в «Параметры URL».'}
};

const TR={'а':'a','б':'b','в':'v','г':'g','д':'d','е':'e','ё':'e','ж':'zh','з':'z','и':'i','й':'y','к':'k','л':'l','м':'m','н':'n','о':'o','п':'p','р':'r','с':'s','т':'t','у':'u','ф':'f','х':'kh','ц':'ts','ч':'ch','ш':'sh','щ':'sch','ъ':'','ы':'y','ь':'','э':'e','ю':'yu','я':'ya','ә':'a','ғ':'g','қ':'q','ң':'n','ө':'o','ұ':'u','ү':'u','һ':'h','і':'i'};
function clean(v){
  let out='';
  for(const ch of String(v||'').trim()){
    const lo=ch.toLowerCase();
    if(lo in TR){const t=TR[lo];out+=(ch!==lo&&t)?t[0].toUpperCase()+t.slice(1):t;}
    else out+=ch;
  }
  out=out.replace(/[\s_]+/g,'-').replace(/[^A-Za-z0-9.+%-]/g,'').replace(/-+/g,'-').replace(/^-|-$/g,'');
  return out||'NA';
}

export {P as namingPlatforms,UTM as namingUTM,GEO as namingGeo,clean as namingClean};
export function namingDate(fmt,now=new Date()){
 const date=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Qyzylorda',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now),part=type=>date.find(p=>p.type===type).value;
 return part('year').slice(-2)+part('month')+(fmt==='ymd'?part('day'):'');
}
export function createNamingDraft(now=new Date()){
 const fields={},utm={};for(const [p,schema] of Object.entries(P)){utm[p]={source:UTM[p].src,medium:UTM[p].med};for(const level of schema.levels)for(const f of level.fields)fields[p+'.'+level.id+'.'+f.k]=f.t==='date'?namingDate(f.fmt,now):structuredClone(f.d);}
 return {platform:'meta',fields,utm};
}
export function normalizeNamingDraft(raw,now=new Date()){
 const draft=createNamingDraft(now);if(!raw||typeof raw!=='object')return draft;if(Object.hasOwn(P,raw.platform))draft.platform=raw.platform;
 for(const [p,schema] of Object.entries(P)){for(const lv of schema.levels)for(const f of lv.fields){const key=p+'.'+lv.id+'.'+f.k,v=raw.fields?.[key];if(v===undefined)continue;
 if(f.t==='multi'){if(Array.isArray(v))draft.fields[key]=f.o.map(o=>o[0]).filter(x=>v.includes(x));}
 else if(f.t==='ga'){if(Array.isArray(v)&&v.length===3)draft.fields[key]=[(['All','M','F'].includes(v[0])?v[0]:'All'),String(v[1]).slice(0,3),String(v[2]).slice(0,3)];}
 else if(f.t==='select'){if(f.o.some(o=>o[0]===v))draft.fields[key]=v;}
 else if(typeof v==='string'||typeof v==='number')draft.fields[key]=String(v).slice(0,160);
 }for(const k of ['source','medium'])if(typeof raw.utm?.[p]?.[k]==='string')draft.utm[p][k]=raw.utm[p][k].slice(0,100);}
 return draft;
}
export function fieldValue(draft,p,lv,f){const v=draft.fields[p+'.'+lv.id+'.'+f.k];if(f.t==='select')return v;
 if(f.t==='multi'){const pick=f.o.map(o=>o[0]).filter(c=>v.includes(c));return pick.length?pick.join('-'):'NA';}
 if(f.t==='ver')return 'v'+Math.max(1,parseInt(v,10)||1);
 if(f.t==='ga')return v[0]+(parseInt(v[1],10)||18)+'-'+(parseInt(v[2],10)||65);
 return clean(v);
}
export function namingParts(draft,level,p=draft.platform){const lv=P[p].levels.find(l=>l.id===level);return lv.fields.map(f=>({key:f.k,value:fieldValue(draft,p,lv,f)}));}
export const namingName=(draft,level,p=draft.platform)=>namingParts(draft,level,p).map(s=>s.value).join('_');
export function namingErrors(draft,level,p=draft.platform){const lv=P[p].levels.find(l=>l.id===level),errors=[];for(const f of lv.fields){const v=draft.fields[p+'.'+level+'.'+f.k];
 if(f.t==='ga'&&(!v.slice(1).every(x=>/^\d+$/.test(x)&&Number(x)>=13&&Number(x)<=65)||+v[1]>+v[2]))errors.push('Укажите возраст от 13 до 65 лет; нижняя граница не должна превышать верхнюю.');
 if(f.t==='date'&&v){const length=f.fmt==='ym'?4:6;if(!new RegExp('^\\d{'+length+'}$').test(v))errors.push(f.l+': используйте '+length+' цифр.');else {const year=2000+Number(v.slice(0,2)),month=Number(v.slice(2,4)),day=f.fmt==='ym'?1:Number(v.slice(4,6));const d=new Date(Date.UTC(year,month-1,day));if(d.getUTCFullYear()!==year||d.getUTCMonth()!==month-1||d.getUTCDate()!==day)errors.push(f.l+': такой даты нет.');}}
 }return errors;}
export function toggleNamingSelection(field,previous,code,checked){const sub=field.sub||field.o.map(o=>o[0]).filter(c=>c!==field.all);let result=previous.filter(c=>c!==code);if(checked){result.push(code);if(code===field.all)result=result.filter(c=>!sub.includes(c));else if(sub.includes(code))result=result.filter(c=>c!==field.all);}return field.o.map(o=>o[0]).filter(c=>result.includes(c));}
export function namingQuery(draft,p=draft.platform){const enc=level=>encodeURIComponent(namingName(draft,level,p)),source=encodeURIComponent(clean(draft.utm[p].source)),medium=encodeURIComponent(clean(draft.utm[p].medium));return 'utm_source='+source+'&utm_medium='+medium+'&utm_campaign='+enc('camp')+(p==='meta'?'&utm_term='+enc('group')+'&utm_content='+enc('ad'):'&utm_content='+enc('ad')+'&utm_term={keyword}');}
export function normalizeNamingList(rows){if(!Array.isArray(rows))return [];return rows.slice(0,1000).flatMap(r=>{if(!r||typeof r!=='object')return [];const p=Object.keys(P).find(p=>p===r.platform||P[p].label===r.p),lv=P[p]?.levels.find(l=>l.id===r.level||l.title===r.l),name=r.name??r.n;if(!p||!lv||typeof name!=='string'||name.length>3000)return [];return [{id:typeof r.id==='string'?r.id:crypto.randomUUID(),platform:p,level:lv.id,name,createdAt:r.createdAt||''}];});}
export const namingListTSV=rows=>rows.map(r=>[P[r.platform].label,P[r.platform].levels.find(l=>l.id===r.level).title,r.name].map(x=>String(x).replace(/[\t\r\n]/g,' ')).join('\t')).join('\n');
