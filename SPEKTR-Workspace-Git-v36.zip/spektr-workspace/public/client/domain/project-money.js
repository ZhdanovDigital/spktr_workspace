// Rates are KZT for one unit of the named currency, never an inferred market rate.
export function normalizeExchangeRates(input){
 if(!input||input.base!=='KZT'||!input.rates||typeof input.rates!=='object'||Array.isArray(input.rates))return null;
 const rates={KZT:1};
 for(const [currency,value] of Object.entries(input.rates)){
  if(!/^[A-Z]{3}$/.test(currency)||typeof value!=='number'||!Number.isFinite(value)||value<=0||value>1e8)return null;
  if(currency==='KZT'&&value!==1)return null;rates[currency]=value;
 }
 if(typeof input.asOf!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(input.asOf)||!Number.isFinite(Date.parse(input.asOf))||new Date(input.asOf).toISOString().slice(0,10)!==input.asOf)return null;
 return {base:'KZT',rates,asOf:input.asOf,source:typeof input.source==='string'?input.source.slice(0,120):'База данных'};
}
export function projectSpend(accounts,metricFor,exchange){
 const rows=accounts.map(a=>({currency:a.currency,...metricFor(a)}));
 const total=target=>{
  if(!rows.length||rows.some(r=>r.spend==null||!Number.isFinite(r.spend)))return null;
  let sum=0;for(const row of rows){if(row.currency===target){sum+=row.spend;continue;}const from=exchange?.rates[row.currency],to=target==='KZT'?1:exchange?.rates[target];if(!from||!to)return null;sum+=row.spend*from/to;}return sum;
 };
 return {kzt:total('KZT'),usd:total('USD'),partial:rows.some(r=>!r.complete),requiresRate:rows.some(r=>r.currency!=='KZT')||rows.length>0};
}
export const budgetDayTone=days=>days==null||!Number.isFinite(days)?'unknown':days<7?'low':days>7?'safe':'boundary';
