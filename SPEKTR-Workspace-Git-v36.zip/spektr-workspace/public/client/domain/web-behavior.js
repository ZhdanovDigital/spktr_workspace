const nonnegative=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0;
// GA4: non-engaged sessions. Metrika: use its own bounce definition from the source.
export function bounceCount(row,provider){
 if(!nonnegative(row.sessions))return null;
 if(row.bounces!=null)return nonnegative(row.bounces)&&row.bounces<=row.sessions?row.bounces:null;
 return provider==='ga4'&&nonnegative(row.engagedSessions)&&row.engagedSessions<=row.sessions?row.sessions-row.engagedSessions:null;
}
