import {isoDate,shiftDate} from './dates.js';
import {alerts,periods} from './metrics.js';
import {accountMetrics} from './analytics.js';

export const statusLabels={todo:'К выполнению',progress:'В работе',review:'На проверке',done:'Выполнено',cancelled:'Отменено'};
export const kindLabels={review:'Проверка рекламы',optimization:'Оптимизация',budget:'Бюджет',tracking:'Аналитика и цели',creative:'Креативы',report:'Отчёт',other:'Другое'};
export const checklistItems=['Бюджеты и темп расходов','Поисковые запросы / аудитории','Результаты и цена конверсии','Креативы и статусы объявлений','Цели и актуальность данных','Изменения внесены в журнал'];
export const openTask=t=>!['done','cancelled'].includes(t.status);
export function taskDueAt(task){const time=/^\d{2}:\d{2}$/.test(task.time||'')?task.time:'18:00';return new Date(task.due+'T'+time+':00+05:00').getTime();}
export const overdue=(task,now=Date.now())=>openTask(task)&&taskDueAt(task)<now;
export function nextDue(date,repeat,anchorDay=null){if(repeat==='daily')return shiftDate(date,1);if(repeat==='weekly')return shiftDate(date,7);if(repeat==='monthly'){const d=new Date(date+'T00:00:00Z'),day=anchorDay||d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+1);const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(day,last));return d.toISOString().slice(0,10);}return null;}
export function logInPeriod(logs,period){return logs.filter(l=>l.date>=period.from&&l.date<=period.to);}
export function composePrompt(config,modules,client,selectedIds=[]){
  const chosen=modules.filter(p=>p.active!==false&&selectedIds.includes(p.id)&&(!p.client||p.client===client.id)&&(!p.platform||client.accounts.some(a=>a.platform===p.platform)));
  const order={agency:0,client:1,platform:2,format:3};chosen.sort((a,b)=>(order[a.scope]??4)-(order[b.scope]??4));
  if(chosen.filter(p=>p.scope==='format').length>1)throw new Error('Для отчёта выберите один модуль формата.');
  const layers=chosen.map(p=>({id:p.id,name:p.name,scope:p.scope,revision:p.revision||1,content:p.content}));
  return {prompt:config.prompt||'',skill:[config.skill||'',...layers.map(p=>'['+p.name+' · '+p.scope+']\n'+p.content)].filter(Boolean).join('\n\n'),layers};
}
export function accountIssues(client,settings){
  const result=[];const ratio=settings.cpaPercent??30,min=settings.minResults??5;
  for(const a of client.accounts){
    if(a.state!=='fresh'||client.dataOrigin==='database'&&(Date.now()-Date.parse(a.updated))/3600000>(settings.staleHours??24))continue;
    const ref=isoDate(new Date(a.asOf||new Date())),to=shiftDate(ref,-1),from=shiftDate(to,-6),prevTo=shiftDate(from,-1),prevFrom=shiftDate(prevTo,-6);
    const p={from,to,previousFrom:prevFrom,previousTo:prevTo};const m=accountMetrics(a,p),old=accountMetrics(a,p,true);
    if(m.days===7&&old.days===7&&m.conversions>=min&&old.conversions>=min&&m.cpa!=null&&old.cpa>0&&((m.cpa/old.cpa)-1)*100>ratio)
      result.push({id:a.id+'-cpa-growth',client:client.id,level:'warning',title:'Цена результата выросла',source:a.platform,detail:`За 7 полных дней рост на ${Math.round((m.cpa/old.cpa-1)*100)}% к предыдущим 7 дням · порог ${ratio}%. Причина требует проверки.`,tab:'accounts'});
  }return result;
}
export function operationalIssues(clients,R){
  const tasks=R.tasks(),result=[];
  for(const c of clients){const settings=R.settings(c.id);for(const a of [...alerts(c,settings,R.activePlan(c.id)),...accountIssues(c,settings)])result.push({...a,client:c.id,key:c.id+':'+a.id});
    const clientTasks=tasks.filter(t=>t.client===c.id),due=clientTasks.filter(t=>overdue(t));
    for(const t of due)result.push({id:'task-'+t.id,key:'task:'+t.id,client:c.id,level:'critical',title:'Просрочена задача',source:t.platform,detail:t.title+' · '+t.assignee+' · срок '+t.due,taskId:t.id});
    if(!clientTasks.some(t=>t.kind==='review'&&openTask(t)))result.push({id:'no-review',key:c.id+':no-review',client:c.id,level:'info',title:'Нет запланированной проверки',source:'team',detail:'Назначьте следующую проверку рекламы и ответственного.'});
  }
  return result.sort((a,b)=>({critical:0,warning:1,info:2}[a.level]??3)-({critical:0,warning:1,info:2}[b.level]??3));
}
