import {allAccountDays} from './analytics.js';
import {dayCount,shiftDate} from './dates.js';
import {divide,ratioPct} from './metrics.js';
export const accountChartMetrics={
 spend:{label:'Расход',color:'#8465df',unit:'money'},conversions:{label:'Результаты',color:'#16a084',unit:'count'},cpa:{label:'Цена результата',color:'#e78a37',unit:'money'},cr:{label:'CR',color:'#d45aab',unit:'percent'},impressions:{label:'Показы',color:'#4586e9',unit:'count'},clicks:{label:'Клики',color:'#13a9c1',unit:'count'},ctr:{label:'CTR',color:'#b39a29',unit:'percent'},cpc:{label:'CPC',color:'#e45f6d',unit:'money'}
};
export const accountChartScope=(client,account)=>JSON.stringify([client.dataOrigin||'demonstration',client.id,account.id]);
export const chartGranularity=(p,mode='auto')=>mode==='day'||mode==='week'?mode:dayCount(p)>45?'week':'day';
export function accountChartSeries(account,p,mode='auto'){
 const n=dayCount(p);if(!Number.isSafeInteger(n)||n<1||n>366)return {granularity:'day',bins:[]};const granularity=chartGranularity(p,mode),days=new Map(allAccountDays(account).map(r=>[r.date,r])),groups=new Map();
 for(let i=0;i<n;i++){const date=shiftDate(p.from,i),weekday=(new Date(date+'T12:00:00Z').getUTCDay()+6)%7,key=granularity==='week'?shiftDate(date,-weekday):date;const group=groups.get(key)||[];group.push(date);groups.set(key,group)}
 const bins=[...groups.values()].map(dates=>{const rows=dates.map(d=>days.get(d)),total=key=>rows.every(r=>r&&Number.isFinite(r[key])&&r[key]>=0)?rows.reduce((s,r)=>s+r[key],0):null,spend=total('spend'),clicks=total('clicks'),impressions=total('impressions'),conversions=total('conversions');return {from:dates[0],to:dates.at(-1),days:dates.length,availableDays:rows.filter(Boolean).length,spend,clicks,impressions,conversions,cpa:divide(spend,conversions),cpc:divide(spend,clicks),cr:ratioPct(conversions,clicks),ctr:ratioPct(clicks,impressions)}});
 return {granularity,bins};
}
export function selectedAccountMetrics(preferences){return Array.isArray(preferences)?[...new Set(preferences.filter(key=>Object.hasOwn(accountChartMetrics,key)))]:['spend','conversions']}
