export const TASK_FILE_MAX_BYTES=10*1024*1024;
export const TASK_FILE_MAX_COUNT=10;
export const TASK_FILES_MAX_BYTES=50*1024*1024;
export const taskFileIdOK=id=>typeof id==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(id);
export function attachmentReferencesOK(files){
 if(!Array.isArray(files)||files.length>TASK_FILE_MAX_COUNT)return false;
 const ids=new Set();let total=0;
 for(const file of files){if(!file||!taskFileIdOK(file.id)||ids.has(file.id)||typeof file.name!=='string'||!file.name||file.name.length>200||!Number.isSafeInteger(file.size)||file.size<0||file.size>TASK_FILE_MAX_BYTES)return false;ids.add(file.id);total+=file.size;}
 return total<=TASK_FILES_MAX_BYTES;
}
export const taskFileSize=bytes=>bytes>=1048576?(bytes/1048576).toLocaleString('ru-RU',{maximumFractionDigits:1})+' МБ':bytes>=1024?Math.ceil(bytes/1024)+' КБ':bytes+' Б';
