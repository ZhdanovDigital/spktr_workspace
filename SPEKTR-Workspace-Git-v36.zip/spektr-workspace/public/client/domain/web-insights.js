import {webDailySeries} from './web-dashboard.js';
export function weekdayPerformance(source,p){
 const days=webDailySeries(source,p),labels=['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];
 return labels.map((label,i)=>{const rows=days.filter(r=>(new Date(r.date+'T12:00:00Z').getUTCDay()+6)%7===i),loaded=rows.filter(r=>r.sessions!=null),sessions=loaded.length?loaded.reduce((n,r)=>n+r.sessions,0):null,valid=loaded.length>0&&loaded.every(r=>r.goalSessions!=null),goals=valid?loaded.reduce((n,r)=>n+r.goalSessions,0):null;return {label,sessions,goalSessions:goals,cr:goals!=null&&sessions>0?goals/sessions*100:null,loaded:loaded.length,expected:rows.length};});
}
export function qualityTrend(source,p){return webDailySeries(source,p).map(r=>({...r,cr:r.sessions>0&&r.goalSessions!=null?r.goalSessions/r.sessions*100:null}));}
