export const clientFolderKey=c=>'clientFolders.'+(c.dataOrigin==='database'?'database':'demonstration')+'.'+encodeURIComponent(c.id);
export function driveFolderURL(value){
 if(typeof value!=='string'||!value.trim()||value.length>2000)return null;
 try{const u=new URL(value.trim());if(u.protocol!=='https:'||u.hostname!=='drive.google.com'||u.username||u.password||u.port||!/^\/drive\/(?:u\/\d+\/)?folders\/[a-zA-Z0-9_-]+\/?$/.test(u.pathname)||u.hash)return null;return u.href}catch{return null}
}
