import {installTaskEditor,finishTaskAttachments} from './ui/task-editor.js';
import {installExchange} from './ui/exchange.js';
import {installClientControl} from './ui/client-control.js';
import {animateWorkspace} from './ui/motion.js';
import {installMediaPlan} from './ui/media-plan.js';
import {installAccountCharts} from './ui/account-charts.js';
import {installClientFolders} from './ui/client-folders.js';
import {installOneC} from './ui/onec.js';
import {oneCSnapshot,oneCReportText} from './domain/onec.js';
import {reportFileName} from './domain/report-files.js';
import {installWebGoals} from './ui/web-goals.js';
import {installClientFavicons} from './ui/client-favicon.js';
import {installBudgets} from './ui/budget-plan.js';
import {installMarketingDashboard} from './ui/marketing-dashboard.js';
import {installWebCharts} from './ui/web-charts.js';
import {namingGeneratorPage,installNamingGenerator} from './ui/naming-generator.js';
import {semanticsPage,installSemantics} from './semantic/ui.js';
import {workspaceHeader,routeTitle,activeRoute,installHeaderNavigation,dismissSettingsMenu} from './ui/navigation.js';
import {analyticsReportText} from './domain/report.js';
import {installClientSettings} from './ui/client-admin.js';
import {initializeTheme,toggleTheme,themeControl} from './ui/theme.js';
import {positionDatePopover} from './ui/calendar.js';
import {installFeatures} from './features.js';
import {installTeam,initializeReport,captureReportInputs} from './team-features.js';
import {tasksPage,journalPage,promptsPage,sharedBadge,teamIssues} from './ui/team.js';
import {logInPeriod} from './domain/operations.js';
import {periodCaption,setCustomPeriod,isoDate,dayCount} from './domain/dates.js';
import {accountMetrics,webMetrics} from './domain/analytics.js';
import {repository as R} from './data/repository.js';
import {platforms,briefQuestions,defaultPlanRows} from './data/demo.js';
import {metrics,periods,validateSales,alerts,range,sum} from './domain/metrics.js';
import {generateNames} from './domain/naming.js';
import {exportXLSX,readSpreadsheet,download} from './domain/spreadsheet.js';
import {S,currentClient} from './ui/state.js';
import {e,fmt,money,currencyMoney,pct,icon,button,empty} from './ui/components.js';
import {projectsPage} from './ui/projects.js';
import {clientPage} from './ui/client.js';
import {planPage,integrationsPage,settingsPage,reportsPage} from './ui/tools.js';
import {modalHTML} from './ui/modals.js';
initializeTheme();
installClientControl();
installClientFavicons();
const app=document.getElementById('app'),modalRoot=document.getElementById('modal-root');
let toastTimer,modalOpener=null;
function toast(message){const node=document.getElementById('toast');node.textContent=message;node.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.classList.remove('show'),5000)}
function render(){
 const active=document.activeElement,id=active?.id;let start=null,end=null;try{start=active?.selectionStart;end=active?.selectionEnd}catch{}
 const scroll=document.querySelector('.modal')?.scrollTop||0,dateScroll=document.querySelector('.date-popover')?.scrollTop||0;
 const pages={semantics:semanticsPage,projects:projectsPage,client:clientPage,tasks:tasksPage,journal:journalPage,prompts:promptsPage,plan:planPage,naming:namingGeneratorPage,integrations:integrationsPage,settings:settingsPage,reports:reportsPage};
 const title=S.route==='client'?currentClient().name:routeTitle(S.route);
 const user=R.sharedUser?.name||'Команда',attention=teamIssues().filter(i=>i.level!=='info').length;
 document.title=`${title} — SPEKTR Workspace`;
 app.innerHTML=`${workspaceHeader({user,attention})}<main class="workspace">${R.sharedError?`<div class="notice error shared-warning">${e(R.sharedError)} ${button('Проверить сохранение','team-sync','ghost small')}</div>`:''}${(pages[S.route]||projectsPage)()}</main>`;
 animateWorkspace(app,`${S.route}/${S.client||''}/${S.tab||''}`);
 modalRoot.innerHTML=modalHTML();app.inert=!!S.modal;document.body.style.overflow=S.modal?'hidden':'';
 if(S.modal){const modal=document.querySelector('.modal');if(modal)modal.scrollTop=scroll;}
 positionDatePopover();
 const datePanel=document.querySelector('.date-popover');if(datePanel)datePanel.scrollTop=dateScroll;
 if(id){const replacement=document.getElementById(id);replacement?.focus({preventScroll:true});try{replacement?.setSelectionRange(start,end)}catch{}}
}
function navigate(route){if(location.hash===`#/${route}`)parseRoute();else location.hash=`#/${route}`}
function parseRoute(){const [route,id]=location.hash.replace(/^#\/?/,'').split('/');S.route=activeRoute(route||'projects');if(S.route!==route&&['ads'].includes(route))history.replaceState(null,'','#/projects');S.settingsMenuOpen=false;S.workMenuOpen=false;if(S.route==='naming')S.namingReturn=null;if(S.route==='client'){S.client=id?decodeURIComponent(id):R.clients()[0]?.id||'';S.tab='overview';S.accountFilter='all';S.clientTaskState='active';S.analyticsSource='auto';S.expanded=null;}S.modal=null;S.dateOpen=false;render();window.scrollTo({top:0,behavior:'instant'})}
function openModal(name){dismissSettingsMenu();S.dateOpen=false;modalOpener=document.activeElement;if(S.modal&&S.modal!==name&&['ai-settings','google-export-settings'].includes(name))S.modalReturn=S.modal;S.modal=name;if(name==='import'){S.uploadRows=[];S.uploadErrors=[]}render();requestAnimationFrame(()=>document.querySelector('.modal input,.modal textarea,.modal select,.modal button')?.focus())}
function closeModal(){if(S.aiBusy||S.teamBusy){toast('Дождитесь завершения запроса');return}if(S.modal==='task-edit'&&S.taskDraft)finishTaskAttachments(S.taskDraft);S.modal=S.modalReturn||null;S.modalReturn=null;S.dateOpen=false;render();if(modalOpener?.isConnected)modalOpener.focus();else document.querySelector('main button')?.focus({preventScroll:true})}
function saveData(key,value,message){R.write(key,value);if(message)toast(message)}
function id(){return crypto.randomUUID()}
const safeURL=(url)=>{try{const v=new URL(url);return ['https:','http:'].includes(v.protocol)}catch{return false}};
async function sync(){if(S.busy)return;S.busy=true;openModal('sync');try{S.syncResults=await R.sync(S.client,periods[S.period]);toast(R.runtime.database||R.read('dataSource',{}).enabled?'Данные из БД обновлены':'Демоснимок проверен')}catch(err){toast(err.message)}finally{S.busy=false;render()}}
function beginReport(el){S.reportClient=null;S.reportArchived=false;if(el?.dataset.client)S.client=el.dataset.client;if(!currentClient().id){toast('Сначала загрузите или выберите клиента');return}S.reportClient=currentClient();S.modalReturn=null;S.aiError='';S.exportResult=null;S.aiConsent=false;S.reportGeneratedBy=null;S.reportId=null;S.reportDate=isoDate();S.reportFileName=reportFileName({reportDate:S.reportDate},currentClient());S.reportStatus='draft';S.brief=Array(6).fill('');S.step=1;S.reportPeriod=S.period;S.reportText='';S.confirmLogs=true;initializeReport();openModal('report')}
function reportText(){const c=currentClient(),p=periods[S.reportPeriod],m=metrics(c,p),old=metrics(c,p,true);const rows=c.accounts.map(a=>{const v=accountMetrics(a,p);return `${platforms[a.platform].name} (${a.currency}) — расход ${fmt(v.spend)}, переходы ${fmt(v.clicks)}, CTR ${pct(v.ctr)}, ${v.resultsLabel}: ${fmt(v.conversions)}, CR ${pct(v.cr)}, цена результата ${fmt(v.cpa)}. Статус: ${a.state}.`});const analytics=analyticsReportText(c,p,R.settings(c.id));return `${c.name}\nОтчёт за ${periodCaption(S.reportPeriod)}\n${c.dataOrigin==='database'?'Данные подключённой БД':'ДЕМОНСТРАЦИОННЫЕ ДАННЫЕ'}\nЧерновик по данным и брифу · без ИИ\n\nАНАЛИТИКА САЙТА\n${analytics}\n\nОБЩАЯ СВОДКА РЕКЛАМЫ\nРасход по загруженным данным: ${currencyMoney(m.spend,m.currency)}${m.adComplete?'':' · период покрыт не полностью'}. Переходы: ${fmt(m.clicks)}. CTR: ${pct(m.ctr)}.\n\nРЕКЛАМНЫЕ КАБИНЕТЫ\n${rows.join('\n')}\n\nДАННЫЕ 1С\n${oneCReportText(oneCSnapshot(c.oneCRecord,p))}\n\nДАННЫЕ КЛИЕНТА\nФактические лиды: ${fmt(m.leads)}. Квалифицированные: ${fmt(m.qualified)}. CPL: ${currencyMoney(m.cpl,m.currency)}. Продажи: ${fmt(m.sales)}.${m.revenue===null?'\nВыручка не предоставлена; окупаемость не оценивается.':`\nВыручка: ${money(m.revenue)}. ROAS: ${m.roas===null?'не рассчитывается':fmt(m.roas,2)+'×'}. ДРР: ${pct(m.drr)}.`}\n\nСРАВНЕНИЕ\nПредыдущий период: ${p.previousFrom} — ${p.previousTo}. CPL: ${currencyMoney(old.cpl,old.currency)} → ${currencyMoney(m.cpl,m.currency)}.\n\n${briefQuestions.map((q,i)=>q.toUpperCase()+'\n'+(S.brief[i]||'Нет информации')).join('\n\n')}\n\nЖУРНАЛ ИЗМЕНЕНИЙ ЗА ПЕРИОД\n${S.confirmLogs?logInPeriod(R.logs(c.id),p).map(l=>l.date+' · '+l.manager+' · '+l.text+'\nЦель: '+l.goal+'. Результат: '+l.result+' · '+l.status).join('\n')||'Записей за период нет':'Журнал не включён в этот отчёт'}\n\nОГРАНИЧЕНИЯ\n${m.partial?'Есть неполные или устаревшие источники. ':''}Конверсии кабинетов не суммируются как уникальные лиды. Отсутствующие значения не заменяются нулями. Причины изменений без подтверждения не устанавливаются.`}
async function persistReport(status,{keepOpen=false}={}){
 if(S.teamSavingReport)throw Error('Отчёт уже сохраняется');S.teamSavingReport=true;try{
 if(!S.reportDataSnapshot)captureReportInputs();
 if(!S.reportId)S.reportId=id();
 S.reportDate=S.reportDate||isoDate();S.reportFileName=S.reportFileName||reportFileName({reportDate:S.reportDate},currentClient());
 await R.saveReport({id:S.reportId,fileName:S.reportFileName,reportDate:S.reportDate,client:S.client,clientName:currentClient().name,period:periodCaption(S.reportPeriod),periodKey:S.reportPeriod,periodRange:{...periods[S.reportPeriod]},generatedBy:S.reportGeneratedBy,ai:S.reportAI,exportResult:S.exportResult,brief:[...S.brief],text:S.reportText||reportText(),step:S.step,status,updated:new Date().toISOString(),origin:currentClient().dataOrigin||'demonstration',selectedModules:S.reportPromptIds||[],promptSnapshot:S.reportPromptSnapshot||null,dataSnapshot:S.reportDataSnapshot||null,includeLogs:S.confirmLogs});
 S.reportStatus=status;toast(status==='draft'?'Черновик сохранён в команде':'Отчёт сохранён в команде');if(status==='ready'&&!keepOpen)closeModal();else render();
 }finally{S.teamSavingReport=false}
}
function printReport(preopened,saved){const w=preopened?.document?preopened:window.open('','_blank');if(!w){toast('Разрешите всплывающее окно для печати PDF');return}w.document.write('<!doctype html><html lang="ru"><head><meta charset="UTF-8"><title>'+e(saved?reportFileName(saved,R.clients().find(c=>c.id===saved.client)||{}):S.reportFileName||reportFileName({reportDate:S.reportDate},currentClient()))+'</title><style>body{font:11px/1.5 Arial,sans-serif;color:#2c3040;margin:24px}pre{white-space:pre-wrap;font:inherit}h1{color:#4e49ae;font-size:24px} @page{margin:14mm}</style></head><body><h1>SPEKTR / Отчёт</h1><pre>'+e(saved?saved.text:S.reportText)+'</pre></body></html>');w.document.close();w.focus();setTimeout(()=>w.print(),200)}
function accountsSheet(periodKey=S.period){const c=currentClient();return [['Platform','Account','Currency','Spend','Impressions','Clicks','Platform conversions','State','Balance','Monthly plan'],...c.accounts.map(a=>{const r=range([...new Map([...(a.history||[]),...(a.days||[])].map(d=>[d.date,d])).values()],periods[periodKey]);return [platforms[a.platform].name,a.name,a.currency,r.length?sum(r,'spend'):'',r.length?sum(r,'impressions'):'',r.length?sum(r,'clicks'):'',r.length?sum(r,'conversions'):'',a.state,a.balance??'',a.plan]})]}
function salesSheet(template=false){const columns=['date','source','leads','qualified','poor','unrated','sales','revenue','attributed','comment'];return [columns,...(template?[{date:isoDate(),source:'unknown',leads:10,qualified:6,poor:2,unrated:2,sales:1,revenue:50000,attributed:false,comment:'Пример — замените своими данными'}]:currentClient().sales).map(r=>columns.map(k=>typeof r[k]==='boolean'?String(r[k]):r[k]??''))]}
function exportStructure(){const keywords=R.keywords(S.client);if(!keywords.length){toast('Сначала добавьте ключевые слова');return}const ads=R.ads(S.client);const rows=keywords.filter(k=>!k.excluded).flatMap(k=>{const variants=ads.filter(a=>a.group===k.group&&a.campaign===k.campaign);return (variants.length?variants:[null]).map(a=>[a?.platform||'',k.campaign,k.group,k.text,k.match,...(a?.headlines||['','','']),...(a?.descriptions||['','']),a?.url||'',a?.utm||'',a?.cta||'',a?.sitelinks[0]?.text||'',a?.sitelinks[0]?.url||''])});exportXLSX('SPEKTR-Структура-аккаунта.xlsx',{'Структура':[['Platform','Campaign','Ad Group','Keyword','Match Type','Headline 1','Headline 2','Headline 3','Description 1','Description 2','Final URL','UTM','CTA','Sitelink','Sitelink URL'],...rows],'Минус-слова':[['Campaign','Ad Group','Negative keyword'],...keywords.filter(k=>k.excluded).map(k=>[k.campaign,k.group,k.text])],'Проверка':[['Перед загрузкой'],['Рабочая структура для ручного переноса, не файл прямого импорта.'],['Проверьте обязательные поля, длину текста, URL и правила площадки.'],['Пустые тексты означают, что объявление для группы ещё не сохранено.'],['Частотность не получена из API.']]});toast('XLSX подготовлен. Перед загрузкой проверьте формат кабинета.')}
function loadAd(group=S.adGroup,platform=S.adPlatform){const found=R.ads(S.client).find(a=>a.group===group&&a.platform===platform);S.ad=found?structuredClone(found):{headlines:['','',''],descriptions:['',''],url:'https://'+currentClient().site,utm:`utm_source=${platform}&utm_medium=cpc`,cta:'Узнайте подробнее',sitelinks:[]};S.adGroup=group;S.adPlatform=platform}
function adErrors(){const ad=S.ad,limits=S.adPlatform==='google'?[30,30,30]:[56,30,56],desc=S.adPlatform==='google'?90:81;const errors=[];if(!S.adGroup)errors.push('Сначала выберите группу');if(ad.headlines.some(x=>!x.trim())||ad.descriptions.some(x=>!x.trim()))errors.push('Заполните все заголовки и описания');ad.headlines.forEach((x,i)=>{if([...x].length>limits[i])errors.push('Заголовок '+(i+1)+' превышает лимит')});ad.descriptions.forEach((x,i)=>{if([...x].length>desc)errors.push('Описание '+(i+1)+' превышает лимит')});if(!safeURL(ad.url))errors.push('Укажите полный URL посадочной страницы');if(ad.sitelinks[0]?.text&&!safeURL(ad.sitelinks[0]?.url))errors.push('Укажите URL быстрой ссылки');return errors}
const actions={
 'toggle-theme':()=>{toggleTheme();render();document.getElementById('theme-toggle')?.focus({preventScroll:true})},
 close:closeModal,
 'client':el=>navigate('client/'+encodeURIComponent(el.dataset.id)),
 'filter':el=>{S.filter=el.dataset.value;render()},
 'filter-attention':()=>{S.filter='attention';render()},
 'notifications':()=>{S.filter='attention';navigate('projects')},
 'reset-filters':()=>{S.search='';S.filter='all';S.manager='all';S.platform='all';S.sort='priority';S.modal=null;render()},
 'filters':()=>openModal('filters'),
 'new-project':()=>openModal('new-project'),
 'sync':sync,'sync-all':sync,
 'client-tab':el=>{S.tab=el.dataset.value;render()},
 'thresholds':()=>openModal('thresholds'),
 'alert-details':el=>{S.alertID=el.dataset.id;openModal('alert')},
 'alert-go':el=>{S.tab=el.dataset.value;closeModal()},
 'expand':el=>{S.expanded=S.expanded===el.dataset.id?null:el.dataset.id;render()},
 'report':beginReport,
 'reports-client':el=>{S.client=el.dataset.id;S.reportOrigin=el.dataset.origin;render()},
 'print-saved-report':el=>{const r=R.reports().find(r=>r.id===el.dataset.id);if(r)printReport(null,r)},
 'download-saved-report':el=>{const r=R.reports().find(r=>r.id===el.dataset.id);if(!r)return;download(reportFileName(r,R.clients().find(c=>c.id===r.client)||{})+'.txt',r.text,'text/plain;charset=utf-8')},
 'report-back':()=>{S.step--;render()},
 'report-next':()=>{if(S.step===2&&S.brief.some(b=>!b.trim())){toast('Заполните ответы или выберите «Нет информации»');return}if(S.step===2)S.reportText=reportText();S.step++;render();document.querySelector('.modal').scrollTop=0},
 'brief-fill':el=>{S.brief[Number(el.dataset.index)]=el.dataset.value;render()},
 'use-logs':()=>{if(!S.confirmLogs)return;const logs=R.logs(S.client);if(!logs.length){toast('Журнал пока пуст');return}S.brief[1]=logs.map(l=>`${l.date}: ${l.text}. Цель: ${l.goal}. ${l.result}`).join('\n');render();toast('Подтверждённые записи добавлены в бриф')},
 'save-report-draft':()=>persistReport('draft'),
 'finish-report':()=>persistReport('ready'),
 'print-report':printReport,
 'open-report':el=>{const r=R.reports().find(r=>r.id===el.dataset.id);if(!r)return;S.client=r.client;const live=R.clients().find(c=>c.id===r.client&&(!r.origin||c.dataOrigin===r.origin));S.reportArchived=!live;S.reportClient=live||{...(r.dataSnapshot?.client||{}),id:r.client,name:r.clientName||r.dataSnapshot?.client?.name||r.client,dataOrigin:r.origin,accounts:[],analytics:[],sales:[],previous:[],targets:{}};S.reportId=r.id;S.reportDate=r.reportDate||(r.updated||isoDate()).slice(0,10);S.reportFileName=reportFileName(r,currentClient());S.reportStatus=r.status;S.brief=r.brief;S.reportPeriod=r.periodKey in periods?r.periodKey:'this_month';if(r.periodRange){periods.report_custom={...r.periodRange};S.reportPeriod='report_custom'}S.reportGeneratedBy=r.generatedBy;S.reportAI=r.ai;S.exportResult=r.exportResult;S.reportText=r.text;S.step=S.reportArchived?3:r.status==='draft'?r.step||2:3;openModal('report')},
 'export-report-data':()=>exportXLSX('SPEKTR-Данные-отчёта.xlsx',{'Кабинеты':accountsSheet(S.reportPeriod),'CRM':[salesSheet()[0],...salesSheet().slice(1).filter(r=>r[0]>=periods[S.reportPeriod].from&&r[0]<=periods[S.reportPeriod].to)],'Бриф':[['Вопрос','Ответ'],...briefQuestions.map((q,i)=>[q,S.brief[i]])]}),
 'export-accounts':()=>exportXLSX('SPEKTR-Кабинеты.xlsx',{'Кабинеты':accountsSheet()}),
 'export-sales':()=>exportXLSX('SPEKTR-Лиды.xlsx',{'CRM':salesSheet()}),
 'sales-template':()=>exportXLSX('SPEKTR-Шаблон-лидов.xlsx',{'CRM':salesSheet(true)}),
 'import':()=>openModal('import'),
 'commit-import':()=>{const errors=validateSales(S.uploadRows,S.uploadMode==='append'?currentClient().sales:[]);if(errors.length){S.uploadErrors=errors;render();return}R.write(R.salesKey(S.client),S.uploadMode==='append'?[...currentClient().sales,...S.uploadRows]:S.uploadRows);S.tab='sales';closeModal();toast('Таблица сохранена. KPI пересчитаны по выбранному периоду.')},
 'manual-sale':()=>openModal('manual-sale'),
 'source-table':()=>{const url=R.read('integration.'+S.client+'.sheet',{}).url;if(url&&safeURL(url))window.open(url,'_blank','noopener');else openModal('source-table')},
 'work-log':()=>openModal('work-log'),
 'open-plan':()=>{S.plan.client=S.client;navigate('plan')},
 'scenario':el=>{S.plan.scenario=el.dataset.value;S.planDirty=true;render()},

 'keywords':()=>{S.keywordUpload=[];S.keywordError='';openModal('keywords')},
 'clean-keywords':()=>{const list=R.keywords(S.client),seen=new Set();const cleaned=list.map(k=>({...k,text:k.text.trim().replace(/\s+/g,' ')})).filter(k=>{const key=k.text.toLowerCase()+'|'+k.campaign+'|'+k.group;if(!k.text||seen.has(key))return false;seen.add(key);return true});R.write('keywords.'+S.client,cleaned);render();toast(`Удалено дублей и пустых строк: ${list.length-cleaned.length}`)},
 'delete-keyword':el=>{R.write('keywords.'+S.client,R.keywords(S.client).filter(k=>k.id!==el.dataset.id));render();toast('Ключ удалён')},
 'group-filter':el=>{S.group=el.dataset.value;render()},
 'group-keywords':()=>{const words=R.keywords(S.client);if(!words.length){toast('Сначала добавьте ключи');return}S.proposedGroups=words.map(k=>({...k,proposed:/голов|мозг/.test(k.text)?'МРТ головы':/позвон|пояснич|спин/.test(k.text)?'МРТ позвоночника':/мрт/.test(k.text)?'МРТ / Общие запросы':k.text.split(/\s+/).slice(0,2).join(' ')}));openModal('group-preview')},
 'apply-groups':()=>{R.write('keywords.'+S.client,S.proposedGroups.map(({proposed,...k})=>({...k,group:proposed})));S.group='all';closeModal();toast('Группировка применена')},
 'to-ads':()=>{S.adGroup=S.group==='all'?'':S.group;const group=S.adGroup||R.keywords(S.client).find(k=>!k.excluded)?.group||'';loadAd(group);navigate('ads')},
 'to-semantics':()=>navigate('semantics'),
 'export-structure':exportStructure,
 'generate-ad':()=>{const group=S.adGroup||'Услуга';const key=R.keywords(S.client).find(k=>k.group===group&&!k.excluded)?.text||group;const title=key.charAt(0).toUpperCase()+key.slice(1);S.ad.headlines=[title,'Узнайте подробности','Оставьте заявку на сайте'];S.ad.descriptions=[`${group}. Ознакомьтесь с условиями и оставьте заявку на сайте.`,'Выберите подходящую услугу. Подробная информация и контакты на сайте.'];if(!S.ad.url)S.ad.url='https://'+currentClient().site;render();toast('Текст собран по шаблону. Проверьте содержание и лимиты.')},
 'save-ad':()=>{const errors=adErrors();if(errors.length){toast(errors[0]);return}const campaign=R.keywords(S.client).find(k=>k.group===S.adGroup)?.campaign;const list=R.ads(S.client),draft={...S.ad,id:S.ad.id||id(),client:S.client,platform:S.adPlatform,group:S.adGroup,campaign};R.write('ads.'+S.client,[draft,...list.filter(a=>a.id!==draft.id)]);S.ad=draft;render();toast('Объявление сохранено и включено в экспорт структуры')},
 'load-ad':el=>{const ad=R.ads(S.client).find(a=>a.id===el.dataset.id);S.ad=structuredClone(ad);S.adGroup=ad.group;S.adPlatform=ad.platform;render();window.scrollTo({top:0,behavior:'smooth'})},
 'naming-from-structure':()=>{S.naming.client=S.client;S.namingReturn='semantics';navigate('naming')},
 'copy-name':async el=>{await navigator.clipboard.writeText(generateNames(S.naming)[el.dataset.key]);toast('Название скопировано')},
 'copy-names':async()=>{await navigator.clipboard.writeText(Object.values(generateNames(S.naming)).join('\n'));toast('Все названия скопированы')},
 'apply-name':()=>{const n=generateNames(S.naming);R.write('keywords.'+S.client,R.keywords(S.client).map(k=>S.group==='all'||k.group===S.group?{...k,campaign:n.campaign}:k));const route=S.namingReturn||'semantics';S.namingReturn=null;navigate(route);toast('Название кампании применено к выбранной структуре')},
 'integration':el=>{S.integration=el.dataset.value;openModal('integration')},
 'backup':()=>{const payload={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k.startsWith('spektr.workspace.v1.'))payload[k]=JSON.parse(localStorage.getItem(k))}download('SPEKTR-Локальные-данные.json',JSON.stringify(payload,null,2),'application/json')}
};
document.addEventListener('click',async event=>{const el=event.target.closest('[data-action]');if(!el||el.disabled)return;if(event.target.closest('a')&&el.tagName==='TR')return;event.preventDefault();try{await actions[el.dataset.action]?.(el)}catch(error){toast(error.message||'Действие не выполнено')}});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&S.modal){event.preventDefault();closeModal()}if((event.key==='Enter'||event.key===' ')&&event.target.matches('tr[data-action]')){event.preventDefault();event.target.click()}if(event.key==='Tab'&&S.modal){const focusable=[...modalRoot.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea,a[href]')];const first=focusable[0],last=focusable.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus()}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus()}}});
function updateField(el){const key=el.dataset.field,value=el.type==='checkbox'?el.checked:el.value;switch(key){case 'toolClient':S.client=value;S.group='all';S.adGroup='';loadAd(R.keywords(value)[0]?.group||'');break;case 'planClient':S.plan.client=value;S.planDirty=true;break;case 'planBudget':S.plan.budget=Number(value);S.planDirty=true;break;case 'planMonth':S.plan.month=value;S.planDirty=true;break;case 'window':S.window=Number(value);break;case 'adGroup':loadAd(value);break;case 'adPlatform':loadAd(S.adGroup,value);break;case 'uploadMode':S.uploadMode=value;S.uploadErrors=validateSales(S.uploadRows,value==='append'?currentClient().sales:[]);break;default:S[key]=value;}render()}
document.addEventListener('input',event=>{const el=event.target;try{if(el.dataset.brief!==undefined){S.brief[Number(el.dataset.brief)]=el.value;return}if(el.dataset.field==='reportText'){S.reportText=el.value;return}if(el.dataset.ad){const k=el.dataset.ad;if(k==='headline')S.ad.headlines[+el.dataset.index]=el.value;else if(k==='description')S.ad.descriptions[+el.dataset.index]=el.value;else if(k==='sitelinkText'||k==='sitelinkURL'){S.ad.sitelinks[0]??={text:'',url:''};S.ad.sitelinks[0][k==='sitelinkText'?'text':'url']=el.value}else S.ad[k]=el.value;render();return}if(el.dataset.naming&&el.tagName!=='SELECT'){S.naming[el.dataset.naming]=el.value;render();return}if(el.dataset.plan&&el.tagName!=='SELECT'){S.plan.rows[Number(el.dataset.plan)][el.dataset.key]=Number(el.value);S.planDirty=true;render();return}if(['search','keywordSearch','planBudget'].includes(el.dataset.field))updateField(el)}catch(error){toast(error.message)}});
document.addEventListener('change',async event=>{const el=event.target;try{if(el.dataset.upload==='skill')return;if(el.dataset.upload){await handleUpload(el.files?.[0],el.dataset.upload);return}if(el.dataset.keyword){const list=R.keywords(S.client).map(k=>k.id===el.dataset.keyword?{...k,[el.dataset.key]:el.type==='checkbox'?el.checked:el.value}:k);R.write('keywords.'+S.client,list);render();return}if(el.dataset.plan){S.plan.rows[Number(el.dataset.plan)][el.dataset.key]=el.dataset.key==='mode'?el.value:Number(el.value);S.planDirty=true;render();return}if(el.dataset.naming){S.naming[el.dataset.naming]=el.value;render();return}if(el.dataset.field&&!['search','keywordSearch','planBudget','reportText'].includes(el.dataset.field))updateField(el)}catch(error){toast(error.message)}});
async function handleUpload(file,kind){if(!file)return;try{const rows=await readSpreadsheet(file);if(rows.length>10001)throw new Error('Максимум 10 000 строк за один импорт');if(!rows.length)throw new Error('Файл пуст');if(kind==='keywords'){const data=rows.filter((r,i)=>i>0||!['keyword','ключ','ключевое слово'].includes(String(r[0]).toLowerCase()));S.keywordUpload=data.map(r=>String(r[0]||'')).filter(Boolean);S.keywordError='';render();toast(`Подготовлено ключей: ${S.keywordUpload.length}`);return}const headers=rows[0].map(x=>String(x).trim().toLowerCase());const required=['date','source','leads','qualified','poor','unrated','sales'];if(required.some(x=>!headers.includes(x)))throw new Error('Не найдены обязательные столбцы. Скачайте и заполните шаблон.');S.uploadRows=rows.slice(1).map(row=>{const r=Object.fromEntries(headers.map((h,i)=>[h,row[i]??'']));if(/^\d{5}$/.test(r.date)){r.date=new Date(Date.UTC(1899,11,30)+Number(r.date)*86400000).toISOString().slice(0,10)}for(const key of ['leads','qualified','poor','unrated','sales','revenue'])r[key]=key==='revenue'&&(r[key]==null||r[key]==='')?null:r[key]===''?'':Number(String(r[key]).replace(/\s/g,'').replace(',','.'));r.attributed=['true','1','да'].includes(String(r.attributed).toLowerCase())&&r.source!=='unknown';return r});S.uploadErrors=validateSales(S.uploadRows,S.uploadMode==='append'?currentClient().sales:[]);render()}catch(error){if(kind==='keywords'){S.keywordError=error.message}else{S.uploadRows=[];S.uploadErrors=[error.message]}render()}}
document.addEventListener('dragover',event=>{if(event.target.closest('#dropzone'))event.preventDefault()});
document.addEventListener('drop',event=>{if(event.target.closest('#dropzone')){event.preventDefault();handleUpload(event.dataTransfer.files[0],'sales')}});
document.addEventListener('submit',async event=>{const form=event.target;if(!form.dataset.form)return;event.preventDefault();const f=Object.fromEntries(new FormData(form));try{switch(form.dataset.form){case 'new-project':{const c={id:id(),name:f.name.trim(),site:f.site.trim(),manager:f.manager,sector:f.sector,initials:f.name.trim().slice(0,2).toUpperCase(),accounts:[],monthly:0,sales:[],previous:[],targets:{ctr:null,cr:null,cpl:null,cpa:null}};if(!c.name)throw new Error('Введите название клиента');if(S.teamBusy)return;S.teamBusy=true;try{await R.persist('customClients',[...R.read('customClients',[]),{...c,manualProject:true}],R.sharedRecords.get('customClients')?.revision??0)}finally{S.teamBusy=false}S.modal=null;navigate('client/'+c.id);toast('Проект создан и доступен в списке задач.');break}case 'thresholds':R.write('settings.'+S.client,{...R.settings(S.client),budgetDays:+f.budgetDays,cplPercent:+f.cplPercent,staleHours:+f.staleHours,cpaPercent:+f.cpaPercent||30,minResults:+f.minResults||5});S.modal=null;render();toast('Пороги сохранены');break;case 'settings':if(f.namingURL&&!safeURL(f.namingURL))throw new Error('Введите HTTP/HTTPS URL');R.write('settings.global',{...R.settings(),namingURL:f.namingURL});toast('Настройки сохранены');break;case 'manual-sale':{const r={...f,attributed:f.attributed==='on'&&f.source!=='unknown'};for(const k of ['leads','qualified','poor','unrated','sales','revenue'])r[k]=k==='revenue'&&(f[k]===''||f[k]==null)?null:Number(f[k]);const errors=validateSales([r],currentClient().sales);if(errors.length)throw new Error(errors[0]);R.write(R.salesKey(S.client),[...currentClient().sales,r]);closeModal();toast('Данные добавлены');break}case 'keywords':{const words=String(f.keywords).split(/[\r\n]+/).map(k=>k.trim().replace(/[\u200B-\u200D\uFEFF]/g,'').replace(/\s+/g,' ')).filter(Boolean);if(!words.length)throw new Error('Вставьте хотя бы одно ключевое слово');const existing=R.keywords(S.client),seen=new Set(existing.map(k=>[k.text.toLowerCase(),k.campaign,k.group].join('|')));const added=[];for(const text of words){const key=[text.toLowerCase(),f.campaign,f.group].join('|');if(seen.has(key))continue;seen.add(key);added.push({id:id(),text,frequency:null,intent:'Коммерческий',campaign:f.campaign,group:f.group,match:'Фразовое',excluded:false,comment:''})}R.write('keywords.'+S.client,[...existing,...added]);S.group='all';closeModal();toast(`Добавлено ${added.length} ключей, дубли пропущены`);break}case 'work-log':R.saveLog({...f,id:id(),client:S.client}).catch(err=>toast(err.message));closeModal();toast('Запись добавлена в журнал');break;case 'integration':{const {token,...config}=f;if(config.url&&!safeURL(config.url))throw new Error('Введите HTTP/HTTPS URL');R.write('integration.'+S.client+'.'+S.integration,config);closeModal();toast('Параметры сохранены. Реальное подключение API не выполнялось.');break}}}catch(error){toast(error.message)}});
window.addEventListener('hashchange',parseRoute);
window.addEventListener('error',()=>toast('Возникла ошибка интерфейса. Попробуйте открыть раздел заново.'));
installWebCharts(actions,{render});
installMediaPlan(actions,{render,toast,openModal,closeModal});
installMarketingDashboard(actions,{render});
installAccountCharts(actions,{render});
installNamingGenerator(actions,{render,toast});
installSemantics(actions,{render,toast,openModal,closeModal,navigate});
parseRoute();
installClientFolders(actions,{render,toast,openModal,closeModal});
installOneC(actions,{render,toast,openModal});
installFeatures(actions,{render,toast,openModal,closeModal,printReport,persistReport,reportText});

installTaskEditor(actions,{render,toast});
installExchange(actions,{openModal,closeModal,toast,render});
installTeam(actions,{render,toast,openModal,closeModal,navigate,persistReport});

installClientSettings(actions,{render,toast,openModal,closeModal});
installBudgets(actions,{render,toast,openModal,closeModal});
installWebGoals(actions,{render,toast,openModal,closeModal});

installHeaderNavigation(actions,{render});
