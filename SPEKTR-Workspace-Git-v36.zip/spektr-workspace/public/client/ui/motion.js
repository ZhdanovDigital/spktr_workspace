// Animate navigation, never routine redraws (metric toggles, filters or dialogs).
let previousView;
const reducedMotion=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches;
export function animateWorkspace(root,view){
 const changed=view!==previousView;previousView=view;
 if(!changed||reducedMotion())return;
 const blocks=root.querySelectorAll('.workspace > .panel,.workspace > .summary-strip,.workspace > .heading,.performance-dashboard > .executive-grid,.performance-dashboard > .panel,.performance-dashboard > .channel-section,.performance-dashboard > .project-web-analytics,.performance-dashboard > .client-activity-grid');
 let visibleIndex=0;
 for(const block of blocks){
  if(!block.animate||block.getBoundingClientRect().top>window.innerHeight)continue;
  block.animate([{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'translateY(0)'}],{duration:360,delay:Math.min(visibleIndex++*45,180),easing:'cubic-bezier(.22,1,.36,1)',fill:'backwards'});
 }
}
if(typeof window!=='undefined')window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change',event=>{
 if(event.matches)document.getAnimations().forEach(animation=>animation.cancel());
});
