import {S} from './state.js';
import {repository as R} from '../data/repository.js';
import {sharedBadge} from './team.js';
import {themeControl} from './theme.js';
import {e,icon,button} from './components.js';

export const workRoutes=[['tasks','check','Задачи'],['journal','file','Журнал'],['reports','chart','Отчёты']];
export const toolRoutes=[['plan','layers','Медиаплан'],['naming','link','Нейминг'],['semantics','search','Семантика']];
export const settingsRoutes=[['prompts','spark','Препромпты'],['integrations','plug','Интеграции'],['settings','gear','Настройки']];
export const routeTitle=route=>route==='projects'?'Проекты':[...toolRoutes,...workRoutes,...settingsRoutes].find(([key])=>key===route)?.[2]||'Проекты';
export const activeRoute=route=>['ads'].includes(route)?'projects':route;
const link=(route,label,i='')=>`<a id="header-link-${route}" href="#/${route}" class="${S.route===route||route==='projects'&&S.route==='client'?'active':''}" ${S.route===route||route==='projects'&&S.route==='client'?'aria-current="page"':''}>${i?icon(i):''}${label}</a>`;
export function workspaceHeader({user='Команда',attention=0}={}){
 const initials=user.split(/\s+/).slice(0,2).map(x=>x[0]).join(''),active=settingsRoutes.some(([r])=>r===S.route);
 return `<header class="topbar workspace-topbar"><a class="brand" href="#/projects" aria-label="SPEKTR — главная"><img src="/assets/spektr.png" class="logo" alt="SPEKTR"><span class="brand-tag">AGENCY<br>WORKSPACE</span></a>
 <div class="header-navigation"><nav class="nav primary-nav" aria-label="Проекты и инструменты">${link('projects','Проекты','grid')}${toolRoutes.map(([r,i,label])=>link(r,label,i)).join('')}</nav><div class="header-work">${button(icon('layers')+'Работа'+icon('down'),'header-work','ghost header-work-button '+(workRoutes.some(([r])=>r===S.route)?'active':''),`id="header-work-trigger" aria-expanded="${Boolean(S.workMenuOpen)}" aria-controls="header-work-menu"`)}<nav class="header-settings-menu header-work-menu" id="header-work-menu" aria-label="Работа по проектам" ${S.workMenuOpen?'':'hidden'}>${workRoutes.map(([r,i,label])=>link(r,label,i)).join('')}</nav></div></div>
 <div class="top-actions">${sharedBadge()}${button(icon('bell')+(attention?`<span class="notification-count">${attention}</span>`:''),'notifications','ghost icon-btn notification-button','aria-label="Центр внимания" title="Уведомления"')}
 <div class="header-settings">${button(icon('gear'),'header-settings','ghost icon-btn header-settings-button '+(active?'active':''),`id="header-settings-trigger" aria-label="Настройки рабочего пространства" title="Настройки рабочего пространства" aria-expanded="${Boolean(S.settingsMenuOpen)}" aria-controls="header-settings-menu"`)}<nav class="header-settings-menu" id="header-settings-menu" aria-label="Настройки рабочего пространства" ${S.settingsMenuOpen?'':'hidden'}>${settingsRoutes.map(([r,i,label])=>link(r,label,i)).join('')}</nav></div>
 ${themeControl()}<span class="divider"></span><span class="user-info">${e(user)}<small>${R.canManageClients()?'Администратор':'Команда digital'}</small></span><span class="avatar" aria-label="${e(user)}">${e(initials)}</span></div></header>`;
}
const menus=[{key:'workMenuOpen',id:'header-work',selector:'.header-work'},{key:'settingsMenuOpen',id:'header-settings',selector:'.header-settings'}];
function closeMenu(menu,restoreFocus=false){
 S[menu.key]=false;const node=document.getElementById(menu.id+'-menu');if(node)node.hidden=true;
 document.getElementById(menu.id+'-trigger')?.setAttribute('aria-expanded','false');
 if(restoreFocus)document.getElementById(menu.id+'-trigger')?.focus({preventScroll:true});
}
export function dismissSettingsMenu(restoreFocus=false){
 const active=menus.find(menu=>S[menu.key]);for(const menu of menus)closeMenu(menu,restoreFocus&&menu===active);
}
export function installHeaderNavigation(actions,{render}){
 for(const menu of menus)actions[menu.id]=()=>{const open=!S[menu.key];dismissSettingsMenu();S.dateOpen=false;S[menu.key]=open;render();document.getElementById(menu.id+'-trigger')?.focus({preventScroll:true})};
 for(const type of ['pointerdown','focusin'])document.addEventListener(type,event=>{for(const menu of menus)if(S[menu.key]&&!event.target.closest(menu.selector))closeMenu(menu)},type==='pointerdown');
 document.addEventListener('keydown',event=>{
  const active=menus.find(menu=>S[menu.key]);
  if(active&&event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();closeMenu(active,true);return}
  const menu=menus.find(menu=>event.target.closest(menu.selector));if(!menu)return;
  const trigger=event.target.closest('#'+menu.id+'-trigger'),inside=event.target.closest('#'+menu.id+'-menu');
  if(trigger&&['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();dismissSettingsMenu();S[menu.key]=true;S.dateOpen=false;render();const links=[...document.querySelectorAll('#'+menu.id+'-menu a')];(event.key==='ArrowDown'?links[0]:links.at(-1))?.focus();return}
  if(!S[menu.key]||!inside||!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;
  event.preventDefault();const links=[...document.querySelectorAll('#'+menu.id+'-menu a')],index=links.indexOf(document.activeElement),next=event.key==='Home'?0:event.key==='End'?links.length-1:(index+(event.key==='ArrowDown'?1:-1)+links.length)%links.length;links[next]?.focus();
 },true);
}
