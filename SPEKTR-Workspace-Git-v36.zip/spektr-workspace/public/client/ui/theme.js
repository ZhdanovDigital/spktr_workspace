import {button,icon} from './components.js';
const key='spektr.workspace.theme';
export function applyTheme(theme){
 const selected=theme==='dark'?'dark':'light';
 document.documentElement.dataset.theme=selected;
 document.documentElement.style.colorScheme=selected;
 try{localStorage.setItem(key,selected)}catch{}
 return selected;
}
export function initializeTheme(){
 let stored;try{stored=localStorage.getItem(key)}catch{}
 return applyTheme(stored==='dark'||stored==='light'?stored:window.matchMedia?.('(prefers-color-scheme: dark)').matches?'dark':'light');
}
export function toggleTheme(){return applyTheme(document.documentElement.dataset.theme==='dark'?'light':'dark')}
export function themeControl(){
 const dark=document.documentElement.dataset.theme==='dark',label=dark?'Включить светлый режим':'Включить ночной режим';
 return button(icon(dark?'sun':'moon'),'toggle-theme','ghost icon-btn theme-toggle',`id="theme-toggle" aria-label="${label}" title="${label}" aria-pressed="${dark}"`);
}
