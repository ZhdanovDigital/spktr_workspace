import {periods,periodCaption,shortDate,makePeriod,comparisonCaption} from '../domain/dates.js';
import {S} from './state.js';
import {e,icon,button,field,input} from './components.js';
export function periodControl(target='period'){
  const open=S.dateOpen&&S.dateTarget===target,id='date-popover-'+target;
  return `<div class="period-picker" data-date-target="${e(target)}">${button(icon('calendar')+e(periods[S[target]].label)+' <span class="period-dates">'+e(periodCaption(S[target]))+'</span>'+icon('down'),'date-picker','period-button',`id="date-trigger-${e(target)}" data-target="${e(target)}" aria-haspopup="dialog" aria-expanded="${Boolean(open)}" aria-controls="${e(id)}"`)}${open?`<section id="${e(id)}" class="date-popover" role="dialog" aria-modal="false" aria-label="Выбор периода"><div class="date-popover-body">${calendarBody()}</div><div class="date-popover-footer"><small>Алматы · UTC+5</small>${button('Отмена','cancel-period')}${button('Применить','apply-period','primary')}</div></section>`:''}</div>`;
}
export function dismissDatePopover(restoreFocus=false){
  S.dateOpen=false;
  document.querySelectorAll('.date-popover').forEach(node=>node.remove());
  document.querySelectorAll('.period-button[aria-expanded="true"]').forEach(node=>node.setAttribute('aria-expanded','false'));
  if(restoreFocus)document.getElementById('date-trigger-'+S.dateTarget)?.focus({preventScroll:true});
}
export function positionDatePopover(){
  if(!S.dateOpen)return;
  const panel=document.getElementById('date-popover-'+S.dateTarget),trigger=document.getElementById('date-trigger-'+S.dateTarget);
  if(!panel||!trigger)return;
  const rect=trigger.getBoundingClientRect(),margin=12,gap=8,vw=window.innerWidth,vh=window.innerHeight;
  if(rect.bottom<0||rect.top>vh){dismissDatePopover();return;}
  const width=panel.getBoundingClientRect().width,below=vh-rect.bottom-margin-gap,above=rect.top-margin-gap;
  const up=below<Math.min(panel.scrollHeight,320)&&above>below;
  panel.style.maxHeight=Math.max(60,Math.min(vh-margin*2,Math.max(120,up?above:below)))+'px';
  const height=panel.getBoundingClientRect().height;
  const preferredLeft=S.dateTarget==='reportPeriod'?rect.left:rect.right-width;
  panel.style.left=Math.max(margin,Math.min(preferredLeft,vw-width-margin))+'px';
  panel.style.top=Math.max(margin,Math.min(up?rect.top-height-gap:rect.bottom+gap,vh-height-margin))+'px';
  panel.style.visibility='visible';
}
function monthGrid(month){const d=new Date(month+'-01T12:00:00Z'),offset=(d.getUTCDay()+6)%7,count=new Date(d.getUTCFullYear(),d.getUTCMonth()+1,0).getDate(),draft=S.rangeDraft||periods[S[S.dateTarget]];return `<section class="calendar-month"><h3>${d.toLocaleDateString('ru-RU',{month:'long',year:'numeric',timeZone:'UTC'})}</h3><div class="calendar-grid">${['Пн','Вт','Ср','Чт','Пт','Сб','Вс'].map(x=>`<span class="weekday">${x}</span>`).join('')}${Array.from({length:offset},()=>'<span></span>').join('')}${Array.from({length:count},(_,i)=>{const date=month+'-'+String(i+1).padStart(2,'0');return button(String(i+1),'calendar-day','cal-day '+(date===draft.from||date===draft.to?'selected':draft.from&&draft.to&&date>draft.from&&date<draft.to?'between-days':''),`id="cal-day-${date}" data-date="${date}" aria-label="${shortDate(date)}"`)}).join('')}</div></section>`;}
export function calendarBody(){const month=S.calendarMonth||periods.this_month.from.slice(0,7),next=new Date(month+'-01T12:00:00Z');next.setUTCMonth(next.getUTCMonth()+1);const draft=S.rangeDraft||periods[S[S.dateTarget]];return `<div class="date-picker-grid"><div class="date-presets">${Object.entries(periods).filter(([k])=>k!=='report_custom').map(([k,p])=>button(p.label,'date-preset',S.rangePreset===k?'active':'',`id="date-preset-${k}" data-value="${k}"`)).join('')}</div><div><div class="flex between" style="margin-bottom:10px">${button(icon('back'),'calendar-shift','ghost small','id="calendar-previous" data-offset="-1" aria-label="Предыдущий месяц"')}<small>Выберите начало и конец периода</small>${button(icon('chevron'),'calendar-shift','ghost small','id="calendar-next" data-offset="1" aria-label="Следующий месяц"')}</div><div class="calendar-months">${monthGrid(month)}${monthGrid(next.toISOString().slice(0,7))}</div><div class="form-grid section-gap">${field('Начало',input('rangeFrom',draft.from||'','date',`id="date-from-${S.dateTarget}" data-field="rangeFrom"`))}${field('Конец',input('rangeTo',draft.to||'','date',`id="date-to-${S.dateTarget}" data-field="rangeTo"`))}</div><label class="check section-gap"><input type="checkbox" id="date-compare-${S.dateTarget}" data-field="rangeCompare" ${(S.rangeCompare??S.compare)?'checked':''}>Сравнить с предыдущим периодом</label><small class="comparison-hint">${draft.from&&draft.to&&draft.from<=draft.to?'База сравнения: '+e(comparisonCaption(makePeriod('',draft.from,draft.to,['this_month','last_month'].includes(S.rangePreset)?'month':['this_week','last_week'].includes(S.rangePreset)?'week':'auto'))):'Выберите даты периода'}</small></div></div>`;}
