import {repository as R} from '../data/repository.js';
import {S} from './state.js';
import {goalKinds,goalPreferenceKey,favoriteGoals,favoriteGoalSnapshot} from '../domain/web-goals.js';
import {periods} from '../domain/dates.js';
import {e,fmt,pct,icon,button,options,delta} from './components.js';
const numeric=n=>n==null?'—':fmt(n);
const bySource=(client,provider,id)=>client?.analytics?.find(a=>a.provider===provider&&a.id===id);
export function selectedConversions(c,source,snapshot){
 const list=favoriteGoalSnapshot(source,periods[S.period]);
 return `<section class="web-favorite-goals"><div class="web-goals-heading"><div><h3>Избранные конверсии</h3><p>Лиды / заявки · WhatsApp · звонки</p></div>${button(icon('settings')+'Выбрать цели','web-goals-edit','ghost small',`data-client="${e(c.id)}" data-provider="${e(source.provider)}" data-source="${e(source.id)}"`)}</div>${list.length?`<div class="web-goals-grid">${list.map(g=>{const m=g.current,old=g.previous,comparable=snapshot.coverage.fresh&&m.complete&&old.complete;return `<article class="web-goal-card goal-${e(g.kind)}"><span class="web-goal-kind">${e(goalKinds[g.kind])}</span><h4>${e(g.name)}</h4><div class="web-goal-value"><b class="num">${numeric(m.conversions)}</b>${S.compare?delta(m.conversions,comparable?old.conversions:null):''}</div><div class="web-goal-details"><span>Целевые визиты <b class="num">${numeric(m.goalSessions)}</b></span><span>CR цели <b class="num">${pct(m.cr,2)}</b></span></div><small>${!g.available?'Цель отсутствует в выгрузке':m.complete?'Период загружен':m.days?'Данные: '+m.days+' из '+m.expectedDays+' дней':'Нет данных за период'}</small></article>`}).join('')}</div>`:`<div class="web-goals-empty">${source.goals?.length?'Выберите цели для этого счётчика.':'Разбивка по целям не передана. Нужны отдельные данные по заявкам, WhatsApp и звонкам.'}</div>`}<p class="web-goals-note">Показаны только выбранные цели. Достижения целей могут повторяться у одного человека; клики по WhatsApp и телефону сами по себе не подтверждают диалог или звонок. Цели не складываются в уникальные лиды.</p></section>`;
}
export function webGoalsModal(){
 if(S.modal!=='web-goals')return null;const d=S.goalDraft;if(!d)return null;
 const body=d.rows.length?`<div class="web-goal-options">${d.rows.map((g,i)=>`<div class="web-goal-option"><label class="check"><input id="goal-selected-${i}" type="checkbox" name="selected-${i}" ${g.selected?'checked':''}><span><b>${e(g.name)}</b><small>ID: ${e(g.id)}${g.missing?' · нет в текущей выгрузке':''}</small></span></label><label class="web-goal-category" for="goal-kind-${i}">Тип цели<select id="goal-kind-${i}" name="kind-${i}">${options(Object.entries(goalKinds),g.kind)}</select></label></div>`).join('')}</div>`:'<div class="notice">В источнике нет списка целей. После загрузки отдельных целей в analytics.goals здесь появится выбор.</div>';
 return `<div class="modal-shade"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="web-goals-title"><div class="modal-top"><div><h2 id="web-goals-title">Избранные конверсии</h2><p>${e(d.clientName)} · ${e(d.sourceName)}</p></div>${button(icon('close'),'close','ghost icon-btn','aria-label="Закрыть"')}</div><div class="modal-body"><form id="web-goals-form" data-goal-preferences-form><fieldset class="web-goals-fieldset" ${S.teamBusy?'disabled':''}>${body}<p class="sub">Отметьте нужные цели и задайте тип каждой. Выбор сохраняется для всей команды отдельно для каждого счётчика.</p>${S.goalError?`<div class="notice error" role="alert">${e(S.goalError)}</div>`:''}${!R.sharedReady?'<div class="notice error">Дождитесь подключения командного хранилища для сохранения.</div>':''}</fieldset></form></div><div class="modal-footer">${button('Отмена','close')}<button form="web-goals-form" class="primary" ${S.teamBusy||!R.sharedReady||!d.rows.length?'disabled':''}>${S.teamBusy?'Сохраняем…':'Сохранить выбор'}</button></div></section></div>`;
}
export function installWebGoals(actions,{render,toast,openModal,closeModal}){
 actions['web-goals-edit']=el=>{
  if(S.teamBusy)return;const c=R.clients().find(c=>c.id===el.dataset.client),source=bySource(c,el.dataset.provider,el.dataset.source);if(!source)return;
  const key=goalPreferenceKey(c),record=R.sharedRecords.get(key),favorites=favoriteGoals(source),list=[...(source.goals||[])];
  for(const f of favorites)if(!list.some(g=>g.id===f.id))list.push({id:f.id,name:f.name,kind:f.kind,missing:true});
  S.goalDraft={key,revision:record?.revision||0,base:record?.value||{clientId:c.id,origin:c.dataOrigin==='database'?'database':'demonstration',sources:[]},clientName:c.name,sourceName:source.name,sourceId:source.id,provider:source.provider,rows:list.map(g=>({id:g.id,name:g.name,missing:g.missing===true,kind:favorites.find(f=>f.id===g.id)?.kind||(Object.hasOwn(goalKinds,g.kind)?g.kind:'lead'),selected:favorites.some(f=>f.id===g.id)}))};S.goalError='';openModal('web-goals');
 };
 const capture=form=>{const fields=new FormData(form);S.goalDraft.rows.forEach((g,i)=>{g.selected=fields.has('selected-'+i);g.kind=String(fields.get('kind-'+i)||g.kind)})};
 document.addEventListener('change',event=>{const form=event.target.closest('[data-goal-preferences-form]');if(form)capture(form)});
 document.addEventListener('submit',async event=>{
  const form=event.target;if(!form.hasAttribute('data-goal-preferences-form'))return;event.preventDefault();if(S.teamBusy)return;capture(form);
  const d=S.goalDraft,goals=d.rows.filter(g=>g.selected).map(({id,name,kind})=>({id,name,kind}));
  try{if(goals.some(g=>!Object.hasOwn(goalKinds,g.kind)))throw Error('Выберите тип цели');const source={provider:d.provider,sourceId:d.sourceId,goals},value={...d.base,sources:[...(d.base.sources||[]).filter(s=>s.provider!==d.provider||s.sourceId!==d.sourceId),source]};
   S.teamBusy=true;S.goalError='';render();await R.persist(d.key,value,d.revision);S.teamBusy=false;closeModal();toast('Избранные конверсии сохранены для команды');
  }catch(error){S.teamBusy=false;S.goalError=error.message;render()}
 });
}
