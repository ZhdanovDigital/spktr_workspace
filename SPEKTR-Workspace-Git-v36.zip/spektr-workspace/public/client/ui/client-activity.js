import {repository as R} from '../data/repository.js';
import {S} from './state.js';
import {periods} from '../domain/dates.js';
import {openTask,overdue,logInPeriod,statusLabels} from '../domain/operations.js';
import {platforms} from '../data/demo.js';
import {e,icon,button,panel,chip,date,empty} from './components.js';

export function clientJournal(c,preview=false){
 const all=logInPeriod(R.logs(c.id),periods[S.period]),logs=preview?all.slice(0,3):all;
 return panel(`Журнал изменений <span class="section-count">${all.length}</span>`,logs.length?`<div class="client-journal">${logs.map(l=>`<article><div class="journal-date-badge">${icon('calendar')} ${date(l.date)}</div><div class="client-journal-content"><div class="flex between"><small>${e(l.manager)} · ${e(platforms[l.platform]?.name||'Все кабинеты')}</small>${button(icon('more'),'journal-edit','ghost small',`data-client="${e(c.id)}" data-id="${e(l.id)}" aria-label="Редактировать запись"`)}</div><h3>${e(l.text)}</h3>${!preview?`<p><b>Цель:</b> ${e(l.goal||'Не указана')}</p><p><b>Результат:</b> ${e(l.result||'Эффект ещё не оценён')}</p><small>${e(l.campaign||'')}</small>`:''}<div class="journal-entry-foot">${chip(e(l.status||'Наблюдаем'),'info')}<small>Учитывается в отчёте</small></div></div></article>`).join('')}</div>`:empty('Изменений за период нет','Зафиксируйте правки, чтобы команда и отчёт учитывали контекст.'),`<div class="flex">${preview?button('Все записи','client-tab','ghost small','data-value="journal"'):''}${button(icon('plus')+'Запись','work-log','small')}</div>`,'client-journal-panel');
}
export function clientActivity(c){
 const tasks=R.tasks().filter(t=>t.client===c.id&&openTask(t)).sort((a,b)=>Number(overdue(b))-Number(overdue(a))||(a.due+(a.time||'18:00')).localeCompare(b.due+(b.time||'18:00'))),late=tasks.filter(t=>overdue(t));
 return `<section class="client-activity-grid" aria-label="Работа по клиенту">${panel(`Задачи клиента <span class="section-count">${tasks.length}</span>`,tasks.length?`<div class="client-task-preview">${late.length?`<div class="task-late-summary">${icon('alert')} Просрочено: ${late.length}</div>`:''}${tasks.slice(0,4).map(t=>`<button class="client-task-preview-row" data-action="task-edit" data-id="${e(t.id)}"><span class="task-state-icon ${overdue(t)?'red':''}">${icon(t.status==='progress'?'clock':'check')}</span><span><b>${e(t.title)}</b><small>${e(t.assignee)} · ${date(t.due)} · ${e(t.time||'18:00')}</small></span>${chip(overdue(t)?'Просрочено':statusLabels[t.status],overdue(t)?'critical':'info')}</button>`).join('')}</div>`:empty('Нет активных задач','Назначьте следующую проверку рекламы и срок.',button('Плановая проверка','client-review','small')),`<div class="flex">${button('Все задачи','client-tab','ghost small','data-value="tasks"')}${button(icon('plus')+'Задача','task-new-client','small')}</div>`,'client-tasks-panel')}${clientJournal(c,true)}</section>`;
}
