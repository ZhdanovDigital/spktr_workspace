import {repository as R} from '../data/repository.js';
import {S,currentClient} from './state.js';
import {accountURL,validAccountURL} from '../domain/dashboard.js';
import {platforms} from '../data/demo.js';
import {e,icon,button,field,input,options,panel,chip} from './components.js';

export function managerControl(c){return `<span class="manager-chip">${icon('users')}<span><small>Менеджер проекта</small><b>${e(c.manager||'Не назначен')}</b></span>${R.canManageClients()?button(icon('settings'),'client-settings','ghost small',`data-client="${e(c.id)}" aria-label="Назначить менеджера ${e(c.name)}"`):''}</span>`}
export function administrationPanel(){return panel('Менеджеры проектов',`<div class="panel-body"><p class="sub">${R.canManageClients()?'Вы администратор. Назначайте ответственных и добавляйте прямые ссылки на рекламные кабинеты.':'Назначение ответственных доступно администратору.'}</p><div class="admin-client-list">${R.clients().map(c=>`<div><span><b>${e(c.name)}</b><small>${e(c.manager||'Не назначен')}</small></span>${R.canManageClients()?button('Настроить','client-settings','small',`data-client="${e(c.id)}"`):chip('Просмотр','info')}</div>`).join('')}</div></div>`,'','section-gap')}
export function clientSettingsModal(){
 if(S.modal!=='client-settings')return null;
 const c=currentClient(),draft=S.clientConfigDraft||{},managers=[...new Set(['Мадина','Темирлан',...R.clients().map(c=>c.manager)].filter(Boolean))];
 const body=R.canManageClients()?`<form id="client-settings-form" data-form="client-settings" class="stack">${field('Ответственный менеджер',input('manager',draft.manager??c.manager,'text','required maxlength="80" list="workspace-managers" placeholder="Имя менеджера"'))}<datalist id="workspace-managers">${options(managers,'')}</datalist><p class="sub">Можно выбрать имя или ввести нового менеджера. Он станет ответственным по умолчанию для новых задач; существующие задачи сохранят своих исполнителей.</p><h3>Переходы в рекламные кабинеты</h3><p class="sub">Вставьте ссылку из адресной строки нужного кабинета. Команда сможет открывать его прямо из дашборда.</p>${c.accounts.map((a,i)=>field(`${e(platforms[a.platform]?.name)} · ${e(a.name)}`,input('link-'+i,draft.accountLinks?.[a.id]??accountURL(a)??'','url',`maxlength="2000" placeholder="https://…"`))).join('')}${!c.accounts.length?'<p class="sub">Сначала добавьте кабинеты в источник данных.</p>':''}${S.clientSettingsError?`<div class="notice error" role="alert">${e(S.clientSettingsError)}</div>`:''}</form>`:'<div class="notice">Назначать ответственного и менять ссылки может администратор рабочего пространства.</div>';
 return `<div class="modal-shade"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="client-settings-title"><div class="modal-top"><div><h2 id="client-settings-title">Настройки клиента</h2><p>${e(c.name)} · управление администратором</p></div>${button(icon('close'),'close','ghost icon-btn','aria-label="Закрыть"')}</div><div class="modal-body">${body}</div><div class="modal-footer">${button('Отмена','close')}${R.canManageClients()?`<button form="client-settings-form" class="primary" ${S.teamBusy?'disabled':''}>${S.teamBusy?'Сохраняем…':'Сохранить настройки'}</button>`:''}</div></section></div>`;
}
export function installClientSettings(actions,{render,toast,openModal,closeModal}){
 actions['client-settings']=el=>{if(!R.canManageClients()){toast('Настройки клиента доступны администратору');return}if(el?.dataset.client)S.client=el.dataset.client;S.clientConfigDraft=null;S.clientSettingsError='';openModal('client-settings')};
 document.addEventListener('submit',async event=>{
  const form=event.target;if(form.dataset.form!=='client-settings')return;event.preventDefault();if(S.teamBusy)return;
  const c=currentClient(),fields=Object.fromEntries(new FormData(form)),accountLinks={};S.clientSettingsError='';
  for(const [i,a] of c.accounts.entries())if(String(fields['link-'+i]||'').trim())accountLinks[a.id]=String(fields['link-'+i]).trim();
  S.clientConfigDraft={manager:String(fields.manager||'').trim(),accountLinks};
  try{
   if(!R.canManageClients())throw new Error('Изменение доступно только администратору');
   if(!S.clientConfigDraft.manager)throw new Error('Укажите ответственного менеджера');
   for(const a of c.accounts)if(accountLinks[a.id]&&!validAccountURL(accountLinks[a.id],a.platform))throw new Error(`Проверьте ссылку ${platforms[a.platform].name}: нужен адрес этого рекламного кабинета по HTTPS`);
   S.teamBusy=true;form.querySelectorAll('button,input').forEach(n=>n.disabled=true);
   await R.persist(R.clientConfigKey(c.id),{...S.clientConfigDraft,clientId:c.id,origin:R.runtime.database||R.read('dataSource',{}).enabled?'database':'demonstration'});
   S.teamBusy=false;S.clientConfigDraft=null;closeModal();render();toast('Менеджер и ссылки сохранены для всей команды');
  }catch(error){S.teamBusy=false;S.clientSettingsError=error.message;render()}
 });
}
