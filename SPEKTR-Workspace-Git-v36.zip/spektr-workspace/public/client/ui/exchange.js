import {repository as R} from '../data/repository.js';
import {S} from './state.js';
import {isoDate} from '../domain/dates.js';
import {normalizeExchangeRates} from '../domain/project-money.js';
import {e,fmt,icon,button,field,input,options} from './components.js';
export function projectExchange(){
 const config=R.read('settings.exchange',{});
 if(config.mode==='manual')return normalizeExchangeRates(config);
 if(R.runtime.database||R.read('dataSource',{}).enabled)return normalizeExchangeRates(R.runtime.exchangeRates);
 return {base:'KZT',rates:{KZT:1,USD:500},asOf:'2026-10-09',source:'Демонстрационный курс'};
}
export function exchangeControl(){const fx=projectExchange();return button(icon('wallet')+(fx?.rates.USD?`1 $ = ${fmt(fx.rates.USD,2)} ₸`:'Курс валют'),'exchange-settings','ghost small',`title="${e(fx?fx.source+' · '+fx.asOf:'Загрузите exchangeRates из БД или задайте курс вручную')}"`);}
export function exchangeModal(){
 if(S.modal!=='exchange-settings')return null;const cfg=R.read('settings.exchange',{}),fx=projectExchange();
 return `<div class="modal-shade"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="exchange-title"><div class="modal-top"><h2 id="exchange-title">Курс для сводки расходов</h2>${button(icon('close'),'close','ghost icon-btn','aria-label="Закрыть"')}</div><div class="modal-body"><form id="exchange-form" data-exchange-form class="stack">${field('Источник',`<select name="mode">${options([['database','Из подключённой БД'],['manual','Ручной курс команды']],cfg.mode||'database')}</select>`)}${field('₸ за 1 $',input('usd',cfg.rates?.USD??'','number','min="0.000001" max="100000000" step="any" placeholder="Например, курс из ваших документов"'))}${field('Дата курса',input('asOf',cfg.asOf||isoDate(),'date','required'))}<p class="sub">Курс применяется к расходам всего выбранного периода. Это управленческий эквивалент, а не бухгалтерская переоценка. Для других валют передайте rates в БД.</p>${fx?`<div class="notice">Используется: ${e(fx.source)} · ${e(fx.asOf)}</div>`:'<div class="notice">Без заданного курса недоступный эквивалент показывается прочерком.</div>'}</form></div><div class="modal-footer">${button('Отмена','close')}<button form="exchange-form" class="primary" ${!R.sharedReady?'disabled':''}>Сохранить</button></div></section></div>`;
}
export function installExchange(actions,{openModal,closeModal,toast,render}){
 actions['exchange-settings']=()=>openModal('exchange-settings');
 document.addEventListener('submit',async event=>{if(!event.target.hasAttribute('data-exchange-form'))return;event.preventDefault();if(S.teamBusy)return;const f=Object.fromEntries(new FormData(event.target)),value={mode:f.mode,base:'KZT',rates:{USD:Number(f.usd)},asOf:f.asOf,source:'Ручной курс команды'};
  if(value.mode==='manual'&&!normalizeExchangeRates(value)){toast('Укажите положительный курс и корректную дату');return;}
  S.teamBusy=true;try{await R.persist('settings.exchange',value);S.teamBusy=false;closeModal();toast('Источник курса сохранён')}catch(error){toast(error.message)}finally{S.teamBusy=false;render()}
 });
}
