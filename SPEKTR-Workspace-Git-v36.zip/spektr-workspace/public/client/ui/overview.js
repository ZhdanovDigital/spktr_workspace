import {accountChart,accountMetricButton} from './account-charts.js';
import {oneCPanel} from './onec.js';
import {budgetPanel} from './budget-plan.js';
import {webAnalyticsSection} from './web-analytics.js';
import {repository as R} from '../data/repository.js';
import {platforms,SNAPSHOT} from '../data/demo.js';
import {metrics,budgetForecast,periods,range} from '../domain/metrics.js';
import {accountMetrics,webMetrics,webChannelRows} from '../domain/analytics.js';
import {accountSnapshot,accountURL,validAccountURL,spendByCurrency,} from '../domain/dashboard.js';
import {dayCount} from '../domain/dates.js';
import {openTask,overdue} from '../domain/operations.js';
import {S} from './state.js';
import {clientActivity} from './client-activity.js';
import {e,fmt as formatNumber,currencyMoney as formatMoney,pct,date,icon,brand,chip,button,options,empty,info,panel,table,delta} from './components.js';

const fmt=(n,d=0)=>n==null?'—':formatNumber(n,d);
const currencyMoney=(n,currency)=>n==null?'—':formatMoney(n,currency);
const change=(current,old,lower=false,allowed=true)=>S.compare?delta(current,allowed?old:null,lower):'';

const accountId=a=>'channel-'+encodeURIComponent(a.id);

function executiveSummary(c,snapshots){
 const p=periods[S.period],m=metrics(c,p),old=metrics(c,p,true),spends=spendByCurrency(c.accounts,p),known=snapshots.filter(s=>s.budget.days!==null).sort((a,b)=>a.budget.days-b.budget.days),soon=known[0];
 const tasks=R.tasks().filter(t=>t.client===c.id&&openTask(t)),late=tasks.filter(t=>overdue(t));
 return `<section class="executive-grid" aria-label="Главные показатели проекта">
 <article class="glass-kpi kpi-sapphire"><div class="glass-kpi-top"><span>Расход на рекламу</span>${icon('wallet')}</div><div class="glass-kpi-value">${spends.length?spends.map(r=>`<span class="num">${currencyMoney(r.value,r.currency)}</span>`).join(''):'—'}</div><div class="glass-kpi-foot">${icon('calendar')} За выбранный период${snapshots.some(s=>!s.complete)?' · неполные данные':''}</div></article>
 <article class="glass-kpi kpi-emerald"><div class="glass-kpi-top"><span>Лиды по CRM</span>${icon('target')}</div><div class="glass-kpi-value num">${fmt(m.leads)}${change(m.leads,old.leads,false,m.crmComplete&&old.crmComplete)}</div><div class="glass-kpi-foot">Квалифицированные: <b>${fmt(m.qualified)}</b> ${m.crmComplete?'':'· период заполнен частично'}</div></article>
 <article class="glass-kpi kpi-amethyst"><div class="glass-kpi-top"><span>CPL по CRM ${info('Общий расход / фактические лиды CRM. Считается при полном покрытии рекламы и CRM и одной валюте кабинетов.')}</span>${icon('chart')}</div><div class="glass-kpi-value num">${m.currency?currencyMoney(m.cpl,m.currency):'—'}${change(m.cpl,old.cpl,true)}</div><div class="glass-kpi-foot">CR по CRM: <b>${pct(m.cr,2)}</b>${!m.currency?' · валюты отдельно':''}</div></article>
 <article class="glass-kpi kpi-bronze"><div class="glass-kpi-top"><span>Бюджета хватит</span>${icon('clock')}</div><div class="glass-kpi-value num">${soon?fmt(Math.max(0,soon.budget.days),1)+' <small>дн.</small>':'—'}</div><div class="glass-kpi-foot">${soon?`${e(platforms[soon.account.platform]?.name)} · минимум по кабинетам`:'Нет полного окна расходов для прогноза'}</div><div class="glass-kpi-note">${late.length?'Просрочено задач: '+late.length:'Активных задач: '+tasks.length}</div></article>
 </section>`;
}
function accountCard(c,s){
 const a=s.account,m=s.current,old=s.previous,f=s.budget,url=accountURL(a),available=a.payment==='postpay'?a.limit:a.balance;
 const stat=(key,label,value,lower=false)=>accountMetricButton(c,a,key,`<span>${label}</span><b class="num">${value}</b>${change(m[key],old[key],lower,s.comparable)}`);
 const primary=(key,label,value,lower=false,help='')=>accountMetricButton(c,a,key,`<span>${label}</span><strong class="num">${value}</strong>${change(m[key],old[key],lower,s.comparable)}`,`channel-kpi channel-kpi-${key}`,help);
 return `<article class="panel channel-card compact-channel horizontal-channel interactive-channel channel-${e(a.platform)} tone-${e(s.tone)}" id="${e(accountId(a))}" tabindex="-1" aria-label="${e(platforms[a.platform]?.name)} · ${e(a.name)}">
 <div class="channel-card-head"><div class="channel-identity"><div class="flex">${brand(a.platform,a.state)}<h3>${e(platforms[a.platform]?.name)}</h3></div><small>${e(a.name)}</small><span class="channel-currency">Валюта кабинета · ${e(a.currency)}</span></div>${chip(s.fresh?(s.complete?'Данные доступны':'Неполный период'):'Проверить источник',s.fresh&&s.complete?'ok':'warning')}<div class="channel-account-actions">${url?`<a class="cabinet-link" href="${e(url)}" target="_blank" rel="noopener noreferrer">Открыть кабинет ${icon('external')}</a>`:R.canManageClients()?button('Добавить ссылку '+icon('link'),'client-settings','small',`data-client="${e(c.id)}"`):'<small>Ссылку добавляет администратор</small>'}<div class="channel-work-actions">${button(icon('plus')+'Задача','task-new-account','ghost small',`data-account="${e(a.id)}"`)}${button(icon('file')+'Журнал','work-log','ghost small',`data-account="${e(a.id)}"`)}</div></div></div>
 <div class="channel-card-body"><div class="channel-primary" aria-label="Основные показатели кабинета">${primary('spend','Расход за период',currencyMoney(m.spend,a.currency),true)}${primary('conversions',e(m.resultsLabel),fmt(m.conversions),false,'Результат кабинета по настроенной цели. Может отличаться от уникального лида в CRM.')}${primary('cpa','Цена результата',currencyMoney(m.cpa,a.currency),true)}${primary('cr','CR кабинета',pct(m.cr,2),false,'Результаты рекламного кабинета / клики × 100%.')}</div>
 <div class="channel-support-grid"><section class="channel-traffic-group" aria-label="Показатели трафика"><h4>Трафик</h4><div class="channel-secondary">${stat('impressions','Показы',fmt(m.impressions))}${stat('clicks','Клики',fmt(m.clicks))}${stat('ctr','CTR',pct(m.ctr,2))}${stat('cpc','CPC',currencyMoney(m.cpc,a.currency),true)}</div></section><section class="channel-budget-group" aria-label="Контроль бюджета"><h4 title="Остаток и прогноз — текущие значения, без исторического ряда">Бюджет · на сегодня</h4><div class="channel-budget"><div><span>${a.payment==='postpay'?'Доступный лимит':'Остаток'}</span><b class="num">${currencyMoney(available,a.currency)}</b></div><div><span>Расход / день</span><b class="num">${currencyMoney(f.daily,a.currency)}</b></div><div class="${f.days!==null&&f.days<(R.settings(c.id).budgetDays??3)?'red':''}"><span>Хватит на</span><b class="num">${f.days===null?'Нет прогноза':fmt(Math.max(0,f.days),1)+' дн.'}</b></div></div></section></div>
 ${accountChart(c,a,periods[S.period])}
 <div class="channel-reading-status ${e(s.tone)}"><b>${e(s.headline)}</b><span>${e(s.detail)}</span></div>
 </div>${(a.campaigns||[]).length?`<footer class="channel-card-footer">${campaignPreview(a,s)}</footer>`:''}</article>`;
}
function campaignPreview(a,s){
 const p=periods[S.period],list=(a.campaigns||[]).map(c=>({campaign:c,m:accountMetrics(c,p),old:accountMetrics(c,p,true)})).sort((a,b)=>(b.m.spend??-1)-(a.m.spend??-1));
 return `<details class="campaign-snapshot"><summary>${icon('layers')} Кампании <b>${list.length}</b>${icon('down')}</summary>${table(['Кампания','Расход','Результаты','Цена'],list.map(({campaign:c,m,old})=>{const comparable=s.fresh&&m.days===dayCount(p)&&old.days===dayCount({from:p.previousFrom,to:p.previousTo});return `<tr><td>${validAccountURL(c.url,a.platform)?`<a href="${e(validAccountURL(c.url,a.platform))}" target="_blank" rel="noopener noreferrer"><b>${e(c.name)}</b> ${icon('external')}</a>`:`<b>${e(c.name)}</b>`}<small>${e(c.goal||'Цель не передана')}</small></td><td>${currencyMoney(m.spend,a.currency)}</td><td>${fmt(m.conversions)}</td><td>${currencyMoney(m.cpa,a.currency)}${change(m.cpa,old.cpa,true,comparable)}</td></tr>`}).join(''))}<p class="sub">Детализация по данным БД. Отсутствующие значения не заменяются нулями.</p></details>`;
}
function crmPanel(c){
 const p=periods[S.period],m=metrics(c,p),old=metrics(c,p,true),revenue=R.read('revenue.'+c.id,c.revenueEnabled||false),comparable=m.crmComplete&&old.crmComplete;
 const metric=(label,value,prev,format=fmt,lower=false,allowed=comparable)=>`<div class="support-metric"><span>${label}</span><b class="num">${format(value)}</b>${change(value,prev,lower,allowed)}</div>`;
 return panel('Лиды и бизнес-результат',`<div class="support-metrics crm-project-metrics">${metric('Лиды CRM',m.leads,old.leads)}${metric('Квалифицированные',m.qualified,old.qualified)}${metric('Продажи',m.sales,old.sales)}${metric('CPL по CRM',m.cpl,old.cpl,n=>currencyMoney(n,m.currency),true)}${revenue?metric('Выручка',m.revenue,old.revenue,n=>currencyMoney(n,m.revenueCurrency))+metric('ROAS',m.roas,old.roas,n=>n==null?'—':fmt(n,2)+'×')+metric('ДРР',m.drr,old.drr,pct,true):''}</div><div class="panel-foot"><span>${m.crmComplete?'CRM покрывает выбранный период':'CRM заполнена не за все дни'}${revenue&&!m.attributed?' · атрибуция не подтверждена':''}</span>${button('Лиды и продажи '+icon('arrow'),'client-tab','ghost small','data-value="sales"')}</div>`,button(revenue?'Скрыть выручку':'+ Выручка','toggle-revenue','ghost small'),'crm-project-panel');
}
export function overview(c){
 const p=periods[S.period],reference=c.dataOrigin==='database'?Date.now():Date.parse(SNAPSHOT),snapshots=c.accounts.map(account=>({...accountSnapshot(account,p,R.settings(c.id),reference),account}));
 return `<div class="performance-dashboard">${executiveSummary(c,snapshots)}${budgetPanel(c)}
 <section class="channel-section"><div class="dashboard-section-title"><div><h2>Рекламные кабинеты <span class="section-count">${c.accounts.length}</span></h2><p>Результаты площадок · CR = результаты / клики</p></div><small class="channel-compact-label">Сопоставляйте показатели по кабинетам</small></div><div class="channel-card-grid horizontal-account-list">${snapshots.map(s=>accountCard(c,s)).join('')||empty('Кабинеты не подключены','Загрузите их из базы данных.',button('Подключить источник','database-settings','primary'))}</div></section>
 ${webAnalyticsSection(c)}${crmPanel(c)}${oneCPanel(c)}${clientActivity(c)}<div class="dashboard-method"><span>${icon('info')} Конверсии кабинетов, целевые сеансы сайта и лиды CRM имеют разные определения. Суммарные расходы показываются по валютам.</span><span>Прогноз бюджета: остаток или лимит / средний расход за 7 полных дней. При пропусках сравнение не рассчитывается.</span></div></div>`;
}
