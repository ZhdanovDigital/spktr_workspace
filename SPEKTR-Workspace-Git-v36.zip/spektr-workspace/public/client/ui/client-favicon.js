import {e} from './components.js';
export function faviconURLs(site){
 try{const url=new URL(/^https?:\/\//i.test(site)?site:'https://'+site);if(!['https:','http:'].includes(url.protocol)||url.username||url.password||!url.hostname.includes('.')||/^(?:localhost|127\.|0\.|10\.|192\.168\.|172\.(?:1[6-9]|2\d|3[01])\.|169\.254\.|\[)/i.test(url.hostname))return null;url.protocol='https:';return {direct:url.origin+'/favicon.ico',fallback:'https://www.google.com/s2/favicons?domain='+encodeURIComponent(url.hostname)+'&sz=64'}}catch{return null}
}
export function clientFavicon(c,cls=''){
 const urls=faviconURLs(c.site);return `<span class="client-mark client-favicon ${e(cls)}" title="${e(c.name)}"><span data-favicon-initials>${e(c.initials||c.name?.slice(0,2)||'?')}</span>${urls?`<img hidden src="${e(urls.direct)}" data-client-favicon data-favicon-fallback="${e(urls.fallback)}" alt="" referrerpolicy="no-referrer" decoding="async">`:''}</span>`;
}
export function installClientFavicons(){
 document.addEventListener('load',event=>{const img=event.target;if(!img.matches?.('img[data-client-favicon]'))return;img.hidden=false;const fallback=img.parentElement.querySelector('[data-favicon-initials]');if(fallback)fallback.hidden=true;img.parentElement.classList.add('favicon-loaded')},true);
 document.addEventListener('error',event=>{const img=event.target;if(!img.matches?.('img[data-client-favicon]'))return;const url=img.dataset.faviconFallback;if(url){delete img.dataset.faviconFallback;img.src=url}else{img.hidden=true;const fallback=img.parentElement.querySelector('[data-favicon-initials]');if(fallback)fallback.hidden=false;img.parentElement.classList.remove('favicon-loaded')}},true);
}
