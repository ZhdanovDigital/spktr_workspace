import {repository as R} from '../data/repository.js';
import {platforms,SNAPSHOT} from '../data/demo.js';
import {accountSnapshot} from '../domain/dashboard.js';
import {periods,periodCaption,comparisonCaption} from '../domain/dates.js';
import {S} from './state.js';
import {e,icon,chip,button} from './components.js';

export function clientControl(c){
 const p=periods[S.period],reference=c.dataOrigin==='database'?Date.now():Date.parse(SNAPSHOT);
 const priority={critical:0,warning:1,neutral:2,good:3};
 const snapshots=c.accounts.map(account=>({...accountSnapshot(account,p,R.settings(c.id),reference),account})).sort((a,b)=>priority[a.tone]-priority[b.tone]);
 const issues=snapshots.filter(s=>['critical','warning'].includes(s.tone));
 const status=issues.length?issues.length+' требуют проверки':!snapshots.length?'Нет подключённых кабинетов':snapshots.some(s=>!s.comparable)?'Нет полной базы сравнения':'Отклонений по правилам нет';
 return `<details class="client-control" data-client-control><summary class="client-control-trigger" title="Эффективность под контролем" aria-controls="client-control-panel">${icon(issues.length?'alert':'check')}<span>Контроль</span>${issues.length?`<b>${issues.length}</b>`:''}${icon('down')}</summary><section class="client-control-panel signal-board" id="client-control-panel" aria-label="Эффективность под контролем"><div class="client-control-heading"><h2>Эффективность под контролем</h2><button type="button" class="ghost icon-btn" data-client-control-close aria-label="Закрыть контроль">${icon('close')}</button></div><div class="client-control-context">${chip(status,issues.length?'warning':snapshots.length&&snapshots.every(s=>s.comparable)?'ok':'info')}<span>${e(periodCaption(S.period))}${S.compare?`<small>к ${e(comparisonCaption(p))}</small>`:''}</span></div><div class="signal-list">${snapshots.map(s=>`<button type="button" class="signal-item ${s.tone}" data-action="client-focus-account" data-account="${e(s.account.id)}"><span class="signal-symbol">${icon(s.tone==='good'?'check':s.tone==='neutral'?'chart':'alert')}</span><span><b>${e(platforms[s.account.platform]?.name||s.account.platform)} · ${e(s.headline)}</b><small>${e(s.account.name)} · ${e(s.detail)}</small></span>${icon('chevron')}</button>`).join('')||'<p class="sub">Кабинеты пока не подключены. Добавьте их в источник данных.</p>'}</div><div class="client-control-footer">${button(icon('settings')+'Пороги контроля','thresholds','ghost small')}</div></section></details>`;
}

export function installClientControl(){
 document.addEventListener('click',event=>{
  for(const disclosure of document.querySelectorAll('[data-client-control][open]')){
   if(!disclosure.contains(event.target))disclosure.open=false;
   else if(event.target.closest('[data-client-control-close]')){disclosure.open=false;disclosure.querySelector('summary')?.focus();}
  }
 });
 document.addEventListener('keydown',event=>{
  if(event.key!=='Escape')return;
  const disclosure=document.querySelector('[data-client-control][open]');
  if(disclosure){event.preventDefault();disclosure.open=false;disclosure.querySelector('summary')?.focus();}
 });
}
