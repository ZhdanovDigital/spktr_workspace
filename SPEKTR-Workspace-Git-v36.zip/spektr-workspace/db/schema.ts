import {sql} from 'drizzle-orm';
import { sqliteTable, text, integer, index, uniqueIndex } from 'drizzle-orm/sqlite-core';

export const workspaceRecords = sqliteTable('workspace_records', {
  key: text('key').primaryKey(),
  valueJson: text('value_json').notNull(),
  revision: integer('revision').notNull().default(1),
  actorId: text('actor_id').notNull(),
  actorName: text('actor_name').notNull(),
  updatedAt: text('updated_at').notNull(),
});

export const workspaceEvents = sqliteTable('workspace_events', {
  id: text('id').primaryKey(),
  recordKey: text('record_key').notNull(),
  revision: integer('revision').notNull(),
  actorId: text('actor_id').notNull(),
  actorName: text('actor_name').notNull(),
  createdAt: text('created_at').notNull(),
}, (table) => [index('workspace_events_record_idx').on(table.recordKey)]);

export const semanticProjects = sqliteTable('semantic_projects', {
 id:text('id').primaryKey(), name:text('name').notNull(), client:text('client').notNull(), owner:text('owner').notNull(),
 document:text('document').notNull(), revision:integer('revision').notNull(), token:text('token').notNull(),
 author:text('author').notNull(), updatedAt:text('updated_at').notNull(),
});
export const semanticVersions = sqliteTable('semantic_versions', {
 id:text('id').primaryKey(), project:text('project').notNull(), revision:integer('revision').notNull(), document:text('document').notNull(),
 author:text('author').notNull(), reason:text('reason').notNull(), createdAt:text('created_at').notNull(),
},t=>[index('semantic_versions_project_idx').on(t.project)]);
export const semanticJobs = sqliteTable('semantic_jobs', {
 id:text('id').primaryKey(), project:text('project').notNull(), source:text('source').notNull(), status:text('status').notNull(),
 document:text('document').notNull(), lease:text('lease').notNull().default(''), leaseUntil:integer('lease_until').notNull().default(0),
 attempts:integer('attempts').notNull().default(0), nextAt:integer('next_at').notNull().default(0),
 error:text('error').notNull().default(''), createdAt:text('created_at').notNull(), updatedAt:text('updated_at').notNull(),
},t=>[index('semantic_jobs_project_idx').on(t.project),uniqueIndex('semantic_jobs_active_project_idx').on(t.project).where(sql`${t.status} IN ('queued','running','retry')`)]);
export const semanticCache = sqliteTable('semantic_cache', {
 key:text('key').primaryKey(), document:text('document').notNull(), expiresAt:integer('expires_at').notNull(),
});
export const semanticLibraries=sqliteTable('semantic_libraries',{
 id:text('id').primaryKey(),scope:text('scope').notNull(),project:text('project').notNull(),owner:text('owner').notNull(),revision:integer('revision').notNull(),document:text('document').notNull(),updatedAt:text('updated_at').notNull(),
});
