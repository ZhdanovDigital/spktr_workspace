CREATE TABLE `semantic_cache` (
	`key` text PRIMARY KEY NOT NULL,
	`document` text NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `semantic_jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`project` text NOT NULL,
	`source` text NOT NULL,
	`status` text NOT NULL,
	`document` text NOT NULL,
	`lease` text DEFAULT '' NOT NULL,
	`lease_until` integer DEFAULT 0 NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`next_at` integer DEFAULT 0 NOT NULL,
	`error` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `semantic_jobs_project_idx` ON `semantic_jobs` (`project`);--> statement-breakpoint
CREATE TABLE `semantic_projects` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`client` text NOT NULL,
	`owner` text NOT NULL,
	`document` text NOT NULL,
	`revision` integer NOT NULL,
	`token` text NOT NULL,
	`author` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `semantic_versions` (
	`id` text PRIMARY KEY NOT NULL,
	`project` text NOT NULL,
	`revision` integer NOT NULL,
	`document` text NOT NULL,
	`author` text NOT NULL,
	`reason` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `semantic_versions_project_idx` ON `semantic_versions` (`project`);