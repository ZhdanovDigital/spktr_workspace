CREATE TABLE `semantic_libraries` (
	`id` text PRIMARY KEY NOT NULL,
	`scope` text NOT NULL,
	`project` text NOT NULL,
	`owner` text NOT NULL,
	`revision` integer NOT NULL,
	`document` text NOT NULL,
	`updated_at` text NOT NULL
);
