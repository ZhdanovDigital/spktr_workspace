CREATE TABLE `workspace_events` (
	`id` text PRIMARY KEY NOT NULL,
	`record_key` text NOT NULL,
	`revision` integer NOT NULL,
	`actor_id` text NOT NULL,
	`actor_name` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `workspace_events_record_idx` ON `workspace_events` (`record_key`);--> statement-breakpoint
CREATE TABLE `workspace_records` (
	`key` text PRIMARY KEY NOT NULL,
	`value_json` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL,
	`actor_id` text NOT NULL,
	`actor_name` text NOT NULL,
	`updated_at` text NOT NULL
);
