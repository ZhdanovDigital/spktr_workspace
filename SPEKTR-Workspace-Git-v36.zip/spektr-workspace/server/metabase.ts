import { env } from 'cloudflare:workers';
import { safeEndpoint } from './security';
function b64(bytes:Uint8Array){let s='';for(const byte of bytes)s+=String.fromCharCode(byte);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
export async function metabaseToken(client:string, entityId?:number) {
  if (typeof client!=='string' || !client || client.length>150 || /[\u0000-\u001f]/.test(client)) throw new Error('Некорректный клиент');
  if (!env.DB) throw new Error('Командное хранилище не подключено');
  const row:any=await env.DB.prepare('SELECT value_json FROM workspace_records WHERE key=?').bind('metabase.'+client).first();
  const config=row?JSON.parse(row.value_json):null;
  if (!config || !Number.isSafeInteger(config.dashboardId) || config.dashboardId<1) throw new Error('Сначала привяжите дашборд к этому клиенту');
  if (entityId!==undefined && entityId!==config.dashboardId) throw new Error('Дашборд не совпадает с привязкой клиента');
  const base=process.env.METABASE_URL,secret=process.env.METABASE_EMBED_SECRET;
  if (!base || !secret) throw new Error('Для встраивания нужны серверные METABASE_URL и METABASE_EMBED_SECRET');
  const origin=safeEndpoint(base);if(origin.pathname!=='/' && origin.pathname!=='')throw new Error('METABASE_URL должен быть адресом сервера без пути');
  const params:Record<string,unknown>=Object.create(null);
  if(config.parameterName){if(!/^[a-zA-Z0-9_-]{1,80}$/.test(config.parameterName))throw new Error('Некорректное имя фильтра');params[config.parameterName]=config.clientValue||client;}
  const encoder=new TextEncoder(),head=b64(encoder.encode(JSON.stringify({alg:'HS256',typ:'JWT'}))),payload=b64(encoder.encode(JSON.stringify({resource:{dashboard:config.dashboardId},params,exp:Math.floor(Date.now()/1000)+600})));
  const key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const signature=b64(new Uint8Array(await crypto.subtle.sign('HMAC',key,encoder.encode(head+'.'+payload))));
  return {jwt:head+'.'+payload+'.'+signature,instanceUrl:origin.origin,dashboardId:config.dashboardId};
}
