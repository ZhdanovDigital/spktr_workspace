import {attachmentReferencesOK} from '../public/client/domain/task-files.js';
import {validateMediaFootnote} from '../public/client/domain/media-plan.js';
import {driveFolderURL} from '../public/client/domain/client-folders.js';
import { env } from 'cloudflare:workers';

const safeKey = /^(?:(?:mediaFootnote|budgetPlan|task|log|report|prompt|settings|metabase|revenue|keywords|ads|integration|activePlan)\..+|(?:clientConfig|clientFolders)\.(?:database|demonstration)\..+|analytics\.config\..+|(?:database\.)?sales\..+|ai\.(?:config|models)|plans|customClients|dataSource)$/;
// Verified Site owner from Sites access policy. Used only to bind the Site-scoped
// authenticated ID once; later authorization uses that immutable ID.
const ownerEmail='zhdanov.roman91@gmail.com';
const accountHosts=new Set(['ads.google.com','adsmanager.facebook.com','business.facebook.com','direct.yandex.ru','direct.yandex.com','direct.yandex.kz','ads.tiktok.com','business.tiktok.com']);
const validDate=(date:unknown)=>typeof date==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(date)&&Number.isFinite(Date.parse(date))&&new Date(date).toISOString().slice(0,10)===date;

export function validateRecord(key: string, value: any, revision: number) {
  if (typeof key!=='string' || !safeKey.test(key) || key.length > 200 || /[\u0000-\u001f]/.test(key)) throw new Error('Неподдерживаемая запись');
  if (!Number.isSafeInteger(revision) || revision < 0) throw new Error('Некорректная версия записи');
  const encoded = JSON.stringify(value);
  if (encoded == null || encoded.length > 240000) throw new Error('Запись слишком большая: максимум 240 000 символов');
  const rejectSecrets = (obj: any): void => {
    if (!obj || typeof obj !== 'object') return;
    for (const [k, v] of Object.entries(obj)) {
      if (/^(?:apiKey|accessToken|refreshToken|password|token|secret)$/i.test(k)) throw new Error('Секреты не сохраняются в командных записях');
      rejectSecrets(v);
    }
  };
  rejectSecrets(value);

  if(key==='settings.exchange'){
    if(!value||!['database','manual'].includes(value.mode))throw new Error('Выберите источник курса');
    if(value.mode==='manual'&&(!value.rates||!Number.isFinite(value.rates.USD)||value.rates.USD<=0||value.rates.USD>1e8||!validDate(value.asOf)))throw new Error('Некорректный курс валют');
  }
  if(key.startsWith('mediaFootnote.')){validateMediaFootnote(value);if(key!=='mediaFootnote.'+value.id)throw new Error('ID шаблона сноски не совпадает');}
  if(key.startsWith('budgetPlan.')){
    if(!value||typeof value!=='object'||Array.isArray(value)||!['database','demonstration'].includes(value.origin)||typeof value.client!=='string'||!value.client||key!==`budgetPlan.${value.origin}.${encodeURIComponent(value.client)}.${value.from}.${value.to}`)throw new Error('Некорректный проект плана');
    if(!validDate(value.from)||!validDate(value.to)||value.from>value.to||(Date.parse(value.to)-Date.parse(value.from))/86400000>=366)throw new Error('Укажите корректный период до 366 дней');
    if(!['manual','media','paid'].includes(value.source)||typeof value.note!=='string'||value.note.length>1000)throw new Error('Проверьте основание и комментарий плана');
    if(!Array.isArray(value.amounts)||!value.amounts.length||value.amounts.length>20)throw new Error('Укажите хотя бы одну сумму');
    const seen=new Set();for(const row of value.amounts){if(!row||typeof row.currency!=='string'||!/^[A-Z]{3}$/.test(row.currency)||seen.has(row.currency)||typeof row.amount!=='number'||!Number.isFinite(row.amount)||row.amount<=0||row.amount>1e12||Math.abs(row.amount*100-Math.round(row.amount*100))>.01)throw new Error('Некорректная сумма или валюта плана');seen.add(row.currency)}
  }
  if(key.startsWith('analytics.config.favorites.')){
    if(!value||typeof value!=='object'||Array.isArray(value)||!['database','demonstration'].includes(value.origin)||typeof value.clientId!=='string'||!value.clientId||key!==`analytics.config.favorites.${value.origin}.${encodeURIComponent(value.clientId)}`||!Array.isArray(value.sources)||value.sources.length>30)throw new Error('Некорректные настройки избранных целей');
    const sources=new Set();for(const source of value.sources){
      if(!source||!['ga4','metrika'].includes(source.provider)||typeof source.sourceId!=='string'||!source.sourceId||source.sourceId.length>200||sources.has(source.provider+':'+source.sourceId)||!Array.isArray(source.goals)||source.goals.length>200)throw new Error('Некорректный счётчик избранных целей');sources.add(source.provider+':'+source.sourceId);
      const goals=new Set();for(const goal of source.goals){if(!goal||typeof goal.id!=='string'||!goal.id||goal.id.length>150||goals.has(goal.id)||!['lead','whatsapp','call'].includes(goal.kind)||typeof goal.name!=='string'||!goal.name||goal.name.length>200)throw new Error('Некорректная избранная цель');goals.add(goal.id)}
    }
  }
  if(key.startsWith('clientFolders.')){
    if(!value||typeof value!=='object'||Array.isArray(value)||typeof value.clientId!=='string'||!value.clientId||value.clientId.length>160||!['database','demonstration'].includes(value.origin)||key!==`clientFolders.${value.origin}.${encodeURIComponent(value.clientId)}`||!value.links||typeof value.links!=='object'||Array.isArray(value.links)||Object.keys(value.links).some(k=>!['general','digital'].includes(k)))throw new Error('Некорректные папки проекта');
    for(const link of Object.values(value.links))if(!driveFolderURL(link))throw new Error('Используйте HTTPS-ссылку на папку Google Диска');
  }
  if(key.startsWith('clientConfig.')){
    if(!value||typeof value!=='object'||Array.isArray(value)||!['database','demonstration'].includes(value.origin)||typeof value.clientId!=='string'||key!==`clientConfig.${value.origin}.${value.clientId}`)throw new Error('Некорректная карточка клиента');
    if(typeof value.manager!=='string'||!value.manager.trim()||value.manager.length>80)throw new Error('Укажите менеджера: до 80 символов');
    if(!value.accountLinks||typeof value.accountLinks!=='object'||Array.isArray(value.accountLinks)||Object.keys(value.accountLinks).length>100)throw new Error('Некорректные ссылки кабинетов');
    for(const [id,link] of Object.entries(value.accountLinks)){
      if(!id||id.length>200||typeof link!=='string'||link.length>2000)throw new Error('Некорректная ссылка кабинета');
      const url=new URL(link);if(url.protocol!=='https:'||url.username||url.password||url.port||!accountHosts.has(url.hostname))throw new Error('Используйте HTTPS ссылку на Google Ads, Meta Ads, Яндекс Директ или TikTok Ads');
    }
  }
  if (/^(task|log|report|prompt)\./.test(key)) {
    if (!value || Array.isArray(value) || typeof value !== 'object' || key !== key.split('.')[0] + '.' + value.id) throw new Error('ID записи не совпадает');
  }
  if (key.startsWith('task.')) {
    if (!String(value.title || '').trim() || !value.client || !value.assignee) throw new Error('Задаче нужны название, клиент и ответственный');
    if (!['todo', 'progress', 'review', 'done', 'cancelled'].includes(value.status)) throw new Error('Неизвестный статус задачи');
    if(String(value.title).length>200||String(value.description||'').length>10000||String(value.assignee).length>100)throw new Error('Слишком длинное поле задачи');
    if(value.subtasks!==undefined&&(!Array.isArray(value.subtasks)||value.subtasks.length>30||value.subtasks.some((s:any)=>!s||typeof s.id!=='string'||typeof s.title!=='string'||!s.title.trim()||s.title.length>200||typeof s.done!=='boolean')))throw new Error('Некорректный список подзадач');
    if(value.comments!==undefined&&(!Array.isArray(value.comments)||value.comments.length>100||value.comments.some((c:any)=>!c||typeof c.id!=='string'||typeof c.text!=='string'||!c.text.trim()||c.text.length>2000||typeof c.author!=='string'||typeof c.at!=='string'||!Number.isFinite(Date.parse(c.at)))))throw new Error('Некорректные комментарии задачи');
    if(value.attachments!==undefined&&!attachmentReferencesOK(value.attachments))throw new Error('Некорректный список вложений: до 10 файлов, до 10 МБ каждый и до 50 МБ всего');
    if (!validDate(value.due)) throw new Error('Некорректный срок задачи');
    if (!['none', 'daily', 'weekly', 'monthly'].includes(value.repeat || 'none')) throw new Error('Неизвестный повтор задачи');
    if(value.kind==='review' && value.status==='done' && (!Array.isArray(value.checks)||value.checks.length!==6||value.checks.some((v:unknown)=>v!==true))) throw new Error('Для завершения проверки отметьте все пункты чеклиста');
  }
  if (key.startsWith('log.')) {
    if (!String(value.text || '').trim() || !value.client || !validDate(value.date)) throw new Error('Заполните клиента, дату и описание изменения');
  }
  if (key.startsWith('report.') && (!value.client || typeof value.text !== 'string')) throw new Error('Неполный отчёт');
  if(key.startsWith('report.')){if(value.fileName!==undefined&&!/^[a-z0-9][a-z0-9_-]{0,149}_ads-report-\d{2}\.\d{2}\.\d{4}$/.test(value.fileName))throw new Error('Неверное имя отчёта');if(value.reportDate!==undefined&&!/^\d{4}-\d{2}-\d{2}$/.test(value.reportDate))throw new Error('Неверная дата отчёта');}
  if (key.startsWith('prompt.')) {
    if (!String(value.name || '').trim() || !String(value.content || '').trim() || value.content.length > 30000) throw new Error('Препромпту нужны название и инструкция до 30 000 символов');
    if (!['agency', 'client', 'platform', 'format'].includes(value.scope)) throw new Error('Неизвестный тип препромпта');
    if(value.scope==='client'&&!value.client)throw new Error('Для клиентского препромпта выберите клиента');
    if(value.scope==='platform'&&!['google','meta','yandex','tiktok'].includes(value.platform))throw new Error('Для инструкции площадки выберите площадку');
  }
  return encoded;
}

export function actor(req: Request) {
  const id = req.headers.get('oai-authenticated-user-id');
  if (!id) throw new Error('Войдите в ChatGPT для работы с командными записями');
  let name = req.headers.get('oai-authenticated-user-full-name') || req.headers.get('oai-authenticated-user-email') || 'Участник команды';
  if (req.headers.get('oai-authenticated-user-full-name-encoding') === 'percent-encoded-utf-8') { try { name = decodeURIComponent(name); } catch {} }
  return { id, name };
}

export async function workspacePermissions(req:Request){
  const user=actor(req),key='access.owner';
  const db=env.DB;if(!db)throw new Error('Командное хранилище ещё не подключено');
  let row:any=await db.prepare('SELECT value_json FROM workspace_records WHERE key=?').bind(key).first();
  if(!row&&req.headers.get('oai-authenticated-user-email')?.toLowerCase()===ownerEmail){
    await db.prepare('INSERT INTO workspace_records (key,value_json,revision,actor_id,actor_name,updated_at) VALUES (?,?,1,?,?,?) ON CONFLICT(key) DO NOTHING').bind(key,JSON.stringify({userId:user.id}),user.id,user.name,new Date().toISOString()).run();
    row=await db.prepare('SELECT value_json FROM workspace_records WHERE key=?').bind(key).first();
  }
  const admin=Boolean(row&&JSON.parse(row.value_json).userId===user.id);
  return {role:admin?'admin':'member',manageClients:admin};
}

// Financial permission is enforced before any shared response leaves the server.
export function publicOneCValue(value:any){
 if(!value||typeof value!=='object'||Array.isArray(value))return {enabled:false,shareRevenue:false,rows:[]};
 let profiles:any[]=[];try{const p=JSON.parse(process.env.ONEC_CONNECTIONS_JSON||'[]');if(Array.isArray(p))profiles=p}catch{}
 const profile=profiles.find(p=>p&&p.id===value.profileId&&p.clientId===value.clientId),enabled=value.enabled===true&&!!profile,revenue=enabled&&value.shareRevenue===true&&profile.allowRevenue===true;
 return {clientId:value.clientId,origin:'database',profileId:value.profileId,enabled,shareRevenue:revenue,from:value.from,to:value.to,lastSynced:value.lastSynced,rows:enabled&&Array.isArray(value.rows)?value.rows.map((r:any)=>Object.fromEntries(['date','orders','completed','cancelled','returned',...(revenue?['revenue','currency']:[])].filter(k=>r[k]!==undefined).map(k=>[k,r[k]]))):[]};
}

export async function readTeam(req: Request) {
  const user = actor(req);
  if (!env.DB) throw new Error('Командное хранилище ещё не подключено');
  const cursor = new URL(req.url).searchParams.get('cursor') || '';
  const result = await env.DB.prepare("SELECT key,value_json,revision,actor_id,actor_name,updated_at FROM workspace_records WHERE key > ? AND key NOT LIKE 'taskFile.%' ORDER BY key LIMIT 101").bind(cursor).all();
  const rows = result.results || [];
  const items = rows.slice(0,100).map((r: any) => ({ key:r.key, value:r.key.startsWith('integration.onec.')?publicOneCValue(JSON.parse(r.value_json)):JSON.parse(r.value_json), revision:r.revision, meta:{authorId:r.actor_id,author:r.actor_name,updatedAt:r.updated_at} }));
  return { items, nextCursor:rows.length > 100 ? items.at(-1)?.key : null, user:{id:user.id,name:user.name,permissions:await workspacePermissions(req)}, shared:true };
}

export async function saveTeam(req: Request, input: { key:string; value:unknown; revision:number }) {
  const user = actor(req);
  if(input.key?.startsWith('integration.onec.'))throw Object.assign(new Error('Настройки 1С изменяются только через коннектор 1С'),{status:403});
  if (!env.DB) throw new Error('Командное хранилище ещё не подключено');
  if(input.key?.startsWith('clientConfig.')&&!(await workspacePermissions(req)).manageClients)throw Object.assign(new Error('Только администратор может назначать менеджера и менять ссылки кабинетов'),{status:403});
  validateRecord(input.key, input.value, input.revision);
  if(input.key.startsWith('task.')&&Array.isArray((input.value as any).attachments)){
    const task=input.value as any,verified=[];
    for(const file of task.attachments){const row:any=await env.DB.prepare('SELECT value_json FROM workspace_records WHERE key=?').bind('taskFile.'+file.id).first();const m=row&&JSON.parse(row.value_json);if(!m||m.taskId!==task.id)throw new Error('Вложение не относится к этой задаче');verified.push({id:m.id,name:m.name,size:m.size,mime:m.mime,uploadedAt:m.uploadedAt,uploadedBy:m.uploadedBy});}
    input.value={...task,attachments:verified};
  }
  const value = validateRecord(input.key, input.value, input.revision);
  const updated = new Date().toISOString();
  // RETURNING + revision guard makes each write atomic and prevents silent overwrites.
  const query = input.revision === 0
    ? env.DB.prepare('INSERT INTO workspace_records (key,value_json,revision,actor_id,actor_name,updated_at) VALUES (?,?,1,?,?,?) ON CONFLICT(key) DO NOTHING RETURNING revision').bind(input.key,value,user.id,user.name,updated)
    : env.DB.prepare('UPDATE workspace_records SET value_json=?,revision=revision+1,actor_id=?,actor_name=?,updated_at=? WHERE key=? AND revision=? RETURNING revision').bind(value,user.id,user.name,updated,input.key,input.revision);
  const saved: any = await query.first();
  if (!saved) {
    const row: any = await env.DB.prepare('SELECT value_json,revision,actor_id,actor_name,updated_at FROM workspace_records WHERE key=?').bind(input.key).first();
    return { conflict:true, current:row ? {key:input.key,value:JSON.parse(row.value_json),revision:row.revision,meta:{authorId:row.actor_id,author:row.actor_name,updatedAt:row.updated_at}} : null };
  }
  // The record is the authoritative audit entry; events are a supplementary index.
  await env.DB.prepare('INSERT INTO workspace_events (id,record_key,revision,actor_id,actor_name,created_at) VALUES (?,?,?,?,?,?)').bind(crypto.randomUUID(),input.key,saved.revision,user.id,user.name,updated).run().catch(() => {});
  return { item:{key:input.key,value:input.value,revision:saved.revision,meta:{authorId:user.id,author:user.name,updatedAt:updated}} };
}
