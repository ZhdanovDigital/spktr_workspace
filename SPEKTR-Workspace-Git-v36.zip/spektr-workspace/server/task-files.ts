import {env} from 'cloudflare:workers';
import {actor} from './team';
import {TASK_FILE_MAX_BYTES,taskFileIdOK} from '../public/client/domain/task-files.js';
const error=(message:string,status=400)=>Object.assign(new Error(message),{status});
const metadataKey=(id:string)=>'taskFile.'+id;
const publicFile=(m:any)=>({id:m.id,name:m.name,size:m.size,mime:m.mime,uploadedAt:m.uploadedAt,uploadedBy:m.uploadedBy});
async function boundedForm(req:Request){
 const limit=TASK_FILE_MAX_BYTES+65536;if(Number(req.headers.get('content-length')||0)>limit)throw error('Файл должен быть не больше 10 МБ',413);
 if(!req.headers.get('content-type')?.startsWith('multipart/form-data;')||!req.body)throw error('Ожидается загрузка файла');
 const reader=req.body.getReader(),chunks:Uint8Array[]=[];let size=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>limit){await reader.cancel();throw error('Файл должен быть не больше 10 МБ',413);}chunks.push(value);}}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
 return new Response(bytes,{headers:{'Content-Type':req.headers.get('content-type')!}}).formData();
}
export async function uploadTaskFile(req:Request){
 const user=actor(req);if(!env.DB||!env.BUCKET)throw error('Хранилище вложений ещё не подключено',503);
 const form=await boundedForm(req),id=form.get('id'),taskId=form.get('taskId'),clientId=form.get('clientId'),file=form.get('file');
 if(!taskFileIdOK(id)||typeof taskId!=='string'||!taskId||taskId.length>160||typeof clientId!=='string'||!clientId||clientId.length>160||!(file instanceof File))throw error('Некорректное вложение или проект');
 if(file.size>TASK_FILE_MAX_BYTES)throw error('Файл должен быть не больше 10 МБ',413);
 const content=await file.arrayBuffer(),hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',content))].map(n=>n.toString(16).padStart(2,'0')).join('');
 const existing:any=await env.DB.prepare('SELECT value_json FROM workspace_records WHERE key=?').bind(metadataKey(String(id))).first();
 if(existing){const m=JSON.parse(existing.value_json);if(m.taskId!==taskId||m.clientId!==clientId||m.sha256!==hash||m.actorId!==user.id)throw error('ID вложения уже используется',409);return {file:publicFile(m)};}
 const name=file.name.replace(/[\\/\u0000-\u001f\u007f]/g,'_').slice(0,180).replace(/[\uD800-\uDBFF]$/,'')||'attachment';
 const key='task-files/'+id+'/'+hash,now=new Date().toISOString();
 const metadata={id,taskId,clientId,name,size:file.size,mime:file.type.slice(0,120),key,sha256:hash,uploadedAt:now,uploadedBy:user.name,actorId:user.id};
 await env.BUCKET.put(key,content,{httpMetadata:{contentType:'application/octet-stream'}});
 const saved:any=await env.DB.prepare('INSERT INTO workspace_records (key,value_json,revision,actor_id,actor_name,updated_at) VALUES (?,?,1,?,?,?) ON CONFLICT(key) DO NOTHING RETURNING revision').bind(metadataKey(String(id)),JSON.stringify(metadata),user.id,user.name,now).first();
 if(!saved){const row:any=await env.DB.prepare('SELECT value_json FROM workspace_records WHERE key=?').bind(metadataKey(String(id))).first();const m=row&&JSON.parse(row.value_json);if(m?.sha256!==hash||m?.taskId!==taskId||m?.clientId!==clientId||m?.actorId!==user.id)throw error('Вложение изменилось. Повторите загрузку.',409);return {file:publicFile(m)};}
 return {file:publicFile(metadata)};
}
export async function downloadTaskFile(req:Request){
 const user=actor(req),id=new URL(req.url).searchParams.get('id');if(!taskFileIdOK(id))throw error('Вложение не найдено',404);
 if(!env.DB||!env.BUCKET)throw error('Хранилище вложений ещё не подключено',503);
 const row:any=await env.DB.prepare('SELECT value_json FROM workspace_records WHERE key=?').bind(metadataKey(String(id))).first();if(!row)throw error('Вложение не найдено',404);const m=JSON.parse(row.value_json);
 const task:any=await env.DB.prepare('SELECT value_json FROM workspace_records WHERE key=?').bind('task.'+m.taskId).first();const linked=task&&JSON.parse(task.value_json).attachments?.some((f:any)=>f.id===id);
 if(!linked&&m.actorId!==user.id)throw error('Вложение ещё не сохранено в задаче',403);
 const object=await env.BUCKET.get(m.key);if(!object)throw error('Файл недоступен',404);
 return new Response(object.body,{headers:{'Content-Type':'application/octet-stream','Content-Length':String(m.size),'Content-Disposition':`attachment; filename="attachment"; filename*=UTF-8''${encodeURIComponent(m.name)}`,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"sandbox; default-src 'none'"}});
}
