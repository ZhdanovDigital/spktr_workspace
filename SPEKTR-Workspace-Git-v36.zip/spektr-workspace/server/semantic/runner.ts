import {database,decode,fail} from './storage';
import {run} from './jobs';
// Narrow machine writer. It can only drain jobs created by an authenticated visitor.
// Sites service access is still required for private hosting; this key is an extra boundary.
export async function runUnattended(req:Request){
 const key=process.env.SEMANTIC_RUNNER_KEY;if(!key)fail('Автономный обработчик не настроен',503);
 const supplied=req.headers.get('authorization')?.replace(/^Bearer /,'')||'';
 const hash=async(s:string)=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
 const [a,b]=await Promise.all([hash(key),hash(supplied)]);let mismatch=0;for(let i=0;i<a.length;i++)mismatch|=a[i]^b[i];if(mismatch)fail('Доступ запрещён',403);
 const db=database(),job:any=await db.prepare("SELECT id,document FROM semantic_jobs WHERE (status IN ('queued','retry') AND next_at<=?) OR (status='running' AND lease_until<?) ORDER BY created_at LIMIT 1").bind(Date.now(),Date.now()).first();if(!job)return {idle:true};
 const data=await decode(job.document);if(!data.executor?.id)fail('У задачи отсутствует инициатор. Создайте сбор заново.');
 const internal=new Request(new URL('/api/semantics',req.url),{headers:{'oai-authenticated-user-id':data.executor.id,'oai-authenticated-user-full-name':encodeURIComponent(data.executor.name),'oai-authenticated-user-full-name-encoding':'percent-encoded-utf-8'}});
 // run() rechecks the stored initiator's current project role on every page.
 try{return {jobId:job.id,...await run(internal,job.id)}}catch(error:any){if(error.status===403){await db.prepare("UPDATE semantic_jobs SET status='failed',error=?,updated_at=? WHERE id=? AND status IN ('queued','retry','running')").bind('У инициатора больше нет права редактировать ядро',new Date().toISOString(),job.id).run();return {jobId:job.id,ok:false,complete:true}}throw error}
}
