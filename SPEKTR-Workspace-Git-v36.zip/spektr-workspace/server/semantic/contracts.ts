/** Extension seam: optional sources must implement their own authorized, bounded page fetch.
 * SERP/competitor/search-term providers are intentionally not fabricated or silently enabled.
 * Register a provider in adapters.ts and an explicit result mapper in jobs.ts before enabling it.
 */
export interface SemanticSourceContext {projectId:string;language:'ru'|'kk';regions:string[];limit:number;depth:number}
export interface SemanticSourceAdapter {
 key:string;
 capabilities:ReadonlyArray<'ideas'|'historical'|'dynamics'|'regions'|'clustering'|'searchterms'>;
 connection():{configured:boolean;missing:string[]};
 page(context:SemanticSourceContext,parameters:Record<string,unknown>,cursor?:string):Promise<{data:unknown;nextCursor?:string;fetchedAt:string}>;
}
export const optionalSourceKinds=['serp','competitors','searchterms'] as const;
