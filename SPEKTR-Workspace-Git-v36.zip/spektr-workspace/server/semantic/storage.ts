import {env} from 'cloudflare:workers';
import {actor,workspacePermissions} from '../team';
export const database=()=>{if(!env.DB)throw Error('Общее хранилище не подключено');return env.DB};
export function fail(message:string,status=400):never{throw Object.assign(new Error(message),{status})}
export async function encode(value:any){const raw=new TextEncoder().encode(JSON.stringify(value));if(raw.length>12000000)fail('Проект превышает 12 МБ');const compressed=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());if(compressed.length>1200000)fail('Проект слишком большой: создайте ядро отдельного направления');let s='';for(let i=0;i<compressed.length;i+=8192)s+=String.fromCharCode(...compressed.subarray(i,i+8192));return btoa(s)}
export async function decode(value:string){const raw=Uint8Array.from(atob(value),c=>c.charCodeAt(0));return JSON.parse(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'))).text())}
export async function access(req:Request,id:string,write=false,leader=false){const row:any=await database().prepare('SELECT * FROM semantic_projects WHERE id=?').bind(id).first();if(!row)fail('Проект не найден',404);const user=actor(req),permissions=await workspacePermissions(req),project=await decode(row.document);const role=permissions.manageClients||row.owner===user.id?'leader':project.acl?.[user.id]||'observer';if(write&&role==='observer'||leader&&role!=='leader')fail('Недостаточно прав для этого действия',403);return {row,project,role,user,admin:permissions.manageClients}}
export async function save(current:any,project:any,user:any,reason:string,job?:{id:string;lease:string;document?:string;status?:string}){
 if(project.phrases.length>5000||project.metrics.length>20000||project.groups.length>1000||project.negatives.length>2000)fail('Достигнут лимит проекта; создайте отдельное ядро направления');
 const db=database(),document=await encode(project),token=crypto.randomUUID(),now=new Date().toISOString(),revision=current.revision+1;
 const extra=job?' AND EXISTS (SELECT 1 FROM semantic_jobs WHERE id=? AND status=\'running\' AND lease=?)':'';
 const args:any[]=[project.name,project.client,document,token,user.name,now,current.id,current.revision];if(job)args.push(job.id,job.lease);
 const update=db.prepare('UPDATE semantic_projects SET name=?,client=?,document=?,revision=revision+1,token=?,author=?,updated_at=? WHERE id=? AND revision=?'+extra+' RETURNING revision').bind(...args);
 // D1 batch is a transaction. Snapshot is inserted only for our successful CAS token.
 const version=db.prepare('INSERT INTO semantic_versions (id,project,revision,document,author,reason,created_at) SELECT ?,id,revision,document,author,?,updated_at FROM semantic_projects WHERE id=? AND token=?').bind(crypto.randomUUID(),reason,current.id,token);
 const statements=[update,version];if(job?.document)statements.push(db.prepare("UPDATE semantic_jobs SET document=?,status=?,attempts=0,lease='',lease_until=0,error='',updated_at=? WHERE id=? AND status='running' AND lease=? AND EXISTS (SELECT 1 FROM semantic_projects WHERE id=? AND token=?)").bind(job.document,job.status,now,job.id,job.lease,current.id,token));
 const result=await db.batch(statements);if(!result[0].results.length)fail('Проект изменён другим участником или сбор остановлен. Обновите данные; ваш ввод остаётся в форме.',409);
 return {project,revision,role:undefined,updatedAt:now,author:user.name};
}
