import {database,encode,decode,fail} from './storage';
import {mutate} from '../../public/client/semantic/core.js';
export async function listLibraries(project:string){const rows=await database().prepare("SELECT document FROM semantic_libraries WHERE scope IN ('agency','topic') OR project=? ORDER BY updated_at DESC LIMIT 100").bind(project).all();return Promise.all(rows.results.map((r:any)=>decode(r.document)))}
export async function libraryVersion(id:string,project:string){const row:any=await database().prepare("SELECT * FROM semantic_libraries WHERE id=? AND (scope IN ('agency','topic') OR project=?)").bind(id,project).first();if(!row)fail('Библиотека не найдена');return {row,value:await decode(row.document)}}
export async function writeLibrary(a:any,data:any){
 const db=database();let existing:any=null;if(data.id){existing=await libraryVersion(data.id,a.project.id);if(existing.row.scope==='agency'&&!a.admin&&existing.row.owner!==a.user.id)fail('Библиотекой агентства управляет руководитель',403);if(existing.row.owner!==a.user.id&&!a.admin)fail('Редактирует автор библиотеки или руководитель',403);if(data.revision!==existing.row.revision)fail('Библиотека изменена другим участником. Обновите данные.',409)}
 if(data.scope==='agency'&&!a.admin)fail('Библиотеку агентства создаёт администратор',403);
 const checked=mutate({...a.project,libraries:[]},'library',data).project.libraries[0],now=new Date().toISOString();const id=existing?.row.id||checked.id,version=(existing?.row.revision||0)+1;
 const history=[...(existing?.value.history||[]),...(existing?[{version:existing.value.version,entries:existing.value.entries,name:existing.value.name,author:existing.value.author,at:existing.value.at}]:[])].slice(-30);
 const doc={...checked,id,version,history,author:a.user.name,at:now};
 const result=existing?await db.prepare('UPDATE semantic_libraries SET scope=?,revision=?,document=?,updated_at=? WHERE id=? AND revision=? RETURNING id').bind(checked.scope,version,await encode(doc),now,id,data.revision).first():await db.prepare('INSERT INTO semantic_libraries (id,scope,project,owner,revision,document,updated_at) VALUES (?,?,?,?,?,?,?) RETURNING id').bind(id,checked.scope,a.project.id,a.user.id,version,await encode(doc),now).first();
 if(!result)fail('Библиотека изменилась. Обновите данные.',409);return doc;
}
